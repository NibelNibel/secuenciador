# Secuenciador de notas — app Android (sin servidor)

Todo va dentro del APK: la app web, Tone.js y las muestras del piano. Funciona sin internet.

## Opción A — sin instalar nada (GitHub, gratis)
1. Crea un repositorio en github.com y sube **todo el contenido** de esta carpeta
   (incluida la carpeta oculta `.github`; si no se sube, crea el archivo
   `.github/workflows/build-apk.yml` a mano con "Add file > Create new file" y pega su contenido).
2. Pestaña **Actions** > "Compilar APK" > **Run workflow** (tarda ~5-8 min).
3. Al terminar, en esa ejecución descarga el artefacto **secuenciador-notas-apk** (zip con el `.apk`).
4. Pasa el `.apk` al móvil, ábrelo y permite "instalar apps desconocidas" cuando Android lo pida.

## Opción B — en tu PC
Requisitos: Node 20+, JDK 21, Android SDK (o Android Studio), Python 3.
```
./scripts/build-android.sh
```
Genera `secuenciador-notas.apk` en esta carpeta.

## Notas
- El APK es "debug" (firmado con la clave de depuración): sirve para instalar directamente.
  Para Google Play hace falta un APK/AAB firmado con tu propia clave.
- Piano: usa las muestras *Salamander Grand Piano* (Alexander Holm, licencia CC-BY 3.0; hay que
  mencionar la autoría). Se descargan al compilar (`scripts/get-piano.sh`) y quedan dentro del APK.
  Si la descarga fallara, la app usa el piano sintetizado.
- La app está en la carpeta `www/`. Si la editas, vuelve a compilar.

## 🏠 Menú principal y modos (`js/menu.js`, `css/home.css`)
- Al abrir **Sonavia** se ve el menú principal: título, botón **⚙️ Ajustes** (apariencia y efectos) y dos paneles de modo. La app siempre arranca aquí.
- **Modo Escritor** (🎹): piano y registro de notas, melodía organizada en secciones y frases, sección de **ritmo** y sección **Escuchar** (panel de la melodía con el reproductor de ritmos). Al tocar su panel se despliega debajo la **lista de melodías**: elegir una la abre en el editor; ahí también está «＋ Nueva melodía» y, si hay una melodía sin guardar, «Borrador».
- **Modo Estudio** (🎛): piano roll multipista, pistas, **Cascada** y proyecto/exportación. Al tocar su panel se despliega debajo la **lista de proyectos** (abrir, nombre, duplicar, eliminar y «＋ Nuevo proyecto»).
- Cada panel explica qué es el modo (descripción y etiquetas de lo que incluye).
- Dentro de un modo ya no hay barra de navegación general: solo una **barra fina** con **←** (volver al menú) y las secciones de ese modo (Escritor: Escribir · Ritmo · Escuchar; Estudio: Roll · Pistas · Cascada · Proyecto). El espacio que ocupaba la barra antigua lo aprovecha el contenido: en el Estudio, el piano roll. El botón «atrás» de Android también vuelve al menú.
- Al volver al menú se reabre el panel del modo del que vienes.

## 🎼 Herramientas musicales (Estudio › Roll › botón 🎼) — `js/teoria.js`, `js/studio-teoria.js`
Todas son **opcionales**: nunca impiden escribir notas fuera de la escala (las que quedan fuera llevan un puntito mientras el resaltado está activo).
- **Escala**: tónica (12) y 22 escalas (mayor, menor natural/armónica/melódica, modos, pentatónicas, blues, **egipcia**, árabe, flamenca, húngara, persa, japonesas, tonos enteros, disminuida). Las notas de la escala se iluminan en el Roll (la tónica más fuerte) y llevan un punto en el teclado; junto al nombre de la pista aparece la tonalidad (p. ej. «E · Mixolidia»). La tonalidad se **guarda con el proyecto**.
- **Ajustar al mover** (se activa a mano): al crear o arrastrar una nota cae en la nota de la escala más cercana (si arrastras varias, la que tocas se ajusta y las demás conservan sus intervalos); las flechas ▲▼ saltan de nota de la escala en nota de la escala. «🧲 Ajustar a la escala las notas seleccionadas» lo hace de una vez.
- **Acordes**: lista de los acordes (tríadas o séptimas) cuyas notas están todas en la escala elegida, con su grado (I, ii, iii°…); tocar uno lo escucha y lo carga en el constructor. Constructor: cualquier nota + 20 tipos (mayor, menor, dim, aug, sus2, sus4, 6, 7, maj7, m7, m7♭5, dim7, add9, 9…), inversión y octava. Se insertan al final de la pista, donde miras o tras lo seleccionado (así se encadenan solos), con duración de ¼ a 2 compases y bajo opcional.
- **Progresión**: 21 progresiones listas (pop I–V–vi–IV, jazz ii–V–I, blues de 12 compases, andaluza, i–VI–III–VII = Am–F–C–G…) que se escriben en la tónica elegida, o escribe las tuyas («Am F C G7», «Bb F#m7», «Lam Do Sol»). «Voces cercanas» hace que cada acorde elija la inversión más próxima al anterior.
- **Arpegio**: convierte lo seleccionado (acordes o notas sueltas) en secuencia: subiendo, bajando, ↑↓, ↓↑, Alberti o aleatorio; velocidad 1/4–1/32, 1–3 octavas, notas ligadas/normales/cortas, y opción de conservar el acorde original.
- **Transponer**: selección (o toda la pista si no hay nada seleccionado) por octava, tono, semitono, cualquier valor 1–24, o **por grados de la escala**. Si alguna nota saldría del rango (C1–C7) no se cambia nada.
- Cada acción es **un solo paso de Deshacer** (↶).

## 🎻 Instrumentos (34, agrupados por familia)
- **Teclados**: Piano (muestras Salamander), Piano eléctrico, Órgano.
- **Cuerdas frotadas**: Cuerdas (conjunto), Violín, Chelo.
- **Cuerdas pulsadas**: Arpa, Guitarra acústica, Guitarra clásica, Guitarra eléctrica, Ukelele, Mandolina, Banjo, Pizzicato.
- **Percusión melódica**: Xilófono, Marimba, Vibráfono, Glockenspiel, Caja de música, Kalimba, Steel drum, Campanas.
- **Vientos y voz**: Flauta, Clarinete, Oboe, Saxofón, Trompeta, Corno francés, Acordeón, Coro.
- **Sintetizadores**: Sintetizador, Retro 8-bit, Bajo, Pad.
- Todos menos el piano se **sintetizan con Tone.js** (sin muestras de audio): no añaden peso al APK y funcionan sin internet. Son aproximaciones sintéticas, no grabaciones reales.
- Se definen en la tabla `INST` de `js/audio.js` (`grp` = familia, `p` = programa General MIDI que se escribe al exportar, `g` = ajuste de volumen solo en el Estudio, `make` = cómo se construye). Los selectores del teclado y de las pistas se arman solos desde esa tabla.
- Los instrumentos nuevos se **nivelan** con la tabla `NIVEL` (mismo volumen percibido que el piano y el órgano, tanto en el teclado como en el Estudio). Al crear uno propio, ajusta su entrada de `NIVEL` si suena más fuerte o más flojo que los demás.
- Al exportar a **MIDI** y **MusicXML** cada pista usa su programa General MIDI. El ukelele y la mandolina no existen en General MIDI y salen como guitarra (clásica y acústica).
- Al abrir una partitura en la **Cascada** (`js/cascada-lectores.js`), el programa o el nombre del instrumento se asigna al más parecido de esta lista.
- Para añadir un instrumento: una entrada en `INST` (y en `NIVEL`); si quieres que lo reconozca el lector de partituras, una regla en `instrumentoDePrograma`.

## Estructura de la canción (secciones y frases)
- Cada melodía se divide en **secciones** (Introducción, Estrofa, Coro…) y cada sección en **frases** (una pestaña por frase).
- Toca la sección activa (o «✏️ Etiqueta») para cambiar su nombre: la app ofrece opciones de estructura o puedes escribir una propia. «📐 Estructura» añade plantillas completas.
- El panel de edición se divide en tres bloques rotulados: **SECCIÓN** (renombrar, mover, plantillas, duplicar, eliminar), **FRASE** (escuchar, unir, eliminar, octava) y **MELODÍA COMPLETA** (copiar, importar, guardar).
- **Octava de toda la frase**: «⬇ Bajar» / «⬆ Subir» desplazan todas las notas de la frase activa una octava (sin editar el texto). Se muestra el rango actual y los botones se desactivan si alguna nota saldría del rango (C0–B8).
- Para dividir una frase: toca una nota y pulsa «✂ Dividir» (la frase se corta después de esa nota). «⤵ Unir» la junta con la siguiente.
- «📋 Copiar» deja en el portapapeles la melodía completa (una línea por frase, bajo el título de cada sección). También está en cada tarjeta de «Melodías».
- «▶ Todo» reproduce solo las notas, en orden, de todas las secciones; «▶ Frase» solo la frase activa.
- Las melodías guardadas con la versión anterior se abren como una sola sección con una frase.

## Modo Escritor › Escuchar (panel de melodía)
- La lista de melodías (en el menú principal) solo muestra nombre, resumen (notas, frases, ritmos) y las secciones como etiquetas de color; **no se ve la melodía**.
- La sección **Escuchar** muestra el **panel** de la melodía que se está editando: datos (notas, secciones, frases, rango, ritmos), acciones (Copiar, Duplicar, Eliminar) y las secciones en tarjetas con **color propio** (mismo tipo = mismo color: «Estrofa» y «Estrofa 2») y la etiqueta en negrita.
- Cada nota es una **cajita**: se ilumina al sonar (las ya tocadas quedan en tono suave y la sección activa se resalta). Tocar una cajita suena esa nota.
- Abajo está el **reproductor de ritmos**: elige «Pulso fijo» (según BPM) o uno de los ritmos creados, mira sus barras iluminarse, y usa ▶ / ⏹, ☆ (ritmo predeterminado) y «＋ Nuevo ritmo» (te lleva a la sección Ritmo; al volver, el ritmo nuevo queda elegido).

## Paneles, reemplazo e importación
- Selector **✏️ Edición / ⇅ Ambos / 🎹 Teclado**: muestra solo el panel de edición, solo el teclado, o los dos.
- **🔁 Reemplazar**: toca una nota, pulsa «Reemplazar» y toca una tecla del piano: la nota se sustituye.
- **📥 Importar**: pega texto con `[Sección]` y una frase por línea; la app crea una melodía nueva dividida en secciones y frases (muestra una vista previa antes de importar).
- El teclado del móvil se dibuja encima sin redimensionar la app (`adjustNothing`, lo aplica `scripts/build-android.sh`; hay que recompilar el APK).

## Ritmos (Modo Escritor › 🥁 Ritmo)
- Se abre con la melodía que estás editando (puedes cambiarla en el selector) y tocas **＋ Crear ritmo**.
- Empieza en la primera nota: **toca y mantén** la pantalla (suena la nota y dura lo que mantengas el dedo); al **soltar**, pasa a la siguiente. Si esperas antes de volver a tocar, ese silencio también se guarda.
- Al terminar la última nota puedes ▶ escucharlo, 🔄 repetirlo o 💾 guardarlo con un nombre. Cada melodía admite varios ritmos.
- **☆ Elegir** marca el favorito (★): es el que suena al pulsar «▶ Reproducir» en «Melodías». También puedes renombrar (✏️) o borrar (🗑).
- **⬇ Descargar**: `.mid` (MIDI con el ritmo exacto) o `.wav` (audio). En el APK se abre el menú «Compartir» de Android (Guardar en el dispositivo, Drive, WhatsApp…); en navegador se descarga directamente.
- Si editas las notas de una melodía después de crear un ritmo, el ritmo queda marcado como desfasado (⚠) y hay que grabarlo de nuevo.
- Requiere los plugins `@capacitor/filesystem` y `@capacitor/share` (ya en `package.json`): **recompila el APK**.

## Sonido
- **🔇** (arriba a la derecha): silencia todo el sonido al instante. Si alguna vez una nota se quedara sonando, púlsalo.
- `js/audio.js` corrige dos fallos de Tone 14.5.26 (`PolySynth.releaseAll` + `_makeVoiceAvailable`) que podían dejar una nota «congelada» al detener la reproducción y empezar otra enseguida.

## 🎛 Estudio (piano roll multipista, integrado desde Tone Studio)
- Modo Estudio. **Todo el sonido sale del motor de la app** (`js/audio.js`): mismos instrumentos, piano de muestras y protección contra notas congeladas. Cada pista tiene su instrumento, volumen y balance, y todas van a un bus con limitador.
- **Teclas del Roll sostenidas**: la columna de teclas suena mientras la mantienes pulsada; admite varios dedos y deslizar (glissando).
- Arriba: ▶ / ■, tempo (mantén − / + para repetir), 🔔 metrónomo. Cuatro secciones: **🎹 Roll**, **🎚 Pistas**, **📁 Proyectos** y **💾 Exportar**.
- **Roll**: una barra con pista, deshacer/rehacer, pegar, Multi, Lazo y **⚙ Más** (desplegable). La fila de debajo cambia sola: sin selección muestra cuadrícula, largo de notas nuevas, zoom y octava; con notas seleccionadas muestra mover, alargar, copiar y borrar.
- **Pistas**: tarjetas desplegables (nombre, sonido, volumen, balance, M/S, limpiar, eliminar) y volumen total. Hasta 8 pistas.
- **Exportar** (proyecto actual): nombre, 🎼 *Traer una melodía a la pista* (con pulso fijo o con uno de tus ritmos), exportar **WAV**, **MIDI**, **Partitura (MusicXML)**, **Tabla de notas (CSV)** y **Proyecto (JSON)** (en el APK abre «Compartir»), importar un proyecto JSON guardado (se añade como proyecto nuevo) y ＋ proyecto nuevo. Se guarda solo.
- Los 34 instrumentos de la app están disponibles en cada pista (ver «🎻 Instrumentos»).
- **Roll sin límite fijo**: empieza con 16 compases y crece solo hacia la derecha al desplazarte (hasta 512). La reproducción da la vuelta al terminar el último compás con notas.
- **Reproducir desde lo que ves**: al pulsar ▶ (también después de pausar) la reproducción empieza en el borde izquierdo de la parte del Roll que se ve en pantalla.
- **Panel de navegación** (debajo del Roll, `js/studio-minimapa.js`): botón `|◀` (ir al comienzo), minimapa de toda la pista en el centro y botón `▶|` (ir al final, última nota). En el minimapa se ven las notas de todas las pistas, un cuadro con la parte visible y la línea roja de reproducción; toca o arrastra el dedo para ir a esa parte. Si está sonando, la música continúa desde el nuevo lugar al soltar.

## 🎛 Mezclador (Estudio › Mezcla) — `js/studio-mezcla.js`, `js/mezcla.js`, `css/mezclador.css`
- Todas las pistas en una sola pantalla: una **tira** por pista (se desplazan de lado) y la tira del **Total** fija a la derecha.
- **Medidor de volumen** estéreo por pista, con rayita de **pico** que se queda 1,2 s. Verde hasta −12 dB, amarillo hasta −3 dB, rojo por encima. Solo mide mientras la sección está a la vista.
- **Luz CLIP**: se enciende cuando la pista llega a −0,1 dB o más (puede distorsionar) y se queda encendida hasta que la toques. El número es el **pico más alto** desde que empezó la reproducción (se reinicia solo al dar ▶ desde cero; «↺ Picos» lo reinicia a mano).
- **Aviso general** arriba: indica qué pistas saturan y cuál es la más fuerte.
- **Total**: mide la mezcla completa justo **antes del limitador**. CLIP = la suma pasa de 0 dB (el limitador la contiene pero suena aplastada); **LIM** se enciende cuando el limitador está bajando el volumen.
- Por pista: **fader** de volumen (doble toque = 0 dB, imán en 0), **balance**, **ganancia de entrada** (−12 a +12 dB, antes de efectos y volumen), **M** / **S** y **FX**.
- **Efectos por pista** (botón FX): Filtro (apaga agudos), Coro, Eco y Reverb, de 0 a 100 %. Solo gastan procesador los que están por encima de 0.
- **Efectos generales** (FX del Total): Reverb, Eco, Graves y Agudos (±12 dB) para toda la canción.
- Se guardan con el proyecto (`tracks[].gan`, `tracks[].fx` y `general` en el JSON; los proyectos anteriores se abren sin efectos). Los respetan la reproducción, la **exportación WAV**, la **Cascada** y el **vídeo MP4**.
- Para añadir un efecto: una entrada en `EFECTOS_PISTA` o `EFECTOS_GENERALES` de `js/mezcla.js` y su construcción en `crearEfecto` de `js/audio.js`.

## 📈 Automatización de parámetros (`js/automation.js`, `js/studio-auto.js`)
- Cambia el **volumen** y el **balance** de una pista *durante la canción*: fundidos de entrada y salida, un instrumento que desaparece antes del coro, un sonido que viaja de izquierda a derecha.
- En el Roll, botón **📈** de la barra: abre bajo el Roll una pista de automatización de la pista actual. Comparte desplazamiento, zoom y cuadrícula con el Roll, así la curva siempre queda alineada con las notas (con el panel abierto se oculta el minimapa para dejar espacio; con 🎼 abierto se cierra el otro panel).
- **Parámetro**: *Volumen* (−∞ a +6 dB) o *Balance* (izquierda–derecha). Cada pista guarda una curva por parámetro; un punto en la pestaña indica que ya hay curva.
- **Puntos**: toca un lugar vacío para añadir uno (se ajusta a la cuadrícula del Roll; volumen a 1 dB, balance a 5 %). Arrastra un punto para moverlo (no cruza a sus vecinos). Arrastra en vacío para desplazar la vista. **🗑** borra el punto elegido, **🧹** borra toda la curva (pide confirmación), **↶ ↷** deshacen y rehacen (por pista; hasta 40 pasos).
- **Curva** (botón central): *Lineal*, *Suave* (arranca y llega con suavidad) o *Escalón* (el valor cambia de golpe en cada punto). Antes del primer punto vale el valor del primero; después del último, el del último.
- Mientras suena manda la curva; al detener o pausar vuelven a valer los deslizadores de **Pistas** (que avisan con «📈 Automatizado…» y tienen un botón **📈 Automatización** que abre la curva de esa pista).
- Se guarda dentro del proyecto (`tracks[].auto` en el JSON; los proyectos anteriores se abren igual, sin curvas). Lo respetan: la reproducción del Estudio, la **exportación WAV**, la **Cascada** y el **vídeo MP4** de la Cascada. MIDI, MusicXML y CSV no llevan automatización.
- Formato: `auto: {vol:{curva, pts:[{s, v}]}, pan:{…}}`; `s` en unidades del Roll (1/32 de nota; negra = 8), `v` en dB (volumen) o −1…1 (balance).
- **Añadir otro parámetro** (p. ej. un filtro): registrarlo en `PARAMS` de `js/automation.js`, darle una salida en `createTrack` de `js/audio.js` (como `autoVol`/`autoPan`) y llamarla desde `tick()` de `studio-auto.js`, `agendarAutomatizacion()` de `cascada.js` y el render de `NS.Audio.render`.

## 📁 Varios proyectos en el Estudio (`js/studio-proyectos.js`)
- La lista de proyectos (en el menú principal, bajo el panel del Modo Estudio) muestra todos los proyectos, el más reciente primero. Cada tarjeta muestra nombre, pistas, notas, BPM, duración, instrumentos, colores de las pistas y fecha de modificación; el abierto lleva la marca «Abierto».
- Acciones por tarjeta: **▶ Abrir** (tocar la tarjeta también abre), **✏️ Nombre**, **⧉ Duplicar** y **🗑 Eliminar** (pide confirmación). Arriba: **＋ Nuevo proyecto**.
- Cada proyecto guarda sus propias pistas, notas y tempo; al cambiar de proyecto el anterior se guarda solo. Si se elimina el abierto, se abre el siguiente más reciente (o se crea uno vacío si no queda ninguno).
- Almacenamiento (`localStorage`): `studio.index` (datos básicos de la lista), `studio.cur` (proyecto abierto) y `studio.p.<id>` (estado completo de cada proyecto). El proyecto único de versiones anteriores (clave `studio`) se migra solo la primera vez, como primer proyecto de la lista, y la clave antigua se deja intacta como respaldo.
- **＋ Proyecto nuevo** (en «Proyecto») e **⬆ Importar proyecto (JSON)** ya no borran ni reemplazan nada: crean un proyecto nuevo.
- La **Cascada** muestra el proyecto que esté abierto en el Estudio.

## Formatos de exportación del Estudio (`js/studio-formatos.js`)
- **Partitura (.musicxml)**: una parte por pista, con tempo, instrumento, acordes, ligaduras entre compases y voces extra cuando las notas se pisan. Se abre en MuseScore, Finale, Sibelius, Flat, etc. Compás fijo de 4/4; las notas graves usan clave de fa.
- **Tabla de notas (.csv)**: pista, instrumento, nota, número MIDI, compás, tiempo, duración (en tiempos y segundos). Se abre en Excel u Hojas de cálculo.
- **Proyecto (.json)**: copia de seguridad completa (pistas, sonidos, volúmenes y notas). **⬆ Importar proyecto** lo añade a la lista como proyecto nuevo (no reemplaza ninguno).
- Las teclas negras del Roll ahora muestran su nombre en blanco (C♯, D♯…).

## Modo Estudio › Cascada (animación de notas que caen)
- Muestra el proyecto del Estudio, o un archivo abierto, como notas que caen sobre un teclado (estilo Falling Notes), con sonido.
- Archivos que acepta: proyecto de la app (`.json`, o un `.js` que lo contenga), partitura MusicXML (`.musicxml`, `.xml`) y MusicXML comprimido (`.mxl`).
- Controles: reproducir, detener, repetir, barra de posición, velocidad, caída (qué tan adelante se ve), teclas (auto o 88), modo cine (pantalla completa) y tocar una pista para ocultarla y silenciarla.
- Archivos: `js/cascada.js` (reproductor y dibujo), `js/cascada-lectores.js` (lectura de archivos), `css/cascada.css`.
- Limitaciones: no se expanden las repeticiones de una partitura; se leen hasta 8 pistas.

## 🎞 Descargar la Cascada como vídeo MP4
- En la sección **Cascada** del Estudio, botón **🎞 Descargar vídeo MP4** (debajo de las pistas). Elige **Calidad** (720p normal / 1080p alta), **Fluidez** (30 / 60 fps) y **Formato** (horizontal 16:9 / vertical 9:16) y pulsa «Crear vídeo».
- El vídeo lleva la animación **y la música** tal como suenan en la app (mismos instrumentos, volúmenes y balance). Respeta la **velocidad**, la **caída**, las **teclas** (auto / 88) y las **pistas ocultas** que tengas elegidas en ese momento.
- No se graba la pantalla: cada fotograma se dibuja y se codifica aparte y el audio se renderiza sin conexión, así que el resultado sale perfecto y sincronizado aunque el móvil vaya justo. Mientras trabaja se ve una vista previa, una barra de progreso y un botón **Cancelar**.
- Salida: H.264 + AAC dentro de un `.mp4` (si el dispositivo no puede, usa VP9 / Opus y lo avisa). Mismo sistema de entrega que el WAV: en el APK abre «Compartir» de Android; en navegador se descarga.
- Tamaño orientativo: 1080p/30 ≈ 45 MB por minuto; 720p/30 ≈ 21 MB por minuto.
- Requiere WebCodecs (Chrome / «Android System WebView» 94 o superior). Si falta, la app lo indica.
- Archivos: `js/cascada-video.js` (exportador y ventana de opciones), `js/mp4-escritor.js` (empaquetador MP4 propio, sin librerías), y en `js/cascada.js` la función `paraVideo()` que dibuja fotogramas sueltos a cualquier resolución.

## Temas (15 estéticas intercambiables)

Botón ⚙️ del menú principal → **Ajustes** → **Apariencia**. Se aplica al instante, sin recargar ni perder el trabajo, y se recuerda entre sesiones.

- `www/css/themes.css`: todo el sistema visual. Variables por tema (`[data-theme="id"]`), ganchos globales y decoración propia de cada estética.
- `www/js/theme.js`: registro de temas, selector, persistencia y paleta de los lienzos (Roll, minimapa, Cascada).
- Claves de `localStorage`: `secuenciadorNotas.v1.tema` y `secuenciadorNotas.v1.temaFx` (efectos animados). No se toca ningún dato de proyectos.
- El vídeo MP4 de la Cascada se exporta siempre con la paleta original, sea cual sea el tema.

### Añadir un tema nuevo
1. En `themes.css`, copia un bloque `[data-theme="..."]` y cambia sus valores (colores, `--r1..--r4`, `--bw`, sombras, `--font`, `--panel-deco`, `--deco-bg`, `--hl/--hd/...` si es claro).
2. Si necesita decoración propia, añade reglas `:root[data-theme="id"] ...` en la sección 4.
3. En `theme.js`, añade `{id, name, sub}` a `THEMES`. La miniatura del selector se genera sola.

## Dónde quedan los archivos exportados
En el móvil, WAV, MIDI, MP4, CSV, MusicXML y proyectos JSON se guardan en **Descargas › Sonavia**
(se ven en el administrador de archivos). La app lo indica al terminar. Lo hace el plugin nativo
`android-nativo/DescargasPlugin.java`; si no estuviera disponible, la app abre el menú «Compartir» de Android.
Las melodías y proyectos guardados con 💾 viven dentro de la app: exporta el JSON del Estudio como copia de seguridad.

## Modo estable (sin crujidos al reproducir)
- Con muchas pistas, sintetizar todo en vivo satura el procesador del teléfono (crujidos y notas que desaparecen). Exportar suena bien porque el render no tiene prisa.
- **🛡️ Modo estable** (botón junto al metrónomo, activado por defecto): antes de reproducir, cada pista se graba una vez (instrumento + ganancia + efectos) y durante la reproducción solo se toca esa grabación. Volumen, balance, automatización, silencio/solo, medidores y efectos generales siguen funcionando en vivo.
- Solo actúa si el proyecto es pesado (3 o más pistas con notas, algún efecto de pista o más de 150 notas). La primera vez (y tras editar una pista) hay una breve espera «Preparando audio…».
- Si editas una pista mientras suena, esa pista pasa a sonar en vivo hasta la próxima vez que pulses ▶.
- Límite de memoria de las grabaciones: 120 MB (`LIMITE_BYTES` en `js/studio-preparar.js`); lo que no cabe se sigue tocando en vivo.
- `index.html` pide `latencyHint: 'playback'` al sistema antes de cargar Tone y `js/audio.js` sube el `lookAhead` a 0,2 s; las teclas en vivo usan `Tone.immediate()` para no notar retraso.
- Código: `js/studio-preparar.js` (lógica), `js/audio.js` (`renderPista`, `tocarPreparado`), `js/studio-roll.js` (ganchos en el reloj) y `js/studio.js` (espera antes de ▶).
