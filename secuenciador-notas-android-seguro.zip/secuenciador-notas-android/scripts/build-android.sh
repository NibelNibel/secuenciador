#!/usr/bin/env bash
# Compila el APK. Requisitos: Node 20+, JDK 21 y Android SDK (Android Studio los incluye).
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/get-piano.sh
npm install

# Nibel: arma una copia ofuscada del código antes de empaquetar, para que no se pueda
# leer tan fácil si alguien abre el APK. La carpeta www original no se toca.
rm -rf www-dist
cp -r www www-dist
npx javascript-obfuscator www-dist/js --output www-dist/js \
  --exclude "**/lib/**" \
  --compact true \
  --control-flow-flattening true \
  --control-flow-flattening-threshold 1 \
  --dead-code-injection true \
  --dead-code-injection-threshold 0.4 \
  --string-array true \
  --string-array-encoding base64 \
  --string-array-threshold 1 \
  --self-defending true \
  --disable-console-output true \
  --rename-globals false
for f in www-dist/css/*.css; do
  npx cleancss -o "$f" "$f"
done

[ -d android ] || npx cap add android
python3 -m pip install --quiet pillow || pip install --quiet --break-system-packages pillow
python3 scripts/set-icons.py

# Nibel: Capacitor copia desde "www", así que usamos la copia ofuscada solo durante el build
WEB_DIR_BACKUP="$(mktemp -d)"
mv www "$WEB_DIR_BACKUP/www"
mv www-dist www
trap 'rm -rf www; mv "$WEB_DIR_BACKUP/www" www' EXIT

npx cap sync android
# Evita que Android 15 dibuje la app bajo la barra de estado
STY=android/app/src/main/res/values/styles.xml
grep -q windowOptOutEdgeToEdgeEnforcement "$STY" || sed -i '0,/<\/style>/s##    <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>\n    </style>#' "$STY"
# El teclado del móvil se dibuja encima, sin redimensionar (ni deformar) la app
MAN=android/app/src/main/AndroidManifest.xml
sed -i 's/android:windowSoftInputMode="[^"]*"/android:windowSoftInputMode="adjustNothing"/' "$MAN"
grep -q windowSoftInputMode "$MAN" || sed -i '0,/<activity/s##<activity android:windowSoftInputMode="adjustNothing"#' "$MAN"
# Plugin nativo «Descargas»: guarda en Descargas/Sonavia (si no compilara, se compila sin él y la app usa «Compartir»)
JAVA_DIR=android/app/src/main/java/com/secuenciador/notas
mkdir -p "$JAVA_DIR"
ORIG_MAIN="$(mktemp)"; cp "$JAVA_DIR/MainActivity.java" "$ORIG_MAIN" 2>/dev/null || : > "$ORIG_MAIN"
cp android-nativo/*.java "$JAVA_DIR/"

# Nibel: clave para firmar el APK de versión (release). Se genera una sola vez y
# debe quedar commiteada en el repo (está fuera de "android/", que sí se ignora),
# para que todas las compilaciones futuras firmen con la misma clave y Android
# acepte las actualizaciones sobre una instalación anterior.
KEYSTORE=android-nativo/release.keystore
KS_PASS="sonavia-release"
if [ ! -f "$KEYSTORE" ]; then
  echo "Generando clave de firma nueva en $KEYSTORE (recuerda hacer commit de este archivo)"
  keytool -genkeypair -v -keystore "$KEYSTORE" -alias release \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=Secuenciador de Notas, OU=Dev, O=Sonavia, L=, S=, C=MX"
fi

# Nibel: activa R8 (minifica y ofusca el código Java/Kotlin compilado) y firma la
# versión release, en vez de compilar una debug sin ofuscar
GRADLE=android/app/build.gradle
if ! grep -q "signingConfigs" "$GRADLE"; then
  python3 - "$GRADLE" "$KEYSTORE" "$KS_PASS" <<'PYEOF'
import re, sys
path, keystore, pw = sys.argv[1], sys.argv[2], sys.argv[3]
src = open(path).read()
# Nibel: primero se parchea buildTypes.release (antes de meter el bloque
# signingConfigs, que también tiene su propio "release {...}" y confundiría al regex)
release_block = re.compile(r'release\s*\{([^{}]*)\}')
def patch_release(m):
    body = m.group(1)
    # Nibel: si ya existe la línea, se reemplaza su valor; si no existe, se agrega
    if re.search(r'minifyEnabled\s+\w+', body):
        body = re.sub(r'minifyEnabled\s+\w+', 'minifyEnabled true', body)
    else:
        body += '\n            minifyEnabled true'
    if 'shrinkResources' not in body:
        body += '\n            shrinkResources true'
    if 'signingConfig ' not in body:
        body += '\n            signingConfig signingConfigs.release'
    if 'proguardFiles' not in body:
        body += '\n            proguardFiles getDefaultProguardFile(\'proguard-android-optimize.txt\'), \'proguard-rules.pro\'\n'
    return 'release {' + body + '\n        }'
src = release_block.sub(patch_release, src, count=1)

signing_block = f'''
    signingConfigs {{
        release {{
            storeFile file("../../{keystore}")
            storePassword "{pw}"
            keyAlias "release"
            keyPassword "{pw}"
        }}
    }}
'''
src = re.sub(r'(android\s*\{)', r'\1' + signing_block, src, count=1)
open(path, 'w').write(src)
PYEOF
fi

# Nibel: evita que R8 rompa el plugin nativo (Capacitor lo llama por reflexión,
# así que no puede dejar que le cambien el nombre ni lo borre por "no usado")
PRO=android/app/proguard-rules.pro
grep -q "com.secuenciador.notas" "$PRO" 2>/dev/null || cat >> "$PRO" << 'EOF'
-keep class com.secuenciador.notas.** { *; }
-keepclassmembers class * {
    @com.getcapacitor.annotation.PluginMethod <methods>;
}
EOF

if ! (cd android && ./gradlew assembleRelease); then
  echo "AVISO: el plugin Descargas no compiló; se compila sin él."
  rm -f "$JAVA_DIR/DescargasPlugin.java"
  [ -s "$ORIG_MAIN" ] && cp "$ORIG_MAIN" "$JAVA_DIR/MainActivity.java"
  (cd android && ./gradlew assembleRelease)
fi
cp android/app/build/outputs/apk/release/app-release.apk secuenciador-notas.apk
echo "Listo: secuenciador-notas.apk (ofuscado JS+CSS, y Java minificado/ofuscado con R8, firmado release)"
