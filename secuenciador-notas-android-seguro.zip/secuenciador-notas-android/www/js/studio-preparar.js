/* Estudio — «Modo estable»: prepara (renderiza) las pistas antes de reproducir.
   Nibel: sintetizar muchas notas y efectos en vivo es lo que hace que el teléfono se ahogue (crujidos y notas que desaparecen).
   Exportar suena bien porque el render no tiene prisa. Aquí se hace lo mismo antes de pulsar ▶: cada pista se graba una vez
   (instrumento + ganancia + efectos) y al reproducir solo se «toca» esa grabación, que casi no gasta procesador.
   Volumen, balance, automatización, silencio/solo, medidores y efectos generales siguen funcionando en vivo.
   Si editas una pista, solo esa vuelve a sintetizarse en vivo hasta la próxima vez que pulses ▶. */
(function(NS){
  'use strict';
  const T = window.Tone, ST = NS.Studio, $ = id => document.getElementById(id);

  const LEAD = 0.05;                              // segundos de silencio al inicio de cada grabación (el render no puede empezar justo en 0)
  const LIMITE_BYTES = 120 * 1024 * 1024;         // memoria máxima de todas las grabaciones; lo que no cabe se sigue tocando en vivo
  const CADA_TICKS = 6;                           // cada cuantos 1/32 se revisa si alguna pista cambió
  const CLAVE = 'modoEstable';

  const stems = new Map();                        // id de pista -> {huella, buf (ToneAudioBuffer), bytes}
  let modo = NS.Storage.get(CLAVE, 'auto');       // 'auto' = solo si el proyecto es pesado · 'no' = siempre en vivo
  if(modo !== 'auto' && modo !== 'no') modo = 'auto';
  let usa = new Set(), gen = 0, esperado = null, previo = -1, ticks = 0, preparando = false, cancelado = false;

  const sec = () => 60 / ST.bpm / 8;
  const activo = () => modo === 'auto';

  // Nibel: «huella» de una pista = todo lo que cambia su sonido. Si cambia, su grabación ya no sirve.
  function huellas(notas, s){
    const h = new Map();
    for(const n of notas){
      let a = h.get(n.t); if(!a){ a = {n:0, h:0}; h.set(n.t, a); }
      a.n++; a.h = (Math.imul(a.h, 31) + n.p * 1009 + n.s * 65537 + n.d * 257 + n.id) | 0;
    }
    const salida = new Map();
    for(const t of ST.tracks){
      const a = h.get(t.id); if(!a) continue;
      const f = t.fx || {};
      salida.set(t.id, a.n + ':' + a.h + '|' + t.inst + '|' + t.gan + '|' + f.filtro + ',' + f.coro + ',' + f.eco + ',' + f.rev + '|' + s.toFixed(5));
    }
    return salida;
  }
  const estereo = t => !!t.fx && (t.fx.coro > 0 || t.fx.rev > 0);
  const costo = t => (t.fx ? (t.fx.rev > 0 ? 40 : 0) + (t.fx.coro > 0 ? 15 : 0) + (t.fx.eco > 0 ? 10 : 0) : 0);

  // Nibel: ¿vale la pena preparar? Con pocas pistas sencillas el modo en vivo responde al instante y suena bien.
  function pesada(notas){
    const conNotas = new Set(notas.map(n => n.t));
    const pistas = ST.tracks.filter(t => conNotas.has(t.id) && ST.audible(t));
    return pistas.length >= 3 || pistas.some(t => costo(t) > 0) || notas.length > 150;
  }

  /* ---------- Antes de reproducir: renderizar lo que haga falta ---------- */
  async function antesDeReproducir(){
    if(!activo() || preparando) return;
    const notas = ST.roll.exportState().notes.filter(n => ST.trackById(n.t));
    if(!notas.length || !pesada(notas)) return;
    preparando = true; cancelado = false;
    try{
      const s = sec(), hs = huellas(notas, s), tasa = T.getContext().sampleRate;
      for(const id of [...stems.keys()]) if(!ST.trackById(id)) stems.delete(id);
      const lista = ST.tracks.filter(t => hs.has(t.id) && ST.audible(t));
      const pendientes = lista.filter(t => !(stems.has(t.id) && stems.get(t.id).huella === hs.get(t.id)))
        .map(t => {
          const mias = notas.filter(n => n.t === t.id), fin = Math.max(...mias.map(n => n.s + n.d)) * s + LEAD + (t.fx && t.fx.rev > 0 ? 3.5 : 2.2);
          return {t, mias, fin, canales:estereo(t) ? 2 : 1, costo:mias.length + costo(t)};
        })
        .sort((a, b) => b.costo - a.costo);
      let usados = 0; stems.forEach((v, id) => { if(lista.some(t => t.id === id) && v.huella === hs.get(id)) usados += v.bytes; });
      let hechos = 0;
      for(const p of pendientes){
        if(cancelado) break;
        const bytes = Math.ceil(p.fin * tasa) * p.canales * 4;
        if(usados + bytes > LIMITE_BYTES){ stems.delete(p.t.id); continue; }       // no cabe: esta pista se queda en vivo
        ST.toast('Preparando audio… ' + (hechos + 1) + '/' + pendientes.length);
        await new Promise(r => setTimeout(r, 30));                                    // deja que se pinte el aviso
        try{
          const buf = await NS.Audio.renderPista({inst:p.t.inst, gan:p.t.gan, fx:p.t.fx},
            p.mias.map(n => ({p:n.p, s:n.s * s + LEAD, d:n.d * s, v:.85})), p.fin, tasa, p.canales);
          stems.set(p.t.id, {huella:hs.get(p.t.id), buf, bytes});         // buf: ToneAudioBuffer
          usados += bytes;
        }catch(e){ console.error(e); stems.delete(p.t.id); }
        hechos++;
      }
    }finally{ preparando = false; esperado = null; ticks = 0; }
  }

  /* ---------- Durante la reproducción: lo llama el Roll en cada 1/32 ---------- */
  // Devuelve el conjunto de pistas que suenan desde su grabación (el Roll no debe sintetizar sus notas).
  function alTick(st, time, notas){
    if(!activo() || !stems.size){ if(usa.size){ usa.forEach(id => { const t = ST.trackById(id); if(t) t.audio.detenerPreparado(time); }); usa = new Set(); } return null; }
    if(T.Transport.state !== 'started') return usa;                  // Nibel: tras pausar/detener todavia llegan ticks ya programados; no deben arrancar grabaciones
    const s = sec();
    const salto = esperado !== st;                                   // arranque o salto de lugar: lo que sonaba ya no vale
    const vuelta = !salto && st < previo;                            // el Roll dio la vuelta al terminar: se relanza, pero la cola de lo anterior se deja terminar
    if(salto) ST.tracks.forEach(t => t.audio.detenerPreparado(time));
    if(salto || vuelta){ gen++; ticks = 0; }
    previo = st;
    if(ticks++ % CADA_TICKS === 0){                                  // ¿alguna pista cambió?
      const hs = huellas(notas, s), nuevo = new Set();
      stems.forEach((v, id) => { if(hs.get(id) === v.huella && ST.trackById(id)) nuevo.add(id); });
      usa.forEach(id => { if(!nuevo.has(id)){ const t = ST.trackById(id); if(t) t.audio.detenerPreparado(time); } });
      usa = nuevo;
    }
    for(const id of usa){
      const t = ST.trackById(id); if(!t) continue;
      if(!ST.audible(t)) continue;
      if(!t.audio.preparadoSonando(gen)) t.audio.tocarPreparado(stems.get(id).buf, st * s + LEAD, time, gen);
    }
    return usa;
  }
  const siguiente = u => { esperado = u; };
  const reiniciar = () => { esperado = null; previo = -1; gen++; ticks = 0; };
  T.Transport.on('stop', reiniciar); T.Transport.on('pause', reiniciar);

  /* ---------- Botón del modo ---------- */
  const boton = $('stEstable');
  function dibujar(){
    if(!boton) return;
    boton.classList.toggle('on', activo()); boton.setAttribute('aria-pressed', activo());
    boton.title = activo() ? 'Modo estable: prepara el audio antes de reproducir (sin crujidos). Toca para desactivarlo.' : 'Modo estable desactivado: todo suena en vivo. Toca para activarlo.';
  }
  if(boton) boton.addEventListener('click', () => {
    modo = activo() ? 'no' : 'auto'; NS.Storage.set(CLAVE, modo); dibujar();
    if(!activo()){ ST.tracks.forEach(t => t.audio.detenerPreparado()); stems.clear(); usa = new Set(); }
    ST.toast(activo() ? 'Modo estable: el audio se prepara antes de reproducir' : 'Modo estable desactivado: todo suena en vivo');
  });
  dibujar();

  ST.preparar = {antesDeReproducir, alTick, siguiente, cancelar:() => { cancelado = true; },
    get preparando(){ return preparando; }, memoria:() => { let b = 0; stems.forEach(v => { b += v.bytes; }); return b; }, tieneGrabacion:id => stems.has(id)};
})(window.NS = window.NS || {});
