/* Estudio — control general: reproducción (Transport de Tone), tempo, metrónomo, secciones
   (Roll / Pistas / Proyecto), proyecto nuevo y arranque (carga lo guardado). */
(function(NS){
  'use strict';
  const T = window.Tone, ST = NS.Studio, $ = id => document.getElementById(id);
  const playBtn = $('stPlay'), beats = [...document.querySelectorAll('#stBeats i')];

  /* ---------- Reproducción ---------- */
  const setPlaying = on => {
    playBtn.textContent = on ? '❚❚' : '▶';
    playBtn.setAttribute('aria-label', on ? 'Pausar' : 'Reproducir');
  };
  async function play(){
    NS.Player.stop();                                           // no se mezclan con la reproducción de la pestaña Melodías
    try{ await NS.Audio.start(); }catch(e){}
    if(T.context.state !== 'running'){ try{ await T.context.resume(); }catch(e){} }
    if(T.context.state !== 'running'){ ST.toast('No se pudo activar el audio. Toca de nuevo.'); return; }
    if(T.Transport.state === 'started'){ T.Transport.pause(); setPlaying(false); }
    else{
      if(ST.preparar){                                          // Nibel: modo estable: antes de sonar, se graba cada pista (ver studio-preparar.js)
        if(ST.preparar.preparando) return;
        playBtn.disabled = true;
        try{ await ST.preparar.antesDeReproducir(); }catch(e){ console.error(e); }
        playBtn.disabled = false;
      }
      if(T.Transport.state === 'started') return;
      ST.roll.releaseHeld(); ST.roll.reiniciarDesdeVista(); T.Transport.start(); setPlaying(true);
    }
  }
  ST.stop = () => {
    if(ST.preparar) ST.preparar.cancelar();
    T.Transport.stop(); setPlaying(false);
    beats.forEach(b => b.classList.remove('on'));
    ST.stopSound(); ST.roll.releaseHeld();
  };
  ST.panic = () => ST.stop();
  playBtn.addEventListener('click', play);
  $('stStop').addEventListener('click', ST.stop);
  document.addEventListener('visibilitychange', () => {
    if(document.hidden && T.Transport.state === 'started'){ T.Transport.pause(); setPlaying(false); ST.stopSound(); }
  });

  // Cada negra: parpadeo del indicador y, si está activado, el clic del metrónomo
  ST.onBeat = (b, time) => {
    if(ST.metro) NS.Audio.click(b === 0, time);
    T.Draw.schedule(() => beats.forEach((d, i) => d.classList.toggle('on', i === b)), time);
  };

  /* ---------- Tempo (mantener pulsado repite) y metrónomo ---------- */
  function holdRepeat(el, delta){
    let t1, t2;
    const end = () => { clearTimeout(t1); clearInterval(t2); };
    el.addEventListener('pointerdown', () => {
      ST.setBpm(ST.bpm + delta);
      t1 = setTimeout(() => { t2 = setInterval(() => ST.setBpm(ST.bpm + delta), 80); }, 400);
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => el.addEventListener(ev, end));
  }
  holdRepeat($('stBpmDn'), -1); holdRepeat($('stBpmUp'), 1);
  const drawMetro = () => { $('stMetro').classList.toggle('on', !!ST.metro); $('stMetro').setAttribute('aria-pressed', !!ST.metro); };
  $('stMetro').addEventListener('click', () => { ST.metro = !ST.metro; drawMetro(); ST.changed(); });

  /* ---------- Secciones del Estudio ---------- */
  const panes = {roll:$('stRoll'), tracks:$('stTracks'), mixer:$('stMezclador'), project:$('stProject')};
  let sub = 'roll';
  ST.showSub = name => {
    if(!panes[name]) name = 'roll';
    sub = name; ST.roll.releaseHeld();
    Object.keys(panes).forEach(k => { panes[k].hidden = k !== name; });
    (ST.subHooks || []).forEach(f => f(name));          // p. ej. redibujar la lista de proyectos al mostrarla
  };
  ST.currentSub = () => sub;                          // lo lee la barra del modo para marcar la sección activa

  /* ---------- Proyecto ---------- */
  const nameIn = $('stName');
  nameIn.addEventListener('input', () => { ST.name = nameIn.value; ST.changed(); });
  $('stNew').addEventListener('click', () => ST.proyectos.nuevo());   // crea otro proyecto (no borra el actual)
  ST.listeners.push(() => {
    if(document.activeElement !== nameIn) nameIn.value = ST.name;
    drawMetro();
  });

  /* ---------- Arranque ---------- */
  ST.proyectos.iniciar();        // abre el último proyecto (o migra el proyecto único de versiones anteriores)
  ST.enableSave();
  ST.showSub('roll');
})(window.NS = window.NS || {});
