/* Piano roll del Estudio. Unidad de tiempo = 1/32 de nota (negra = 8). Notas: {id, t: pista, p: MIDI, s: inicio, d: duración}.
   Las teclas de la izquierda suenan MIENTRAS las mantienes pulsadas (varios dedos, deslizando cambia de nota),
   igual que el teclado de la pestaña Piano. */
(function(NS){
  'use strict';
  const T = window.Tone, ST = NS.Studio, N = NS.Notes, TE = NS.Teoria, $ = id => document.getElementById(id);
  const LOW = 24, HIGH = 96, RH = 30, MINBARS = 16, MAXBARS = 512, MAXU = MAXBARS * 32;
  // El Roll crece solo hacia la derecha: al desplazarte al final se añaden compases (hasta MAXBARS). `bars` es el largo actual.
  let bars = MINBARS;
  const total = () => bars * 32;
  const GRIDS = [[8, '1/4'], [4, '1/8'], [2, '1/16'], [1, '1/32']];
  const LENS = [[1, '1/32'], [2, '1/16'], [4, '1/8'], [6, '1/8.'], [8, '1/4'], [12, '1/4.'], [16, '1/2'], [32, '1']];
  const BLACK = [1, 3, 6, 8, 10];
  const grid = $('stGrid'), keys = $('stKeys'), box = $('stRollBox'), pane = $('stRoll'), more = $('stMore');
  const ctxDraw = $('stCtxDraw'), ctxSel = $('stCtxSel');
  let gx, kx, gw = 0, gh = 0, kw = 0, kh = 0;
  let notes = [], sel = new Set(), clip = [], undoS = [], redoS = [], nextId = 1;
  let U = 12, gi = 2, li = 4, multi = false, lasso = false, canResize = false, oct = 4, inited = false, restoredView = false;
  let playUnit = -1, cur = 0, raf = 0, g = null;
  let tanda = 0, navegando = false; // Nibel: tanda sirve para ignorar avisos viejos de dibujo cuando la reproduccion salta de lugar
  const MARGEN_FINAL = 24;         // Nibel: espacio que se deja despues de la ultima nota al ir al final
  const view = {x:0, y:0};
  const held = new Map(); // pointerId -> {p, tr, h}: teclas del Roll que están sonando

  const step = () => GRIDS[gi][0];
  const defLen = () => LENS[li][0];
  const unitSec = () => 60 / T.Transport.bpm.value / 8;
  const byId = id => notes.find(n => n.id === id);

  /* ---------- Sonido (todo pasa por la pista actual → NS.Audio) ---------- */
  function audition(p, units){
    const tr = ST.cur(); if(!tr) return;
    tr.audio.play(p, Math.min(units ? units * unitSec() : .3, 1.2), undefined, .9);
  }

  // Un único evento en el Transport (cada 1/32); lee las notas actuales, así editar no reprograma nada
  T.Transport.scheduleRepeat(time => {
    const st = cur, sec = unitSec(), miTanda = tanda;
    let end = 32;                                           // la reproducción da la vuelta al terminar el último compás con notas
    const grabadas = ST.preparar ? ST.preparar.alTick(st, time, notes) : null;   // Nibel: pistas que suenan desde su grabación (modo estable): no se sintetizan
    for(const n of notes){
      if(n.s + n.d > end) end = n.s + n.d;
      if(n.s !== st) continue;
      if(grabadas && grabadas.has(n.t)) continue;
      const tr = ST.trackById(n.t);
      if(tr && ST.audible(tr)) tr.audio.play(n.p, n.d * sec, time, .85);
    }
    cur = st + 1 >= Math.ceil(end / 32) * 32 ? 0 : st + 1;
    if(ST.preparar) ST.preparar.siguiente(cur);
    if(ST.auto) ST.auto.tick(st, time, sec);                // automatización: volumen y balance de este instante
    if(st % 8 === 0 && ST.onBeat) ST.onBeat((st / 8) % 4, time);
    if(st % 2 === 0) T.Draw.schedule(() => { if(miTanda !== tanda) return; playUnit = st; follow(); requestDraw(); }, time);
  }, '32n');
  const resetPlay = () => { cur = 0; playUnit = -1; ST.stopSound(); requestDraw(); };
  T.Transport.on('stop', resetPlay);
  T.Transport.on('pause', () => ST.stopSound());

  /* ---------- Teclas sostenidas ---------- */
  const pos = (e, el) => { const r = el.getBoundingClientRect(); return {x:e.clientX - r.left, y:e.clientY - r.top}; };
  const keyPitch = e => HIGH - Math.floor((pos(e, keys).y + view.y) / RH);
  function holdOn(id, p){
    if(p < LOW || p > HIGH) return;
    const tr = ST.cur(); if(!tr) return;
    held.set(id, {p, tr, h:tr.audio.on(p)}); requestDraw();
  }
  function holdOff(id){
    const a = held.get(id); if(!a) return;
    a.tr.audio.off(a.h); held.delete(id); requestDraw();
  }
  const releaseHeld = () => [...held.keys()].forEach(holdOff);
  keys.addEventListener('pointerdown', e => {
    e.preventDefault(); try{ keys.setPointerCapture(e.pointerId); }catch(_){}
    holdOn(e.pointerId, keyPitch(e));
  });
  keys.addEventListener('pointermove', e => {
    const a = held.get(e.pointerId); if(!a) return;
    const p = keyPitch(e); if(p !== a.p){ holdOff(e.pointerId); holdOn(e.pointerId, p); } // deslizar = glissando
  });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => keys.addEventListener(ev, e => holdOff(e.pointerId)));
  document.addEventListener('visibilitychange', () => { if(document.hidden) releaseHeld(); });

  /* ---------- Historial ---------- */
  const snapshot = () => JSON.stringify(notes);
  function commit(pre){
    if(snapshot() === pre) return;
    undoS.push(pre); if(undoS.length > 60) undoS.shift();
    redoS = [];
  }
  function restore(json){
    notes = JSON.parse(json);
    const ids = new Set(notes.map(n => n.id));
    sel = new Set([...sel].filter(i => ids.has(i)));
  }

  /* ---------- Vista ---------- */
  // Asegura que el Roll llegue al menos hasta la unidad `u` (en pasos de 4 compases)
  function growFor(u){
    const need = Math.min(MAXBARS, Math.ceil(u / 32 / 4) * 4);
    if(need > bars) bars = need;
  }
  const clampView = () => {
    view.x = Math.max(0, Math.min(view.x, Math.max(0, MAXU * U - gw)));
    growFor((view.x + gw) / U + 32);
    view.y = Math.max(0, Math.min(view.y, Math.max(0, (HIGH - LOW + 1) * RH - gh)));
  };
  function gotoOct(o){
    oct = Math.max(1, Math.min(6, o));
    view.y = (HIGH - (12 * (oct + 1) + 11)) * RH; clampView(); requestDraw();
  }
  function zoom(f){
    const cx = (view.x + gw / 2) / U;
    U = Math.max(5, Math.min(40, U * f));
    view.x = cx * U - gw / 2; clampView(); requestDraw();
  }
  function follow(){
    if(g || navegando || T.Transport.state !== 'started') return;
    const x = playUnit * U;
    if(x < view.x || x > view.x + gw - 20){ view.x = Math.max(0, x - 40); clampView(); }
  }

  /* ---------- Reproducir desde lo que se ve y navegar por la pista ---------- */
  // Nibel: la reproduccion empieza en el borde izquierdo de lo que estas viendo
  function reiniciarDesdeVista(){
    tanda++;
    cur = Math.max(0, Math.ceil(view.x / U));
    playUnit = cur;
  }
  // Nibel: si esta sonando y cambias de lugar, la musica sigue desde el nuevo lugar
  function saltarSiSuena(){
    if(T.Transport.state !== 'started') return;
    reiniciarDesdeVista(); ST.stopSound(); requestDraw();
  }
  // Nibel: donde termina la ultima nota de todas las pistas
  function finPista(){
    let m = 0;
    for(const n of notes) if(n.s + n.d > m) m = n.s + n.d;
    return m;
  }
  const xMaximo = () => Math.max(0, finPista() * U - gw + MARGEN_FINAL);

  /* ---------- Dibujo ---------- */
  function fit(c){
    const r = c.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    c.width = Math.round(r.width * d); c.height = Math.round(r.height * d);
    const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0);
    return [r.width, r.height, x];
  }
  function requestDraw(){ if(!raf) raf = requestAnimationFrame(draw); }
  const heldSet = () => new Set([...held.values()].map(a => a.p));
  function draw(){
    raf = 0;
    if(!gw || !gh) return;
    const r0 = Math.max(LOW, HIGH - Math.floor((view.y + gh) / RH)), r1 = Math.min(HIGH, HIGH - Math.floor(view.y / RH));
    const hp = heldSet(), C = NS.Theme.palette(), resalta = TE.activa() && TE.estado.resaltar;   // colores del tema activo
    gx.clearRect(0, 0, gw, gh); kx.clearRect(0, 0, kw, kh);
    kx.font = '11px system-ui'; kx.textBaseline = 'middle';
    for(let p = r0; p <= r1; p++){
      const y = (HIGH - p) * RH - view.y, blk = BLACK.includes(p % 12), on = hp.has(p);
      gx.fillStyle = on ? C.filaSonando : blk ? C.filaNegra : C.fila; gx.fillRect(0, y, gw, RH);
      const esc = resalta && TE.enEscala(p);                     // herramienta opcional: notas de la escala elegida
      if(esc && !on){ gx.fillStyle = TE.esRaiz(p) ? (C.escalaRaiz || 'rgba(255,180,84,.24)') : (C.escalaFila || 'rgba(255,180,84,.10)'); gx.fillRect(0, y, gw, RH); }
      if(p % 12 === 0){ gx.fillStyle = C.lineaOctava; gx.fillRect(0, y + RH - 1, gw, 1); }
      kx.fillStyle = on ? C.teclaSonando : blk ? C.teclaNegra : C.teclaBlanca; kx.fillRect(0, y, kw, RH - 1);
      if(esc && !on){ kx.fillStyle = C.escalaPunto || '#ffb454'; kx.beginPath(); kx.arc(kw - 8, y + RH / 2, TE.esRaiz(p) ? 4 : 2.6, 0, 6.2832); kx.fill(); }
      { // Nibel: todas las teclas muestran su nombre (la octava solo en los Do o al sonar); las negras lo llevan en blanco para que se lean
        const full = on || p % 12 === 0;
        kx.fillStyle = on ? C.textoSonando : blk ? C.textoNegra : C.textoBlanca;
        kx.font = (full ? '700 ' : '') + '11px system-ui';
        kx.fillText(full ? N.name(p, '#') : N.name(p, '#').replace(/\d+/, ''), 6, y + RH / 2);
      }
    }
    const st = step(), k0 = Math.floor(view.x / (U * st)), k1 = Math.ceil((view.x + gw) / (U * st));
    gx.lineWidth = 1;
    for(let k = k0; k <= k1; k++){
      const q = k * st; if(q < 0 || q > total()) continue;
      const x = Math.round(q * U - view.x) + 0.5;
      gx.strokeStyle = q % 32 === 0 ? C.cuadriculaCompas : q % 8 === 0 ? C.cuadriculaTiempo : C.cuadriculaFina;
      gx.beginPath(); gx.moveTo(x, 0); gx.lineTo(x, gh); gx.stroke();
      if(q % 32 === 0 && U * 32 >= 44){ gx.fillStyle = C.numeroCompas; gx.font = '10px system-ui'; gx.textBaseline = 'top'; gx.fillText(String(q / 32 + 1), x + 3, gh - 14); }
    }
    gx.textBaseline = 'middle';
    for(const n of notes){
      const x = n.s * U - view.x, w = Math.max(3, n.d * U - 2), y = (HIGH - n.p) * RH - view.y;
      if(x + w < 0 || x > gw || y + RH < 0 || y > gh) continue;
      const tr = ST.trackById(n.t); if(!tr) continue;
      const mine = n.t === ST.curId, on = mine && sel.has(n.id);
      gx.globalAlpha = mine ? 1 : 0.3;
      gx.fillStyle = on ? C.notaElegida : tr.color; gx.fillRect(x + 1, y + 3, w, RH - 6);
      if(on){ gx.strokeStyle = C.notaElegidaBorde; gx.lineWidth = 1.5; gx.strokeRect(x + 1.5, y + 3.5, w - 1, RH - 7); }
      if(on && canResize){ gx.fillStyle = C.notaAsa; gx.fillRect(x + w - 3, y + 3, 4, RH - 6); }
      if(resalta && mine && !on && !TE.enEscala(n.p)){ gx.fillStyle = C.notaTexto; gx.beginPath(); gx.arc(x + w - 5, y + 8, 2.4, 0, 6.2832); gx.fill(); }   // nota fuera de la escala (permitida)
      if(w >= 30 && mine){ gx.fillStyle = C.notaTexto; gx.font = '700 10px system-ui'; gx.fillText(N.name(n.p, '#'), x + 5, y + RH / 2); }
      gx.globalAlpha = 1;
    }
    if(g && g.mode === 'lasso' && g.rect){
      const r = g.rect;
      gx.fillStyle = C.lazoRelleno; gx.fillRect(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0);
      gx.strokeStyle = C.lazoBorde; gx.lineWidth = 1.5; gx.setLineDash([6, 4]);
      gx.strokeRect(r.x0 + 0.5, r.y0 + 0.5, r.x1 - r.x0, r.y1 - r.y0); gx.setLineDash([]);
    }
    const ct = ST.cur();
    if(ct){ // nombre de la pista actual, siempre visible
      gx.font = '600 12px system-ui'; gx.textBaseline = 'middle';
      const w = gx.measureText(ct.name).width + 26;
      gx.fillStyle = C.etiquetaFondo; gx.fillRect(6, 6, w, 22);
      gx.fillStyle = ct.color; gx.fillRect(6, 6, 4, 22);
      gx.fillStyle = C.etiquetaTexto; gx.fillText(ct.name, 16, 17);
      if(resalta){ // tonalidad y escala elegidas, junto al nombre de la pista
        const t = TE.etiqueta(), w2 = gx.measureText(t).width + 16;
        gx.fillStyle = C.etiquetaFondo; gx.fillRect(w + 10, 6, w2, 22);
        gx.fillStyle = C.escalaPunto || C.etiquetaTexto; gx.fillText(t, w + 18, 17);
      }
    }
    if(playUnit >= 0){
      const x = playUnit * U - view.x;
      gx.fillStyle = C.cursor; gx.fillRect(x, 0, 2, gh);
    }
    if(ST.minimapa) ST.minimapa.dibujar(); // Nibel: el minimapa se redibuja junto con el Roll
    if(ST.auto) ST.auto.dibujar();         // la curva de automatización comparte desplazamiento y zoom con el Roll
  }

  /* ---------- Gestos sobre la cuadrícula ---------- */
  function hitTest(px, py){
    for(let i = notes.length - 1; i >= 0; i--){
      const n = notes[i]; if(n.t !== ST.curId) continue;
      const x0 = n.s * U - view.x, x1 = (n.s + n.d) * U - view.x, y0 = (HIGH - n.p) * RH - view.y;
      if(py < y0 || py > y0 + RH || px < x0 - 4 || px > x1 + 4) continue;
      const w = x1 - x0, edge = Math.max(8, w < 30 ? w * 0.4 : 20);
      return {n, zone:px > x1 - edge ? 'edge' : 'body'};
    }
    return null;
  }
  function tapNote(n){
    if(multi) sel.has(n.id) ? sel.delete(n.id) : sel.add(n.id);
    else if(sel.size === 1 && sel.has(n.id)) sel.clear();
    else{ sel.clear(); sel.add(n.id); }
    if(sel.has(n.id)) audition(n.p, n.d);
  }
  function createAt(x, y){
    const st = step();
    const s = Math.floor((x + view.x) / U / st) * st, p0 = HIGH - Math.floor((y + view.y) / RH);
    if(s < 0 || s >= MAXU || p0 < LOW || p0 > HIGH) return;
    const p = TE.ajusta() ? TE.cercana(p0) : p0;                   // «ajustar a la escala» (opcional)
    const pre = snapshot(), id = nextId++, d = Math.min(defLen(), MAXU - s);
    growFor(s + d + 32);
    notes.push({id, t:ST.curId, p, s, d});
    if(!multi) sel.clear();
    sel.add(id); commit(pre); audition(p, d);
  }

  grid.addEventListener('pointerdown', e => {
    if(g) return;
    grid.setPointerCapture(e.pointerId);
    const pt = pos(e, grid), hit = hitTest(pt.x, pt.y);
    g = {id:e.pointerId, x0:pt.x, y0:pt.y, hit, moved:false, mode:null, long:false, pre:snapshot(), vx:view.x, vy:view.y, lastP:hit && hit.n.p};
    if(hit) g.timer = setTimeout(() => { // mantener pulsado = añadir/quitar de la selección
      if(!g || g.moved) return;
      g.long = true;
      sel.has(hit.n.id) ? sel.delete(hit.n.id) : sel.add(hit.n.id);
      if(navigator.vibrate) navigator.vibrate(15);
      requestDraw(); updateUI();
    }, 450);
  });
  grid.addEventListener('pointermove', e => {
    if(!g || e.pointerId !== g.id) return;
    const pt = pos(e, grid), dx = pt.x - g.x0, dy = pt.y - g.y0, st = step();
    if(!g.moved && Math.hypot(dx, dy) > 8){
      g.moved = true; clearTimeout(g.timer);
      if(g.long) g.mode = 'none';
      else if(g.hit){
        if(!sel.has(g.hit.n.id)){ if(!multi) sel.clear(); sel.add(g.hit.n.id); }
        g.mode = g.hit.zone === 'edge' && canResize ? 'resize' : 'move';
        g.orig = notes.filter(n => sel.has(n.id)).map(n => ({...n}));
      }else if(lasso){ g.mode = 'lasso'; g.base = new Set(multi ? sel : []); }
      else g.mode = 'pan';
    }
    if(!g.moved) return;
    if(g.mode === 'pan'){ view.x = g.vx - dx; view.y = g.vy - dy; clampView(); }
    else if(g.mode === 'lasso'){ // rectángulo: atrapa las notas de la pista actual que toque
      const x0 = Math.min(g.x0, pt.x), x1 = Math.max(g.x0, pt.x), y0 = Math.min(g.y0, pt.y), y1 = Math.max(g.y0, pt.y);
      g.rect = {x0, y0, x1, y1}; sel = new Set(g.base);
      for(const n of notes){
        if(n.t !== ST.curId) continue;
        const nx0 = n.s * U - view.x, nx1 = (n.s + n.d) * U - view.x, ny0 = (HIGH - n.p) * RH - view.y;
        if(nx1 >= x0 && nx0 <= x1 && ny0 + RH >= y0 && ny0 <= y1) sel.add(n.id);
      }
      updateUI();
    }
    else if(g.mode === 'move'){
      let dS = Math.round(dx / U / st) * st, dP = -Math.round(dy / RH);
      if(dP && TE.ajusta()){ const a = g.orig.find(o => o.id === g.hit.n.id); if(a) dP = TE.cercana(Math.max(LOW, Math.min(HIGH, a.p + dP))) - a.p; }   // la nota arrastrada cae en la escala; el resto conserva sus intervalos
      dS = Math.max(-Math.min(...g.orig.map(o => o.s)), Math.min(MAXU - Math.max(...g.orig.map(o => o.s + o.d)), dS));
      dP = Math.max(LOW - Math.min(...g.orig.map(o => o.p)), Math.min(HIGH - Math.max(...g.orig.map(o => o.p)), dP));
      for(const o of g.orig){ const n = byId(o.id); n.s = o.s + dS; n.p = o.p + dP; growFor(n.s + n.d + 32); }
      const np = byId(g.hit.n.id).p;
      if(np !== g.lastP){ g.lastP = np; audition(np, 4); }
    }else if(g.mode === 'resize'){
      const dD = Math.round(dx / U / st) * st;
      for(const o of g.orig) growFor(o.s + Math.max(1, o.d + dD) + 32);
      for(const o of g.orig) byId(o.id).d = Math.max(1, Math.min(MAXU - o.s, o.d + dD));
    }
    requestDraw();
  });
  function endGesture(e, cancel){
    if(!g || e.pointerId !== g.id) return;
    const gg = g; g = null; clearTimeout(gg.timer);
    if(cancel) restore(gg.pre);
    else if(!gg.moved){ if(!gg.long) gg.hit ? tapNote(gg.hit.n) : createAt(gg.x0, gg.y0); }
    else if(gg.mode === 'move' || gg.mode === 'resize') commit(gg.pre);
    requestDraw(); updateUI(); ST.changed();
  }
  grid.addEventListener('pointerup', e => endGesture(e, false));
  grid.addEventListener('pointercancel', e => endGesture(e, true));
  [grid, keys].forEach(c => c.addEventListener('contextmenu', e => e.preventDefault()));

  /* ---------- Botones ---------- */
  function dur(delta){
    if(!sel.size) return;
    const pre = snapshot();
    for(const n of notes) if(sel.has(n.id)) { n.d = Math.max(1, Math.min(MAXU - n.s, n.d + delta)); growFor(n.s + n.d + 32); }
    commit(pre);
  }
  function pickTrack(){
    NS.Sheet.open('Pista de trabajo', null, b => {
      const list = document.createElement('div'); list.className = 'stPick';
      ST.tracks.forEach(t => {
        const x = document.createElement('button');
        x.className = 'btn' + (t.id === ST.curId ? ' primary' : ''); x.style.borderLeft = '8px solid ' + t.color;
        x.textContent = t.name + ' · ' + ST.instName(t.inst); x.dataset.id = t.id; list.appendChild(x);
      });
      const add = document.createElement('button'); add.className = 'btn'; add.dataset.add = '1'; add.textContent = '＋ Nueva pista';
      add.disabled = ST.tracks.length >= ST.MAX; list.appendChild(add);
      list.addEventListener('click', e => {
        const x = e.target.closest('button'); if(!x) return;
        NS.Sheet.close();
        if(x.dataset.add) ST.addTrack(); else ST.selectTrack(+x.dataset.id);
      });
      b.appendChild(list);
    });
  }
  const actions = {
    undo(){ if(!undoS.length) return; redoS.push(snapshot()); restore(undoS.pop()); },
    redo(){ if(!redoS.length) return; undoS.push(snapshot()); restore(redoS.pop()); },
    copy(){
      const c = notes.filter(n => sel.has(n.id)); if(!c.length) return;
      const m = Math.min(...c.map(n => n.s));
      clip = c.map(n => ({p:n.p, s:n.s - m, d:n.d}));
      ST.toast(c.length + (c.length === 1 ? ' nota copiada' : ' notas copiadas'));
    },
    paste(){
      if(!clip.length) return;
      const pre = snapshot(), span = Math.max(...clip.map(c => c.s + c.d));
      const s0 = Math.max(0, Math.min(Math.floor(view.x / U / step()) * step(), MAXU - span));
      growFor(s0 + span + 32);
      sel.clear();
      for(const c of clip){ const id = nextId++; notes.push({id, t:ST.curId, p:c.p, s:s0 + c.s, d:c.d}); sel.add(id); }
      commit(pre);
    },
    del(){ if(!sel.size) return; const pre = snapshot(); notes = notes.filter(n => !sel.has(n.id)); sel.clear(); commit(pre); },
    all(){ sel = new Set(notes.filter(n => n.t === ST.curId).map(n => n.id)); },
    track(){ pickTrack(); },
    clear(){ clearTrack(ST.curId); },
    import(){ ST.openImport(); },
    more(){ more.hidden = !more.hidden; },
    multi(){ multi = !multi; },
    resize(){ canResize = !canResize; },
    lasso(){ lasso = !lasso; },
    none(){ sel.clear(); },
    newdn(){ li = Math.max(0, li - 1); },
    newup(){ li = Math.min(LENS.length - 1, li + 1); },
    grid(){ gi = (gi + 1) % GRIDS.length; },
    durup(){ dur(step()); },
    durdn(){ dur(-step()); },
    zoomin(){ zoom(1.25); },
    zoomout(){ zoom(0.8); },
    octup(){ gotoOct(oct + 1); },
    octdn(){ gotoOct(oct - 1); }
  };
  // Una sola escucha para toda la zona de botones (barra, fila contextual y panel «Más»)
  pane.addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b || !pane.contains(b)) return;
    if(b.dataset.n){ // flechas de movimiento: con puntero ya se movió en pointerdown; esto es solo para teclado
      if(e.detail === 0){
        const pre = snapshot(), [dx, dy] = b.dataset.n.split(',').map(Number);
        if(doNudge(dx, dy)){ commit(pre); updateUI(); ST.changed(); }
      }
      return;
    }
    const a = actions[b.dataset.act]; if(!a) return;
    a(); requestDraw(); updateUI(); ST.changed();
  });

  /* ---------- Mover con precisión: flechas (izq/der = un paso de la cuadrícula, arriba/abajo = un semitono) ---------- */
  function ensureVisible(){ // si la selección se sale de la pantalla, desplaza la vista lo mínimo
    const c = notes.filter(n => sel.has(n.id)); if(!c.length) return;
    const x0 = Math.min(...c.map(n => n.s)) * U, x1 = Math.max(...c.map(n => n.s + n.d)) * U;
    const y0 = (HIGH - Math.max(...c.map(n => n.p))) * RH, y1 = (HIGH - Math.min(...c.map(n => n.p)) + 1) * RH;
    if(x0 < view.x) view.x = x0 - 20; else if(x1 > view.x + gw) view.x = x1 - gw + 20;
    if(y0 < view.y) view.y = y0 - 10; else if(y1 > view.y + gh) view.y = y1 - gh + 10;
    clampView();
  }
  function doNudge(dxSteps, dP){
    const c = notes.filter(n => sel.has(n.id)); if(!c.length) return false;
    let dS = dxSteps * step();
    if(dP && TE.ajusta()){ const q = TE.siguiente(c[0].p, dP > 0 ? 1 : -1); if(q !== null) dP = q - c[0].p; }   // con el ajuste, ▲▼ saltan de nota de la escala en nota de la escala
    dS = Math.max(-Math.min(...c.map(n => n.s)), Math.min(MAXU - Math.max(...c.map(n => n.s + n.d)), dS));
    dP = Math.max(LOW - Math.min(...c.map(n => n.p)), Math.min(HIGH - Math.max(...c.map(n => n.p)), dP));
    if(!dS && !dP) return false;
    for(const n of c){ n.s += dS; n.p += dP; growFor(n.s + n.d + 32); }
    if(dP) audition(c[0].p, 4);
    ensureVisible(); requestDraw(); return true;
  }
  let nz = null;
  const endNudge = () => {
    if(!nz) return;
    clearTimeout(nz.t1); clearInterval(nz.t2);
    commit(nz.pre); nz = null; updateUI(); requestDraw(); ST.changed(); // una sola entrada de historial por pulsación
  };
  ctxSel.addEventListener('pointerdown', e => {
    const b = e.target.closest('[data-n]'); if(!b || b.disabled || nz) return;
    const [dx, dy] = b.dataset.n.split(',').map(Number);
    nz = {pre:snapshot()};
    doNudge(dx, dy);
    nz.t1 = setTimeout(() => { nz.t2 = setInterval(() => { if(!doNudge(dx, dy)) clearInterval(nz.t2); }, 90); }, 400);
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => ctxSel.addEventListener(ev, endNudge));
  ctxSel.addEventListener('contextmenu', e => e.preventDefault());

  /* ---------- Limpiar pista (con confirmación; se puede deshacer) ---------- */
  async function clearTrack(id){
    const tr = ST.trackById(id); if(!tr) return;
    const n = notes.filter(x => x.t === id).length;
    if(!n){ ST.toast('«' + tr.name + '» ya está vacía'); return; }
    const ok = await ST.ask({title:'Limpiar pista', msg:'Se borrarán las ' + n + ' notas de «' + tr.name + '». Podrás recuperarlas con Deshacer (↶).', ok:'Limpiar pista'});
    if(!ok) return;
    const pre = snapshot();
    notes = notes.filter(x => x.t !== id); sel.clear(); ST.stopSound();
    commit(pre); requestDraw(); updateUI(); ST.changed();
    ST.toast('Pista limpiada');
  }

  /* ---------- Estado de los controles ---------- */
  function updateUI(){
    const q = a => pane.querySelector('[data-act="' + a + '"]');
    q('undo').disabled = !undoS.length; q('redo').disabled = !redoS.length; q('paste').disabled = !clip.length;
    q('multi').classList.toggle('on', multi); q('lasso').classList.toggle('on', lasso);
    q('more').classList.toggle('on', !more.hidden);
    const has = sel.size > 0;
    ctxSel.hidden = !has; ctxDraw.hidden = has;
    $('stNone').textContent = '✕ ' + sel.size;
    ctxSel.querySelectorAll('[data-n]').forEach(b => { if(!(nz && b.dataset.n)) b.disabled = !has; });
    const rs = q('resize'); rs.classList.toggle('on', canResize); rs.textContent = '↔ Alargar con el dedo: ' + (canResize ? 'sí' : 'no');
    $('stNewLen').textContent = '♩ ' + LENS[li][1];
    q('newdn').disabled = li === 0; q('newup').disabled = li === LENS.length - 1;
    q('grid').textContent = '▦ ' + GRIDS[gi][1];
    const tb = q('track'), tr = ST.cur();
    if(tr){ tb.textContent = tr.name; tb.style.setProperty('--c', tr.color); tb.title = 'Cambiar de pista (' + tr.name + ')'; }
    uiHooks.forEach(f => f());
  }
  const uiHooks = [];                                   // los paneles de herramientas musicales se enteran de cambios de selección y de pista

  NS.Theme.onChange(requestDraw);   // al cambiar de tema se vuelve a dibujar el Roll con la nueva paleta

  /* ---------- Tamaño ---------- */
  new ResizeObserver(() => {
    let r = fit(grid); gw = r[0]; gh = r[1]; gx = r[2];
    r = fit(keys); kw = r[0]; kh = r[1]; kx = r[2];
    if(gw && !inited){ inited = true; if(!restoredView) gotoOct(4); }
    clampView(); requestDraw();
  }).observe(box);

  /* ---------- API para el resto del Estudio ---------- */
  ST.roll = {
    LOW, HIGH,
    releaseHeld,
    reiniciarDesdeVista,
    // Nibel: lo que necesita el panel de navegacion (minimapa y botones de inicio y final)
    navegacion: {
      leer: () => ({x:view.x, ancho:gw, u:U, fin:finPista(), notas:notes, unidadActual:playUnit, margen:MARGEN_FINAL}),
      ir(x){ view.x = Math.max(0, Math.min(x, xMaximo())); clampView(); requestDraw(); },
      empezar(){ navegando = true; },
      terminar(){ navegando = false; saltarSiSuena(); },
      saltarSiSuena
    },
    /* ---- Automatización (js/studio-auto.js): comparte desplazamiento, zoom y cuadrícula con el Roll ---- */
    vista: () => ({x:view.x, ancho:gw, u:U, cursor:playUnit, paso:step(), tocando:T.Transport.state === 'started'}),
    desplazarX(x){ view.x = x; clampView(); requestDraw(); },
    asegurarHasta(u){ growFor(u + 32); },
    /* ---- Herramientas musicales (js/studio-teoria.js) ---- */
    uiHooks,
    redibujar: () => requestDraw(),
    notasSel: () => notes.filter(n => sel.has(n.id) && n.t === ST.curId).map(n => ({id:n.id, p:n.p, s:n.s, d:n.d})),
    notasPista: () => notes.filter(n => n.t === ST.curId).map(n => ({id:n.id, p:n.p, s:n.s, d:n.d})),
    finPistaActual: () => notes.reduce((m, n) => (n.t === ST.curId ? Math.max(m, n.s + n.d) : m), 0),
    inicioVista: () => Math.max(0, Math.round(view.x / U / 8) * 8),
    sonar(ps, secs, retraso){                       // vista previa: suena en la pista actual sin escribir nada
      const tr = ST.cur(); if(!tr) return;
      const t0 = T.now() + 0.03 + (retraso || 0);
      ps.forEach(p => { if(p >= LOW && p <= HIGH) tr.audio.play(p, secs, t0, .85); });
    },
    // Añade notas {p, s, d} (posiciones absolutas) a la pista actual y las deja seleccionadas. ids: notas que se quitan a la vez (una sola entrada de historial).
    colocar(list, quitar){
      const pre = snapshot(); let added = 0, cut = 0; const ids = [];
      if(quitar && quitar.length){ const q = new Set(quitar); notes = notes.filter(n => !q.has(n.id)); }
      for(const x of list){
        if(x.p < LOW || x.p > HIGH || x.s < 0 || x.s >= MAXU){ cut++; continue; }
        const id = nextId++; notes.push({id, t:ST.curId, p:x.p, s:x.s, d:Math.max(1, Math.min(x.d, MAXU - x.s))});
        ids.push(id); added++; growFor(x.s + x.d + 32);
      }
      sel = new Set(ids); commit(pre); ensureVisible(); requestDraw(); updateUI(); ST.changed();
      return {added, cut};
    },
    // Cambia la altura de las notas con fn(p) → p nuevo. ids = null: toda la pista actual. Si alguna saldría del rango, no cambia nada.
    transponer(ids, fn){
      const q = ids ? new Set(ids) : null, c = notes.filter(n => n.t === ST.curId && (!q || q.has(n.id)));
      if(!c.length) return {ok:false, n:0};
      const nuevas = c.map(n => fn(n.p));
      if(nuevas.some(p => !Number.isInteger(p) || p < LOW || p > HIGH)) return {ok:false, n:c.length, fuera:true};
      const pre = snapshot(); let cambiadas = 0;
      c.forEach((n, i) => { if(n.p !== nuevas[i]){ n.p = nuevas[i]; cambiadas++; } });
      commit(pre); if(cambiadas) audition(c[0].p, 4);
      if(q) ensureVisible(); requestDraw(); updateUI(); ST.changed();
      return {ok:true, n:c.length, cambiadas};
    },
    countNotes: id => notes.reduce((a, n) => a + (n.t === id ? 1 : 0), 0),
    removeNotes(id){ notes = notes.filter(n => n.t !== id); sel.clear(); undoS = []; redoS = []; requestDraw(); },
    clearTrack,
    // Añade notas {p, s, d} a la pista actual a partir del compás visible. Devuelve {added, cut}.
    addNotes(list){
      const pre = snapshot(), s0 = Math.max(0, Math.floor(view.x / U / 8) * 8);
      let added = 0, cut = 0; sel.clear();
      for(const x of list){
        const s = x.s + s0;
        if(s >= MAXU){ cut++; continue; }
        const id = nextId++;
        notes.push({id, t:ST.curId, p:x.p, s, d:Math.max(1, Math.min(x.d, MAXU - s))}); sel.add(id); added++; growFor(s + x.d + 32);
      }
      commit(pre); requestDraw(); updateUI(); ST.changed();
      return {added, cut};
    },
    // La posición de la vista solo se guarda si el Roll ya llegó a mostrarse (si no, al abrirlo quedaría arriba del todo)
    exportState: () => ({notes, nextId, ui:{bars, U, gi, li, canResize, multi, lasso, oct, vx:inited ? view.x : undefined, vy:inited ? view.y : undefined}}),
    importState(d){
      const ok = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
      const good = n => n && ok(n.id, 1, 1e9) && ST.trackById(n.t) && ok(n.p, LOW, HIGH) && ok(n.s, 0, MAXU - 1) && ok(n.d, 1, MAXU - n.s);
      notes = (Array.isArray(d.notes) ? d.notes : []).filter(good).map(n => ({id:n.id, t:n.t, p:n.p, s:n.s, d:n.d}));
      nextId = Math.max(Number.isInteger(d.nextId) ? d.nextId : 1, ...notes.map(n => n.id + 1));
      undoS = []; redoS = []; sel.clear();
      const u = d.ui || {}, fin = Number.isFinite;
      bars = Math.max(MINBARS, ok(u.bars, MINBARS, MAXBARS) ? u.bars : MINBARS);
      growFor(Math.max(0, ...notes.map(n => n.s + n.d)) + 32);
      if(fin(u.U)) U = Math.max(5, Math.min(40, u.U));
      if(ok(u.gi, 0, GRIDS.length - 1)) gi = u.gi;
      if(ok(u.li, 0, LENS.length - 1)) li = u.li;
      if(ok(u.oct, 1, 6)) oct = u.oct;
      canResize = !!u.canResize; multi = !!u.multi; lasso = !!u.lasso;
      if(fin(u.vx) && fin(u.vy)){ view.x = u.vx; view.y = u.vy; restoredView = true; clampView(); }
      updateUI(); requestDraw();
    }
  };
  ST.listeners.push(() => {
    sel = new Set([...sel].filter(i => { const n = byId(i); return n && n.t === ST.curId; }));
    updateUI(); requestDraw();
  });
})(window.NS = window.NS || {});
