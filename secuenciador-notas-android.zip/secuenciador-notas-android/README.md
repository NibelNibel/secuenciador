# Secuenciador de notas — app Android (sin servidor)

Todo va dentro del APK: la app web, Tone.js y las muestras del piano. Funciona sin internet.

## Opción A — sin instalar nada (GitHub, gratis)
1. Crea un repositorio en github.com y sube **todo el contenido** de esta carpeta
   (incluida la carpeta oculta `.github`; si no se sube, crea el archivo
   `.github/workflows/build-apk.yml` a mano con "Add file > Create new file" y pega su contenido).
2. Pestaña **Actions** > "Compilar APK" > **Run workflow** (tarda ~5-8 min).
3. Al terminar, en esa ejecución descarga el artefacto **secuenciador-notas-apk** (zip con el `.apk`).
4. Pasa el `.apk` al móvil, ábrelo y permite "instalar apps desconocidas" cuando Android lo pida.

## Opción B — en tu PC
Requisitos: Node 20+, JDK 21, Android SDK (o Android Studio), Python 3.
```
./scripts/build-android.sh
```
Genera `secuenciador-notas.apk` en esta carpeta.

## Notas
- El APK es "debug" (firmado con la clave de depuración): sirve para instalar directamente.
  Para Google Play hace falta un APK/AAB firmado con tu propia clave.
- Piano: usa las muestras *Salamander Grand Piano* (Alexander Holm, licencia CC-BY 3.0; hay que
  mencionar la autoría). Se descargan al compilar (`scripts/get-piano.sh`) y quedan dentro del APK.
  Si la descarga fallara, la app usa el piano sintetizado.
- La app está en la carpeta `www/`. Si la editas, vuelve a compilar.
