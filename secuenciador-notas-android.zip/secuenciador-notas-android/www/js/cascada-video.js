/* Cascada → vídeo MP4. Dibuja la animación fotograma a fotograma (más rápido o más lento que en tiempo real, da igual),
   crea el audio con el mismo motor de sonido de la app, codifica ambos con WebCodecs (H.264 + AAC) y los junta en un .mp4
   con NS.Mp4. No depende de que la pantalla vaya fluida: el vídeo sale siempre perfecto y con el audio sincronizado.
   Requiere WebView/Chrome con WebCodecs (Android 5+ con "Android System WebView" actualizado, Chrome 94+). */
(function(NS){
  'use strict';
  const $ = id => document.getElementById(id);
  const OPC_RESOLUCION = [[720, '720p · normal'], [1080, '1080p · alta']];
  const OPC_FPS = [[30, '30 fps'], [60, '60 fps']];
  const OPC_FORMA = [['h', '🖥 Horizontal'], ['v', '📱 Vertical']];
  const BITS_POR_PIXEL = 0.1;                                   // calidad del vídeo: bits por pixel y fotograma (720p30 ≈ 2,8 Mbps; 1080p30 ≈ 6 Mbps)
  const FRECUENCIA_AUDIO = 48000;                               // la aceptan tanto AAC como Opus
  const ATRAS_MAXIMO = 6;                                       // fotogramas esperando en el codificador antes de pausar el dibujo
  const CANCELADO = {cancelado:true};

  let enCurso = false, cancelar = false;
  const ajustes = Object.assign({resolucion:1080, fps:30, forma:'h'}, NS.Storage.get('cascadaVideo', {}));
  const hayWebCodecs = () => ['VideoEncoder', 'AudioEncoder', 'VideoFrame', 'AudioData'].every(n => typeof window[n] === 'function');
  const esperar = ms => new Promise(r => setTimeout(r, ms));
  const aBytes = d => (d instanceof Uint8Array ? d : new Uint8Array(d.buffer || d, d.byteOffset || 0, d.byteLength));
  const nombreSeguro = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w\- .]+/g, '_').trim().slice(0, 40) || 'Cascada';

  /* ---------- Medidas: el dibujo usa medidas "logicas" y el ratio las lleva a los pixeles del video ---------- */
  function medidas(o){
    const alta = o.resolucion === 1080;
    if(o.forma === 'v'){ const w = alta ? 1080 : 720; return {ancho:450, alto:800, ratio:w / 450, w, h:alta ? 1920 : 1280}; }
    const w = alta ? 1920 : 1280; return {ancho:1280, alto:720, ratio:w / 1280, w, h:alta ? 1080 : 720};
  }

  /* ---------- Codecs: el mejor que admita este dispositivo ---------- */
  async function elegirVideo(m, fps){
    const bitrate = Math.round(m.w * m.h * fps * BITS_POR_PIXEL);
    const candidatos = [['avc1.64002A', 'avc'], ['avc1.4d002a', 'avc'], ['avc1.42002a', 'avc'], ['vp09.00.41.08', 'vp9']];
    for(const [codec, tipo] of candidatos){
      const cfg = {codec, width:m.w, height:m.h, bitrate, framerate:fps, ...(tipo === 'avc' ? {avc:{format:'avc'}} : {})};
      try{ const r = await VideoEncoder.isConfigSupported(cfg); if(r && r.supported) return {cfg, tipo, codec}; }catch(e){}
    }
    return null;
  }
  async function elegirAudio(){
    for(const [codec, tipo, bitrate] of [['mp4a.40.2', 'aac', 192000], ['opus', 'opus', 160000]]){
      const cfg = {codec, sampleRate:FRECUENCIA_AUDIO, numberOfChannels:2, bitrate};
      try{ const r = await AudioEncoder.isConfigSupported(cfg); if(r && r.supported) return {cfg, tipo}; }catch(e){}
    }
    return null;
  }
  // Por si el codificador no entrega la "descripcion" del audio, se arma a mano
  const FRECUENCIAS_AAC = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
  function descripcionAac(frecuencia, canales){
    const f = Math.max(0, FRECUENCIAS_AAC.indexOf(frecuencia)), v = (2 << 11) | (f << 7) | (canales << 3);
    return Uint8Array.of(v >> 8, v & 255);
  }
  function descripcionOpus(frecuencia, canales){
    const d = new Uint8Array(19), dv = new DataView(d.buffer);
    d.set([0x4F, 0x70, 0x75, 0x73, 0x48, 0x65, 0x61, 0x64, 1, canales]); dv.setUint16(10, 312, true); dv.setUint32(12, frecuencia, true);
    return d;
  }

  /* ---------- Progreso ---------- */
  function mostrar(titulo){
    $('caVpTitulo').textContent = titulo; $('caVpCancelar').disabled = false; $('caVpCancelar').textContent = 'Cancelar';
    $('caVpEtapa').textContent = ''; $('caVpRelleno').style.width = '0%'; $('caVpPct').textContent = ''; $('caVideoProg').hidden = false;
  }
  function etapa(texto, fraccion){
    $('caVpEtapa').textContent = texto;
    if(fraccion !== undefined){ const p = Math.max(0, Math.min(1, fraccion)); $('caVpRelleno').style.width = (p * 100).toFixed(1) + '%'; $('caVpPct').textContent = Math.floor(p * 100) + ' %'; }
  }
  const ocultar = () => { $('caVideoProg').hidden = true; const v = $('caVpVista'); v.textContent = ''; };
  const comprobar = () => { if(cancelar) throw CANCELADO; };

  /* ---------- Exportar ---------- */
  async function exportar(o){
    if(enCurso) return;
    const C = NS.Cascada;
    if(!C.hayCancion()){ NS.Studio.toast('No hay nada que animar todavía.'); return; }
    if(!hayWebCodecs()){ $('caMensaje').textContent = 'Este dispositivo no puede crear vídeos: actualiza «Android System WebView» (o Chrome) desde Play Store y vuelve a intentarlo.'; return; }
    enCurso = true; cancelar = false;
    NS.Storage.set('cascadaVideo', o);
    const m = medidas(o), fps = o.fps, nombre = nombreSeguro(C.nombreCancion()) + '.mp4';
    let render = null, codVideo = null, codAudio = null, pantalla = null, notas = [], error = null;
    mostrar('Creando vídeo'); etapa('Preparando…', 0);
    try{
      try{ if(navigator.wakeLock) pantalla = await navigator.wakeLock.request('screen'); }catch(e){}   // que la pantalla no se apague mientras trabaja
      const video = await elegirVideo(m, fps), audio = await elegirAudio();
      if(!video) throw new Error('Este dispositivo no puede codificar vídeo con esta calidad. Prueba con 720p o 30 fps.');
      if(!audio) throw new Error('Este dispositivo no puede codificar el audio del vídeo.');
      if(video.tipo === 'vp9') notas.push('vídeo VP9');
      if(audio.tipo === 'opus') notas.push('audio Opus');
      NS.Player.stop(); NS.Studio.stop(); C.detener();

      const lienzo = document.createElement('canvas');
      render = C.paraVideo({lienzo, ancho:m.ancho, alto:m.alto, ratio:m.ratio});
      if(!render) throw new Error('No hay nada que animar todavía.');
      lienzo.style.cssText = 'max-width:100%;max-height:26vh;border-radius:8px;display:block;margin:0 auto';
      $('caVpVista').replaceChildren(lienzo);
      const muxer = NS.Mp4.crear();
      let descVideo = null, descAudio = null;

      /* 1) Audio completo (render sin conexion, igual que el WAV del Estudio) */
      etapa('Creando el audio…', 0.02); await esperar(30);
      const ad = render.audio();
      const bufer = (await NS.Audio.render(ad.specs, ad.notas, render.duracion, ad.maestro, FRECUENCIA_AUDIO, ad.general)).get();
      comprobar();

      /* 2) Fotogramas de video */
      codVideo = new VideoEncoder({
        output:(trozo, meta) => {
          const d = new Uint8Array(trozo.byteLength); trozo.copyTo(d);
          if(!descVideo && meta && meta.decoderConfig && meta.decoderConfig.description) descVideo = aBytes(meta.decoderConfig.description).slice();
          muxer.muestra('video', d, trozo.timestamp, trozo.duration || Math.round(1e6 / fps), trozo.type === 'key');
        },
        error:e => { error = e; }
      });
      codVideo.configure(video.cfg);
      const total = Math.ceil(render.duracion * fps), inicio = performance.now();
      for(let i = 0; i < total; i++){
        comprobar(); if(error) throw error;
        render.dibujar(i / fps, 1 / fps);
        const fotograma = new VideoFrame(lienzo, {timestamp:Math.round(i * 1e6 / fps), duration:Math.round(1e6 / fps)});
        codVideo.encode(fotograma, {keyFrame:i % (fps * 2) === 0}); fotograma.close();
        while(codVideo.encodeQueueSize > ATRAS_MAXIMO){ await esperar(4); comprobar(); if(error) throw error; }
        if(i % 6 === 5 || i === total - 1){
          const hecho = (i + 1) / total, seg = (performance.now() - inicio) / 1000, falta = hecho > 0.03 ? Math.round(seg / hecho - seg) : null;
          etapa('Dibujando fotogramas ' + (i + 1) + ' de ' + total + (falta !== null ? ' · faltan ~' + (falta >= 60 ? Math.ceil(falta / 60) + ' min' : falta + ' s') : ''), 0.05 + 0.8 * hecho);
          await esperar(0);                                          // deja respirar a la pantalla (barra de progreso, boton Cancelar)
        }
      }
      etapa('Terminando el vídeo…', 0.86); await codVideo.flush(); comprobar(); if(error) throw error;
      codVideo.close(); codVideo = null;
      if(!descVideo && video.tipo === 'avc') throw new Error('El codificador no entregó los datos de configuración del vídeo.');

      /* 3) Audio codificado */
      codAudio = new AudioEncoder({
        output:(trozo, meta) => {
          const d = new Uint8Array(trozo.byteLength); trozo.copyTo(d);
          if(!descAudio && meta && meta.decoderConfig && meta.decoderConfig.description) descAudio = aBytes(meta.decoderConfig.description).slice();
          muxer.muestra('audio', d, trozo.timestamp, trozo.duration || Math.round(1024 * 1e6 / FRECUENCIA_AUDIO), true);
        },
        error:e => { error = e; }
      });
      codAudio.configure(audio.cfg);
      const canales = Math.min(2, bufer.numberOfChannels), datos = []; for(let c = 0; c < canales; c++) datos.push(bufer.getChannelData(c));
      const BLOQUE = 4096;
      for(let i = 0; i < bufer.length; i += BLOQUE){
        comprobar(); if(error) throw error;
        const n = Math.min(BLOQUE, bufer.length - i), plano = new Float32Array(n * canales);
        for(let c = 0; c < canales; c++) plano.set(datos[c].subarray(i, i + n), c * n);
        const trozo = new AudioData({format:'f32-planar', sampleRate:bufer.sampleRate, numberOfFrames:n, numberOfChannels:canales, timestamp:Math.round(i * 1e6 / bufer.sampleRate), data:plano});
        codAudio.encode(trozo); trozo.close();
        while(codAudio.encodeQueueSize > 24){ await esperar(2); comprobar(); if(error) throw error; }
        if(i % (BLOQUE * 40) === 0){ etapa('Codificando el audio…', 0.88 + 0.08 * (i / bufer.length)); await esperar(0); }
      }
      await codAudio.flush(); comprobar(); if(error) throw error;
      codAudio.close(); codAudio = null;

      /* 4) Empaquetar y entregar */
      etapa('Guardando el archivo…', 0.97); await esperar(30);
      const blob = muxer.terminar({
        video:{codec:video.tipo, ancho:m.w, alto:m.h, descripcion:descVideo, codecVp9:video.codec},
        audio:{codec:audio.tipo, frecuencia:FRECUENCIA_AUDIO, canales, descripcion:descAudio || (audio.tipo === 'aac' ? descripcionAac(FRECUENCIA_AUDIO, canales) : descripcionOpus(FRECUENCIA_AUDIO, canales))}
      });
      render.cerrar(); render = null; ocultar();
      const r = await NS.RhythmCore.deliver({name:nombre, mime:'video/mp4', blob});
      const mb = (blob.size / 1048576).toFixed(1) + ' MB';
      if(!r.ok) $('caMensaje').textContent = r.msg || 'No se pudo guardar el vídeo.';
      else if(!r.canceled){ $('caMensaje').textContent = 'Listo: ' + nombre + ' (' + mb + ')' + (r.where ? ' · guardado en ' + r.where : '') + (notas.length ? ' · ' + notas.join(', ') + ': algunos reproductores antiguos no lo abren' : ''); NS.Studio.toast('Vídeo listo: ' + nombre + (r.where ? ' · en ' + r.where : '')); }
      else $('caMensaje').textContent = '';
    }catch(e){
      if(e === CANCELADO) $('caMensaje').textContent = 'Exportación cancelada.';
      else{ console.error(e); $('caMensaje').textContent = 'No se pudo crear el vídeo: ' + (e && e.message ? e.message : e); }
    }finally{
      for(const c of [codVideo, codAudio]) try{ if(c && c.state !== 'closed') c.close(); }catch(e){}
      if(render) render.cerrar();
      try{ if(pantalla) pantalla.release(); }catch(e){}
      ocultar(); enCurso = false;
    }
  }

  /* ---------- Ventana de opciones ---------- */
  function filaOpciones(box, titulo, lista, actual, alElegir){
    const et = document.createElement('label'); et.className = 'stLbl'; et.textContent = titulo;
    const seg = document.createElement('div'); seg.className = 'seg';
    lista.forEach(([valor, texto]) => {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = texto; b.classList.toggle('sel', valor === actual);
      b.addEventListener('click', () => { alElegir(valor); [...seg.children].forEach(x => x.classList.toggle('sel', x === b)); });
      seg.appendChild(b);
    });
    box.append(et, seg);
  }
  function abrir(){
    if(enCurso) return;
    if(!NS.Cascada.hayCancion()){ NS.Studio.toast('No hay nada que animar todavía.'); return; }
    const o = {resolucion:ajustes.resolucion, fps:ajustes.fps, forma:ajustes.forma};
    NS.Sheet.open('Descargar vídeo MP4', 'Crear vídeo', box => {
      filaOpciones(box, 'Calidad', OPC_RESOLUCION, o.resolucion, v => { o.resolucion = v; });
      filaOpciones(box, 'Fluidez', OPC_FPS, o.fps, v => { o.fps = v; });
      filaOpciones(box, 'Formato', OPC_FORMA, o.forma, v => { o.forma = v; });
      const nota = document.createElement('p'); nota.className = 'small';
      nota.textContent = 'El vídeo incluye la animación y la música tal como suenan aquí (con la velocidad y las pistas visibles que tengas elegidas). Tarda un poco: mantén la app abierta mientras lo crea.';
      box.appendChild(nota);
    }, () => { Object.assign(ajustes, o); setTimeout(() => exportar(o), 50); });
  }

  $('caVideo').addEventListener('click', abrir);
  $('caVpCancelar').addEventListener('click', () => { cancelar = true; $('caVpCancelar').disabled = true; $('caVpCancelar').textContent = 'Cancelando…'; });
  NS.CascadaVideo = {abrir, cancelar:() => { cancelar = true; }, exportar};
})(window.NS = window.NS || {});
