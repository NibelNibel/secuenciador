/* Estudio — sección «Mezcla»: todas las pistas en una sola pantalla.
   Nibel: cada pista es una tira con su medidor de volumen, su luz de saturacion (clipping), su fader de volumen, balance, ganancia, silencio, solo y efectos.
   A la derecha esta la tira del volumen total, con el medidor de la mezcla completa y la luz del limitador. */
(function(NS){
  'use strict';
  const ST = NS.Studio, M = NS.Mezcla, $ = id => document.getElementById(id);
  const panel = $('stMezclador'), contenedorTiras = $('stMezTiras'), contenedorMaestro = $('stMezMaestro');
  const cajaAviso = $('stMezAviso'), textoAviso = $('stMezTexto'), textoDetalle = $('stMezDetalle'), panelFx = $('stMezFx');

  const ESCALA_MIN = -40, ESCALA_MAX = 6;       // Nibel: el medidor y el fader usan la misma escala, asi el 0 dB queda a la misma altura
  const PISO_DB = -100;
  const DB_RECORTE = -0.1;                      // Nibel: desde aqui se considera que el sonido toca el techo (saturacion)
  const LINEAL_RECORTE = Math.pow(10, DB_RECORTE / 20);
  const DB_CERCA = -3;                          // Nibel: cerca del techo, el numero se pone en alerta
  const CAIDA_MEDIDOR = 30;                     // dB que baja la barra por segundo
  const CAIDA_MARCA = 14;                       // dB que baja la rayita del pico por segundo (despues de esperar)
  const ESPERA_MARCA = 1.2;                     // segundos que la rayita del pico se queda quieta
  const REDUCCION_LIMITADOR = -0.5;             // dB: desde aqui se enciende la luz del limitador
  const PAUSA_DOBLE_TOQUE = 320;                // milisegundos para que dos toques cuenten como doble toque

  const aDb = v => (v > 1e-5 ? 20 * Math.log10(v) : PISO_DB);
  const posicion = db => Math.max(0, Math.min(1, (db - ESCALA_MIN) / (ESCALA_MAX - ESCALA_MIN)));
  const signo = v => (v > 0 ? '+' : v < 0 ? '−' : '');
  const fmtPico = db => (db <= -90 ? '−∞' : signo(Math.round(db * 10) / 10) + Math.abs(Math.round(db * 10) / 10).toFixed(1));
  const fmtVol = v => (v <= ST.MINDB ? '−∞' : signo(v) + Math.abs(v) + ' dB');
  const fmtPan = v => (Math.abs(v) < 0.025 ? 'Centro' : Math.round(Math.abs(v) * 100) + (v < 0 ? ' I' : ' D'));
  const fmtGan = v => signo(v) + Math.abs(v) + ' dB';
  const fmtPorcentaje = v => Math.round(v * 100) + ' %';
  const escapar = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;'}[c]));

  /* ---------- Estado de cada medidor (lo que se ve, no el audio) ---------- */
  const estados = new Map();                    // id de pista (o 'maestro') -> estado
  const nuevoEstado = () => ({mostrado:[PISO_DB, PISO_DB], marca:[PISO_DB, PISO_DB], espera:[0, 0], picoMax:PISO_DB, tieneRecorte:false});
  const estadoDe = id => { if(!estados.has(id)) estados.set(id, nuevoEstado()); return estados.get(id); };
  const reiniciarEstado = id => estados.set(id, nuevoEstado());

  // Nibel: la barra sube de golpe y baja despacio; la rayita del pico se queda un rato y luego cae
  function avanzar(estado, nivel, dt){
    for(let c = 0; c < 2; c++){
      const db = aDb(nivel.pico[c]);
      estado.mostrado[c] = Math.max(db, estado.mostrado[c] - CAIDA_MEDIDOR * dt);
      if(db >= estado.marca[c]){ estado.marca[c] = db; estado.espera[c] = 0; }
      else{
        estado.espera[c] += dt;
        if(estado.espera[c] > ESPERA_MARCA) estado.marca[c] = Math.max(PISO_DB, estado.marca[c] - CAIDA_MARCA * dt);
      }
      if(db > estado.picoMax) estado.picoMax = db;
      if(nivel.pico[c] >= LINEAL_RECORTE) estado.tieneRecorte = true;
    }
  }

  /* ---------- Dibujo de una tira ---------- */
  const refs = new Map();                       // id de pista -> elementos de su tira
  let refsMaestro = null, firmaTiras = '', fxAbierto = null;   // fxAbierto: id de pista, 'general' o null

  function htmlMedidorYFader(){
    return '<div class="mzCuerpo">' +
      '<div class="mzMedidor"><i class="mzBarra"><b class="mzRelleno"></b><u class="mzMarca" hidden></u></i><i class="mzBarra"><b class="mzRelleno"></b><u class="mzMarca" hidden></u></i></div>' +
      '<div class="mzFader" role="slider" tabindex="0" aria-label="Volumen" aria-valuemin="' + ESCALA_MIN + '" aria-valuemax="' + ESCALA_MAX + '" aria-valuenow="0"><i class="mzRiel"></i><i class="mzPomo"></i></div>' +
      '</div>';
  }
  function htmlTira(p){
    return '<div class="mzTira" data-id="' + p.id + '" style="--c:' + p.color + '">' +
      '<button class="mzNombre" data-a="sel" title="Elegir esta pista en el Roll"></button>' +
      '<button class="mzClip" data-a="clip" title="Pico mas alto de esta pista. Toca para reiniciarlo."><b>CLIP</b><i>−∞</i></button>' +
      htmlMedidorYFader() +
      '<div class="mzVal"><span>0 dB</span><em hidden title="Esta pista tiene volumen automatizado: mientras suena manda la curva">auto</em></div>' +
      '<div class="mzMini"><span data-e="pan">Centro</span><input type="range" min="-1" max="1" step="0.05" value="0" data-k="pan" aria-label="Balance"></div>' +
      '<div class="mzMini"><span data-e="gan">Gan 0 dB</span><input type="range" min="' + M.GANANCIA_MIN + '" max="' + M.GANANCIA_MAX + '" step="0.5" value="0" data-k="gan" aria-label="Ganancia de entrada"></div>' +
      '<div class="mzMS"><button class="btn sm" data-a="mute" aria-label="Silenciar" title="Silenciar esta pista">M</button><button class="btn sm" data-a="solo" aria-label="Solo" title="Escuchar solo esta pista">S</button></div>' +
      '<button class="btn sm mzFxBtn" data-a="fx" title="Efectos de esta pista">FX</button>' +
      '</div>';
  }
  function tomarRefs(raiz){
    return {
      raiz, rellenos:[...raiz.querySelectorAll('.mzRelleno')], marcas:[...raiz.querySelectorAll('.mzMarca')],
      lampara:raiz.querySelector('.mzClip'), numero:raiz.querySelector('.mzClip i'), fader:raiz.querySelector('.mzFader'), pomo:raiz.querySelector('.mzPomo'),
      valor:raiz.querySelector('.mzVal span'), etiquetaAuto:raiz.querySelector('.mzVal em'), nombre:raiz.querySelector('.mzNombre'),
      pan:raiz.querySelector('[data-k="pan"]'), gan:raiz.querySelector('[data-k="gan"]'), etPan:raiz.querySelector('[data-e="pan"]'), etGan:raiz.querySelector('[data-e="gan"]'),
      botonM:raiz.querySelector('[data-a="mute"]'), botonS:raiz.querySelector('[data-a="solo"]'), botonFx:raiz.querySelector('[data-a="fx"]'),
      limitador:raiz.querySelector('.mzLim'), textoLimitador:raiz.querySelector('.mzLim i'),
      cache:{p:[-1, -1], q:[-1, -1], texto:'', alerta:-1, limitador:-1}
    };
  }

  function construir(){
    refs.clear();
    contenedorTiras.innerHTML = ST.tracks.map(htmlTira).join('');
    ST.tracks.forEach(p => refs.set(p.id, tomarRefs(contenedorTiras.querySelector('.mzTira[data-id="' + p.id + '"]'))));
    firmaTiras = firmaDe();
  }
  function construirMaestro(){
    contenedorMaestro.innerHTML = '<div class="mzTira mzMaestro" data-id="maestro">' +
      '<div class="mzNombre fijo">Total</div>' +
      '<button class="mzClip" data-a="clip" title="Pico mas alto de la mezcla completa, antes del limitador. Toca para reiniciarlo."><b>CLIP</b><i>−∞</i></button>' +
      htmlMedidorYFader() +
      '<div class="mzVal"><span>0 dB</span></div>' +
      '<div class="mzLim" title="Se enciende cuando el limitador esta bajando el volumen para proteger la salida"><b>LIM</b><i></i></div>' +
      '<button class="btn sm mzFxBtn" data-a="fx" title="Efectos de toda la cancion">FX general</button>' +
      '</div>';
    refsMaestro = tomarRefs(contenedorMaestro.querySelector('.mzTira'));
    refsMaestro.fader.setAttribute('aria-label', 'Volumen total');
  }
  const firmaDe = () => ST.tracks.map(p => p.id + ':' + p.color).join('|');

  function ponerFader(r, db){
    const p = posicion(db);
    r.pomo.style.bottom = (p * 100).toFixed(2) + '%';
    r.fader.setAttribute('aria-valuenow', String(db)); r.fader.setAttribute('aria-valuetext', fmtVol(db));
    r.valor.textContent = fmtVol(db);
  }

  // Nibel: pone la pantalla al dia con lo que hay en el Estudio (sin tocar lo que el dedo esta moviendo)
  function sincronizar(){
    if(firmaDe() !== firmaTiras) construir();
    const activo = document.activeElement;
    ST.tracks.forEach(p => {
      const r = refs.get(p.id); if(!r) return;
      r.raiz.classList.toggle('cur', p.id === ST.curId);
      r.raiz.classList.toggle('muda', !ST.audible(p));
      if(r.nombre.textContent !== p.name) r.nombre.textContent = p.name;
      r.botonM.classList.toggle('on', !!p.mute); r.botonS.classList.toggle('on', !!p.solo);
      r.botonFx.classList.toggle('tiene', M.hayEfectos(p.fx));
      r.etiquetaAuto.hidden = !NS.Auto.hay(p.auto, 'vol');
      if(!enArrastre || enArrastre.id !== p.id) ponerFader(r, p.vol);
      if(activo !== r.pan){ r.pan.value = p.pan; }
      if(activo !== r.gan){ r.gan.value = p.gan; }
      r.etPan.textContent = fmtPan(p.pan); r.etGan.textContent = 'Gan ' + fmtGan(p.gan);
    });
    if(!refsMaestro) construirMaestro();
    if(!enArrastre || enArrastre.id !== 'maestro') ponerFader(refsMaestro, ST.master());
    refsMaestro.botonFx.classList.toggle('tiene', M.hayGeneral(ST.general()));
    if(fxAbierto !== null && fxAbierto !== 'general' && !ST.trackById(fxAbierto)){ fxAbierto = null; refrescarFx(); }
    marcarFxAbierto();
  }

  /* ---------- Medidores: dibujo ---------- */
  function pintarMedidor(r, estado){
    const c = r.cache;
    for(let k = 0; k < 2; k++){
      const p = posicion(estado.mostrado[k]), q = posicion(estado.marca[k]);
      if(Math.abs(p - c.p[k]) > 0.004){ r.rellenos[k].style.clipPath = 'inset(' + ((1 - p) * 100).toFixed(1) + '% 0 0 0)'; c.p[k] = p; }
      if(Math.abs(q - c.q[k]) > 0.004){
        r.marcas[k].hidden = q <= 0.01;
        r.marcas[k].style.bottom = (q * 100).toFixed(1) + '%'; c.q[k] = q;
      }
    }
    const texto = fmtPico(estado.picoMax);
    if(texto !== c.texto){ r.numero.textContent = texto; c.texto = texto; }
    const alerta = estado.tieneRecorte ? 2 : (estado.picoMax >= DB_CERCA ? 1 : 0);
    if(alerta !== c.alerta){ r.lampara.dataset.nivel = String(alerta); c.alerta = alerta; }
  }
  function pintarLimitador(reduccion){
    const r = refsMaestro, encendido = reduccion <= REDUCCION_LIMITADOR ? 1 : 0;
    if(encendido !== r.cache.limitador){ r.limitador.classList.toggle('on', !!encendido); r.cache.limitador = encendido; }
    r.textoLimitador.textContent = encendido ? Math.round(reduccion) + ' dB' : '';
  }

  /* ---------- Aviso general ---------- */
  let ultimoAviso = '';
  function pintarAviso(){
    const saturadas = ST.tracks.filter(p => estadoDe(p.id).tieneRecorte).map(p => p.name || 'Pista');
    const maestro = estadoDe('maestro'), conSonido = ST.tracks.filter(p => estadoDe(p.id).picoMax > -60);
    let tipo = 'ok', texto = '', detalle = '';
    if(maestro.tieneRecorte){
      tipo = 'mal'; texto = 'La mezcla total pasa de 0 dB y el limitador la aplasta. Baja el volumen de las pistas mas fuertes o el volumen total.';
      if(saturadas.length) detalle = 'Pistas que saturan: ' + saturadas.join(', ') + '.';
    }else if(saturadas.length){
      tipo = 'mal'; texto = 'Saturan: ' + saturadas.join(', ') + '. Baja su volumen o su ganancia.';
    }else if(maestro.picoMax >= DB_CERCA || conSonido.some(p => estadoDe(p.id).picoMax >= DB_CERCA)){
      tipo = 'aviso'; texto = 'Hay picos cerca del limite. Si suenan duros, baja un poco el volumen.';
    }else if(!conSonido.length){
      texto = 'Pulsa ▶ para ver los niveles de cada pista.';
    }else{
      texto = 'Todo en orden: ningun pico llega al limite.';
    }
    if(conSonido.length > 1){
      const masFuerte = conSonido.reduce((a, b) => (estadoDe(b.id).picoMax > estadoDe(a.id).picoMax ? b : a));
      if(!detalle) detalle = 'Pista mas fuerte: ' + (masFuerte.name || 'Pista') + ' (' + fmtPico(estadoDe(masFuerte.id).picoMax) + ' dB).';
    }
    const firma = tipo + '|' + texto + '|' + detalle;
    if(firma === ultimoAviso) return;
    ultimoAviso = firma;
    cajaAviso.dataset.tipo = tipo; textoAviso.textContent = texto; textoDetalle.textContent = detalle; textoDetalle.hidden = !detalle;
  }

  // Nibel: obliga a que el proximo cuadro vuelva a dibujar todo lo de esa tira
  function olvidarDibujo(r){ if(r){ r.cache.texto = ''; r.cache.alerta = -1; r.cache.p = [-1, -1]; r.cache.q = [-1, -1]; } }
  function reiniciarPicos(){
    estados.clear(); ultimoAviso = '';
    refs.forEach(olvidarDibujo); olvidarDibujo(refsMaestro);
    pintarAviso();
  }

  /* ---------- Bucle de dibujo: solo corre mientras la seccion esta a la vista ---------- */
  let idCuadro = 0, ultimoTiempo = 0, estaVisible = false, estadoTransporte = 'stopped', contadorCuadros = 0;
  function cuadro(ahora){
    idCuadro = 0;
    if(!estaVisible) return;
    try{
      const dt = Math.min(0.1, Math.max(0.001, (ahora - ultimoTiempo) / 1000)); ultimoTiempo = ahora;
      const transporte = window.Tone.Transport.state;
      if(transporte === 'started' && estadoTransporte === 'stopped') reiniciarPicos();   // Nibel: al empezar desde cero, los picos viejos ya no sirven
      estadoTransporte = transporte;
      ST.tracks.forEach(p => {
        const r = refs.get(p.id); if(!r) return;
        const estado = estadoDe(p.id); avanzar(estado, p.audio.nivel(), dt); pintarMedidor(r, estado);
      });
      const estadoMaestro = estadoDe('maestro'); avanzar(estadoMaestro, NS.Audio.nivelMaestro(), dt); pintarMedidor(refsMaestro, estadoMaestro);
      pintarLimitador(NS.Audio.reduccionLimitador());
      if(++contadorCuadros % 6 === 0) pintarAviso();
    }catch(e){ console.error(e); }
    idCuadro = requestAnimationFrame(cuadro);
  }
  function iniciarBucle(){ if(idCuadro || !estaVisible) return; ultimoTiempo = performance.now(); idCuadro = requestAnimationFrame(cuadro); }
  function detenerBucle(){ if(idCuadro) cancelAnimationFrame(idCuadro); idCuadro = 0; }
  if('IntersectionObserver' in window){
    new IntersectionObserver(entradas => {
      estaVisible = entradas[entradas.length - 1].isIntersecting;
      if(estaVisible){ sincronizar(); pintarAviso(); iniciarBucle(); } else detenerBucle();
    }).observe(panel);
  }

  /* ---------- Faders de volumen (pista y total) ---------- */
  let enArrastre = null, ultimoToque = {id:null, hora:0};
  function dbDeFader(fader, y){
    const caja = fader.getBoundingClientRect(), fraccion = Math.max(0, Math.min(1, 1 - (y - caja.top) / caja.height));
    let db = Math.round(ESCALA_MIN + fraccion * (ESCALA_MAX - ESCALA_MIN));   // Nibel: pasos de 1 dB
    if(Math.abs(db) <= 1) db = 0;                                             // Nibel: iman en 0 dB
    if(db <= ESCALA_MIN + 1) db = ESCALA_MIN;                                 // Nibel: el fondo es silencio
    return db;
  }
  function aplicarVolumen(id, db){
    if(id === 'maestro'){ ST.setMaster(db); ponerFader(refsMaestro, db); return; }
    const p = ST.trackById(+id), r = refs.get(+id); if(!p || !r) return;
    p.vol = db; p.audio.setVol(db); ST.changed(); ponerFader(r, db);
  }
  const idDeTira = el => { const t = el.closest('.mzTira'); return t.dataset.id === 'maestro' ? 'maestro' : +t.dataset.id; };

  function enlazarFaders(contenedor){
    contenedor.addEventListener('pointerdown', e => {
      const fader = e.target.closest('.mzFader'); if(!fader) return;
      const id = idDeTira(fader), ahora = Date.now();
      if(ultimoToque.id === id && ahora - ultimoToque.hora < PAUSA_DOBLE_TOQUE){        // Nibel: doble toque = volver a 0 dB
        ultimoToque = {id:null, hora:0}; aplicarVolumen(id, 0); e.preventDefault(); return;
      }
      ultimoToque = {id, hora:ahora};
      enArrastre = {id, fader, pointerId:e.pointerId};
      try{ fader.setPointerCapture(e.pointerId); }catch(x){}
      aplicarVolumen(id, dbDeFader(fader, e.clientY)); e.preventDefault();
    });
    contenedor.addEventListener('pointermove', e => {
      if(!enArrastre || enArrastre.pointerId !== e.pointerId) return;
      aplicarVolumen(enArrastre.id, dbDeFader(enArrastre.fader, e.clientY));
    });
    const soltar = e => { if(enArrastre && enArrastre.pointerId === e.pointerId) enArrastre = null; };
    contenedor.addEventListener('pointerup', soltar); contenedor.addEventListener('pointercancel', soltar);
    contenedor.addEventListener('keydown', e => {                                        // Nibel: con teclado, flechas de 1 dB y Re Pag / Av Pag de 6 dB
      const fader = e.target.closest('.mzFader'); if(!fader) return;
      const paso = {ArrowUp:1, ArrowRight:1, ArrowDown:-1, ArrowLeft:-1, PageUp:6, PageDown:-6}[e.key]; if(!paso) return;
      const id = idDeTira(fader), actual = id === 'maestro' ? ST.master() : (ST.trackById(id) || {vol:0}).vol;
      aplicarVolumen(id, Math.max(ESCALA_MIN, Math.min(ESCALA_MAX, actual + paso))); e.preventDefault();
    });
  }
  enlazarFaders(contenedorTiras); enlazarFaders(contenedorMaestro);

  /* ---------- Botones y deslizadores de las tiras ---------- */
  function alPulsar(e){
    const boton = e.target.closest('[data-a]'); if(!boton || !boton.closest('.mzTira')) return;
    const id = idDeTira(boton), accion = boton.dataset.a;
    if(accion === 'clip'){ reiniciarEstado(id); olvidarDibujo(id === 'maestro' ? refsMaestro : refs.get(id)); ultimoAviso = ''; pintarAviso(); return; }
    if(accion === 'fx'){ abrirFx(id === 'maestro' ? 'general' : id); return; }
    const p = ST.trackById(id); if(!p) return;
    if(accion === 'sel') ST.selectTrack(id);
    else if(accion === 'mute'){ p.mute = !p.mute; if(p.mute) p.audio.silence(); ST.emit(); }
    else if(accion === 'solo'){ p.solo = !p.solo; ST.stopSound(); ST.emit(); }
  }
  contenedorTiras.addEventListener('click', alPulsar); contenedorMaestro.addEventListener('click', alPulsar);

  contenedorTiras.addEventListener('input', e => {
    const clave = e.target.dataset.k; if(!clave) return;
    const id = idDeTira(e.target), p = ST.trackById(id), r = refs.get(id); if(!p || !r) return;
    let v = +e.target.value;
    if(clave === 'pan'){
      if(Math.abs(v) < 0.08){ v = 0; e.target.value = '0'; }                // Nibel: iman al centro
      p.pan = v; p.audio.setPan(v); ST.changed(); r.etPan.textContent = fmtPan(v);
    }else{
      ST.setGanancia(id, v); r.etGan.textContent = 'Gan ' + fmtGan(p.gan);
    }
  });

  /* ---------- Panel de efectos (de una pista o de toda la cancion) ---------- */
  function filaFx(clave, nombre, ayuda, minimo, maximo, valor, formato){
    return '<div class="mzFila" title="' + escapar(ayuda) + '"><span>' + escapar(nombre) + '</span>' +
      '<input type="range" min="' + minimo + '" max="' + maximo + '" step="1" value="' + valor + '" data-fx="' + clave + '" aria-label="' + escapar(nombre) + '">' +
      '<span class="val">' + formato(valor) + '</span></div>';
  }
  const fmtCantidad = v => v + ' %';
  const fmtTono = v => signo(v) + Math.abs(v) + ' dB';

  function refrescarFx(){
    if(fxAbierto === null){ panelFx.hidden = true; panelFx.innerHTML = ''; return; }
    let titulo, filas, ayudas;
    if(fxAbierto === 'general'){
      const g = ST.general();
      titulo = 'Efectos de toda la canción';
      filas = M.EFECTOS_GENERALES.map(e => (e.tipo === 'tono'
        ? filaFx(e.id, e.nombre, e.ayuda, M.TONO_MIN, M.TONO_MAX, g[e.id], fmtTono)
        : filaFx(e.id, e.nombre, e.ayuda, 0, 100, Math.round(g[e.id] * 100), fmtCantidad))).join('');
      ayudas = M.EFECTOS_GENERALES.map(e => e.nombre + ': ' + e.ayuda);
      panelFx.style.setProperty('--c', 'var(--accent)');
    }else{
      const p = ST.trackById(fxAbierto);
      titulo = 'Efectos · ' + (p.name || 'Pista');
      filas = M.EFECTOS_PISTA.map(e => filaFx(e.id, e.nombre, e.ayuda, 0, 100, Math.round(p.fx[e.id] * 100), fmtCantidad)).join('');
      ayudas = M.EFECTOS_PISTA.map(e => e.nombre + ': ' + e.ayuda);
      panelFx.style.setProperty('--c', p.color);
    }
    panelFx.innerHTML = '<div class="mzFxCab"><b>' + escapar(titulo) + '</b>' +
      '<button class="btn sm" data-a="fxquitar" title="Poner todos los efectos en cero">Quitar</button>' +
      '<button class="btn sm" data-a="fxcerrar" aria-label="Cerrar efectos">✕</button></div>' + filas +
      '<p class="small">' + escapar(ayudas.join(' ')) + '</p>';
    panelFx.hidden = false;
  }
  function marcarFxAbierto(){
    refs.forEach((r, id) => r.botonFx.classList.toggle('abierto', fxAbierto === id));
    if(refsMaestro) refsMaestro.botonFx.classList.toggle('abierto', fxAbierto === 'general');
  }
  function abrirFx(destino){
    fxAbierto = fxAbierto === destino ? null : destino;
    refrescarFx(); marcarFxAbierto();
    if(fxAbierto !== null) setTimeout(() => { try{ panelFx.scrollIntoView({block:'nearest', behavior:'smooth'}); }catch(x){} }, 40);
  }
  panelFx.addEventListener('input', e => {
    const clave = e.target.dataset.fx; if(!clave || fxAbierto === null) return;
    const v = +e.target.value;
    if(fxAbierto === 'general'){
      ST.setGeneral(clave, clave === 'graves' || clave === 'agudos' ? v : v / 100);
      e.target.nextElementSibling.textContent = clave === 'graves' || clave === 'agudos' ? fmtTono(v) : fmtCantidad(v);
      refsMaestro.botonFx.classList.toggle('tiene', M.hayGeneral(ST.general()));
    }else{
      ST.setEfecto(fxAbierto, clave, v / 100);
      e.target.nextElementSibling.textContent = fmtCantidad(v);
      const r = refs.get(fxAbierto), p = ST.trackById(fxAbierto); if(r && p) r.botonFx.classList.toggle('tiene', M.hayEfectos(p.fx));
    }
  });
  panelFx.addEventListener('click', e => {
    const boton = e.target.closest('button'); if(!boton) return;
    if(boton.dataset.a === 'fxcerrar'){ fxAbierto = null; refrescarFx(); marcarFxAbierto(); }
    else if(boton.dataset.a === 'fxquitar'){
      if(fxAbierto === 'general') ST.quitarGeneral(); else ST.quitarEfectos(fxAbierto);
      refrescarFx(); sincronizar();
    }
  });

  $('stMezReiniciar').addEventListener('click', reiniciarPicos);

  /* ---------- Conexion con el resto del Estudio ---------- */
  ST.listeners.push(() => { if(estaVisible) sincronizar(); });
  (ST.subHooks = ST.subHooks || []).push(nombre => {
    if(nombre === 'mixer') sincronizar();                                                   // Nibel: al entrar, todo al dia
    if(!('IntersectionObserver' in window)){ estaVisible = nombre === 'mixer'; if(estaVisible) iniciarBucle(); else detenerBucle(); }   // Nibel: plan B sin IntersectionObserver
  });
  construirMaestro();
  NS.Mezclador = {reiniciarPicos, sincronizar};
})(window.NS = window.NS || {});
