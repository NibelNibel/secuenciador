/* Escritor MP4 mínimo, sin librerías: junta las muestras ya codificadas (vídeo H.264 o VP9, audio AAC u Opus)
   en un archivo .mp4 con el índice («moov») al principio, listo para reproducir o compartir.
   Uso:
     const m = NS.Mp4.crear();
     m.muestra('video', bytes, inicioMicros, duracionMicros, esClave);
     m.muestra('audio', bytes, inicioMicros, duracionMicros);
     const blob = m.terminar({video:{codec:'avc'|'vp9', ancho, alto, descripcion, codecVp9}, audio:{codec:'aac'|'opus', frecuencia, canales, descripcion}});
   `descripcion` es la que entrega WebCodecs en decoderConfig.description: avcC (H.264), AudioSpecificConfig (AAC) u OpusHead (Opus).
   Las muestras deben llegar en orden de reproducción dentro de cada pista (el codificador no usa fotogramas B). */
(function(NS){
  'use strict';
  const ESCALA_PELICULA = 1000, ESCALA_VIDEO = 90000, EPOCA_1904 = 2082844800;
  const MAXIMO_BYTES = 0xF0000000;                              // los desplazamientos son de 32 bits: por debajo de ~3,7 GB

  const u8 = (...v) => Uint8Array.from(v);
  const u16 = v => u8((v >>> 8) & 255, v & 255);
  const u32 = v => u8((v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255);
  const ascii = t => u8(...[...t].map(c => c.charCodeAt(0)));
  const ceros = n => new Uint8Array(n);
  function unir(partes){
    let total = 0; for(const p of partes) total += p.length;
    const salida = new Uint8Array(total); let o = 0;
    for(const p of partes){ salida.set(p, o); o += p.length; }
    return salida;
  }
  const caja = (tipo, ...partes) => { const cuerpo = unir(partes); return unir([u32(8 + cuerpo.length), ascii(tipo), cuerpo]); };
  const cajaCompleta = (tipo, version, banderas, ...partes) => caja(tipo, u8(version, (banderas >>> 16) & 255, (banderas >>> 8) & 255, banderas & 255), ...partes);
  const MATRIZ = unir([u32(0x10000), u32(0), u32(0), u32(0), u32(0x10000), u32(0), u32(0), u32(0), u32(0x40000000)]);
  // Longitud de un descriptor de «esds»: 7 bits por byte, el bit alto indica que sigue otro byte
  const longitudDescriptor = n => { const b = [n & 127]; while((n >>= 7) > 0) b.unshift((n & 127) | 128); return u8(...b); };
  const descriptor = (etiqueta, ...partes) => { const cuerpo = unir(partes); return unir([u8(etiqueta), longitudDescriptor(cuerpo.length), cuerpo]); };

  /* ---------- Tablas de muestras ---------- */
  // Devuelve [{n, delta}] agrupando duraciones iguales, y los tiempos en la escala de la pista
  function tiempos(muestras, escala){
    const ticks = muestras.map(m => Math.round(m.ts * escala / 1e6)), grupos = [];
    let fin = 0;
    muestras.forEach((m, k) => {
      const siguiente = k + 1 < muestras.length ? ticks[k + 1] : ticks[k] + Math.max(1, Math.round(m.dur * escala / 1e6));
      const delta = Math.max(1, siguiente - ticks[k]); fin += delta;
      const ultimo = grupos[grupos.length - 1];
      if(ultimo && ultimo.delta === delta) ultimo.n++; else grupos.push({n:1, delta});
    });
    return {grupos, duracion:fin};
  }
  function tablaMuestras(entrada, muestras, escala, desplazamientos, esVideo){
    const {grupos} = tiempos(muestras, escala);
    const stts = cajaCompleta('stts', 0, 0, u32(grupos.length), ...grupos.map(g => unir([u32(g.n), u32(g.delta)])));
    const stsc = cajaCompleta('stsc', 0, 0, u32(1), u32(1), u32(1), u32(1));         // una muestra por bloque
    const tamanos = new Uint8Array(muestras.length * 4), vt = new DataView(tamanos.buffer);
    muestras.forEach((m, k) => vt.setUint32(k * 4, m.datos.length));
    const stsz = cajaCompleta('stsz', 0, 0, u32(0), u32(muestras.length), tamanos);
    const posiciones = new Uint8Array(muestras.length * 4), vp = new DataView(posiciones.buffer);
    muestras.forEach((m, k) => vp.setUint32(k * 4, desplazamientos.get(m)));
    const stco = cajaCompleta('stco', 0, 0, u32(muestras.length), posiciones);
    const partes = [cajaCompleta('stsd', 0, 0, u32(1), entrada), stts];
    if(esVideo){
      const claves = []; muestras.forEach((m, k) => { if(m.clave) claves.push(k + 1); });
      if(claves.length < muestras.length) partes.push(cajaCompleta('stss', 0, 0, u32(claves.length), ...claves.map(u32)));
    }
    partes.push(stsc, stsz, stco);
    return caja('stbl', ...partes);
  }

  /* ---------- Entradas de muestra ---------- */
  function entradaVideo(v){
    const cabecera = unir([ceros(6), u16(1), ceros(16), u16(v.ancho), u16(v.alto), u32(0x480000), u32(0x480000), u32(0), u16(1), ceros(32), u16(0x18), u16(0xFFFF)]);
    if(v.codec === 'avc') return caja('avc1', cabecera, caja('avcC', v.descripcion));
    const m = /^vp09\.(\d+)\.(\d+)\.(\d+)/.exec(v.codecVp9 || 'vp09.00.41.08') || [0, '0', '41', '08'];
    const vpcC = cajaCompleta('vpcC', 1, 0, u8(+m[1], +m[2], ((+m[3]) << 4) | (1 << 1), 1, 1, 1), u16(0));   // 4:2:0, colores BT.709, rango limitado
    return caja('vp09', cabecera, vpcC);
  }
  function entradaAudio(a){
    const cabecera = unir([ceros(6), u16(1), ceros(8), u16(a.canales), u16(16), u16(0), u16(0), u32((a.frecuencia * 65536) >>> 0)]);
    if(a.codec === 'aac'){
      const esds = cajaCompleta('esds', 0, 0, descriptor(0x03, u16(0), u8(0),
        descriptor(0x04, u8(0x40, 0x15), u8(0, 0, 0), u32(0), u32(0), descriptor(0x05, a.descripcion)),
        descriptor(0x06, u8(0x02))));
      return caja('mp4a', cabecera, esds);
    }
    const d = a.descripcion, dv = new DataView(d.buffer, d.byteOffset, d.byteLength);       // OpusHead (little-endian) → dOps (big-endian)
    const dOps = caja('dOps', u8(0, a.canales), u16(dv.getUint16(10, true)), u32(dv.getUint32(12, true)), u16(dv.getUint16(16, true)), u8(d[18] || 0));
    return caja('Opus', cabecera, dOps);
  }

  /* ---------- Pistas ---------- */
  function pista(id, esVideo, muestras, info, desplazamientos, ahora){
    const escala = esVideo ? ESCALA_VIDEO : info.frecuencia, t = tiempos(muestras, escala);
    const duracionPelicula = Math.round(t.duracion * ESCALA_PELICULA / escala);
    const tkhd = cajaCompleta('tkhd', 0, 7, u32(ahora), u32(ahora), u32(id), u32(0), u32(duracionPelicula), ceros(8), u16(0), u16(0),
      u16(esVideo ? 0 : 0x100), u16(0), MATRIZ, u32(esVideo ? info.ancho * 65536 : 0), u32(esVideo ? info.alto * 65536 : 0));
    const mdhd = cajaCompleta('mdhd', 0, 0, u32(ahora), u32(ahora), u32(escala), u32(t.duracion), u16(0x55C4), u16(0));
    const hdlr = cajaCompleta('hdlr', 0, 0, u32(0), ascii(esVideo ? 'vide' : 'soun'), ceros(12), ascii(esVideo ? 'Video\0' : 'Audio\0'));
    const medio = esVideo ? cajaCompleta('vmhd', 0, 1, u16(0), u16(0), u16(0), u16(0)) : cajaCompleta('smhd', 0, 0, u16(0), u16(0));
    const dinf = caja('dinf', cajaCompleta('dref', 0, 0, u32(1), cajaCompleta('url ', 0, 1)));
    const stbl = tablaMuestras(esVideo ? entradaVideo(info) : entradaAudio(info), muestras, escala, desplazamientos, esVideo);
    return {duracionPelicula, caja:caja('trak', tkhd, caja('mdia', mdhd, hdlr, caja('minf', medio, dinf, stbl)))};
  }

  function crear(){
    const pistas = {video:[], audio:[]};
    return {
      muestra(tipo, datos, ts, dur, esClave){ pistas[tipo].push({datos, ts, dur:dur || 0, clave:!!esClave}); },
      cantidad(tipo){ return pistas[tipo].length; },
      terminar(info){
        const lista = [];
        if(pistas.video.length) lista.push({id:1, esVideo:true, muestras:pistas.video, info:info.video});
        if(pistas.audio.length) lista.push({id:lista.length + 1, esVideo:false, muestras:pistas.audio, info:info.audio});
        if(!lista.length) throw new Error('No hay nada que guardar.');
        for(const p of lista) if(!p.info) throw new Error('Faltan los datos de la pista.');
        // Orden de las muestras dentro del archivo: por tiempo, mezclando vídeo y audio
        const orden = [];
        for(const p of lista) for(const m of p.muestras) orden.push(m);
        orden.sort((a, b) => a.ts - b.ts || (b.datos.length - a.datos.length));
        let bytesDatos = 0; for(const m of orden) bytesDatos += m.datos.length;
        const ahora = Math.floor(Date.now() / 1000) + EPOCA_1904;
        const ftyp = caja('ftyp', ascii('isom'), u32(512), ascii('isom'), ascii('iso2'), ascii('avc1'), ascii('mp41'));
        const construirMoov = base => {                              // base = posición del primer byte de datos dentro del archivo
          const desplazamientos = new Map(); let pos = base;
          for(const m of orden){ desplazamientos.set(m, pos); pos += m.datos.length; }
          const trak = lista.map(p => pista(p.id, p.esVideo, p.muestras, p.info, desplazamientos, ahora));
          const duracion = Math.max(...trak.map(t => t.duracionPelicula));
          const mvhd = cajaCompleta('mvhd', 0, 0, u32(ahora), u32(ahora), u32(ESCALA_PELICULA), u32(duracion), u32(0x10000), u16(0x100), ceros(10), MATRIZ, ceros(24), u32(lista.length + 1));
          return caja('moov', mvhd, ...trak.map(t => t.caja));
        };
        const tamanoMoov = construirMoov(0).length;                  // el tamaño no depende de los desplazamientos
        const inicioDatos = ftyp.length + tamanoMoov + 8;
        if(inicioDatos + bytesDatos > MAXIMO_BYTES) throw new Error('El vídeo es demasiado grande. Prueba con menos calidad.');
        const moov = construirMoov(inicioDatos);
        const cabeceraMdat = unir([u32(8 + bytesDatos), ascii('mdat')]);
        return new Blob([ftyp, moov, cabeceraMdat, ...orden.map(m => m.datos)], {type:'video/mp4'});
      }
    };
  }

  NS.Mp4 = {crear};
})(window.NS = window.NS || {});
