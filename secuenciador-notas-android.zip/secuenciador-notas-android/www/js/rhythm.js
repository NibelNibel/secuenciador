/* Modo Escritor, sección «Ritmo»: elige una melodía guardada y crea varios ritmos tocando la pantalla.
   Cada pulsación suena la nota actual; mientras mantienes el dedo la nota dura; al soltar, pasa a la siguiente.
   Se guarda cuándo empieza (t) y cuánto dura (d) cada nota, así también se conservan los silencios. */
(function(NS){
  const S = NS.State, N = NS.Notes, RC = NS.RhythmCore, $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const sel = $('rhMel'), list = $('rhList'), info = $('rhInfo'), top = $('rhTop'), recBox = $('rhRec'), pad = $('rhPad'), done = $('recDone');
  const secs = ms => (ms / 1000).toFixed(1).replace('.', ',') + ' s';
  let playingId = null;
  let rec = null; // {m, notes, idx, events, t0, ev, pid, handle, done}

  const curMel = () => S.melodies.find(m => m.id === S.data.rhMel) || S.melodies[0] || null;

  /* ---------- Lista de ritmos de la melodía ---------- */
  function strip(r){
    const T = RC.totalMs(r.events) || 1;
    return '<div class="rbars">' + r.events.map((e, i) =>
      '<i data-i="' + i + '" style="left:' + (e.t / T * 100).toFixed(2) + '%;width:' + Math.max(e.d / T * 100, .8).toFixed(2) + '%"></i>').join('') + '</div>';
  }
  function draw(){
    const m = curMel();
    sel.innerHTML = S.melodies.map(x => '<option value="' + esc(x.id) + '">' + esc(x.name) + ' (' + x.notes.length + ')</option>').join('');
    if(m) sel.value = m.id;
    sel.disabled = !m; $('rhNew').disabled = !m || !m.notes.length;
    if(!m){
      info.textContent = ''; list.innerHTML = '<p class="empty">Primero guarda una melodía (Modo Escritor → «Escribir» → «Guardar») y aquí podrás ponerle ritmo.</p>'; return;
    }
    info.textContent = m.notes.length + ' notas · ' + N.format(m.notes.slice(0, 12), S.data.acc) + (m.notes.length > 12 ? ' …' : '');
    if(!m.rhythms.length){
      list.innerHTML = '<p class="empty">Esta melodía aún no tiene ritmos. Pulsa «＋ Crear ritmo»: toca y mantén la pantalla para cada nota; al soltar pasa a la siguiente.</p>'; return;
    }
    list.innerHTML = m.rhythms.map(r => {
      const ok = RC.fits(m, r), fav = m.favRhythm === r.id, play = playingId === r.id;
      return '<div class="card' + (fav ? ' cur' : '') + '" data-id="' + esc(r.id) + '">' +
        '<div class="cardTop"><b>' + (fav ? '★ ' : '') + esc(r.name) + '</b><small>' + r.events.length + ' notas · ' + secs(RC.totalMs(r.events)) + '</small></div>' +
        (ok ? '' : '<div class="warnLine">⚠ Tiene ' + r.events.length + ' notas y la melodía ' + m.notes.length + ' (se editó). Crea el ritmo de nuevo.</div>') +
        strip(r) +
        '<div class="cardBtns"><button class="btn" data-act="play"' + (ok ? '' : ' disabled') + '>' + (play ? '⏹ Detener' : '▶ Reproducir') + '</button>' +
        '<button class="btn" data-act="fav"' + (ok ? '' : ' disabled') + '>' + (fav ? '★ Elegido' : '☆ Elegir') + '</button>' +
        '<button class="btn" data-act="name">✏️</button><button class="btn" data-act="dl">⬇ Descargar</button>' +
        '<button class="btn danger" data-act="del">🗑</button></div></div>';
    }).join('');
  }

  function mark(id, i){
    const card = list.querySelector('.card[data-id="' + id + '"]'); if(!card) return;
    [...card.querySelectorAll('.rbars i')].forEach((b, k) => b.classList.toggle('now', k === i));
  }

  list.addEventListener('click', e => {
    const b = e.target.closest('button'), card = e.target.closest('.card'), m = curMel(); if(!b || !card || !m) return;
    const r = m.rhythms.find(x => x.id === card.dataset.id); if(!r) return;
    switch(b.dataset.act){
      case 'play':
        if(NS.Player.isPlaying('rh:' + r.id)) return NS.Player.stop();
        NS.Audio.setInstrument(S.data.inst);
        NS.Player.playTimed('rh:' + r.id, m.notes, r.events, i => mark(r.id, i), () => { playingId = null; draw(); });
        playingId = r.id; draw(); break;
      case 'fav':
        S.updateMelody(m.id, mm => { mm.favRhythm = mm.favRhythm === r.id ? null : r.id; }); break;
      case 'name': rename(m, r); break;
      case 'dl': exportSheet(m, r); break;
      case 'del':
        if(confirm('¿Eliminar el ritmo «' + r.name + '»?')){
          NS.Player.stop();
          S.updateMelody(m.id, mm => { mm.rhythms = mm.rhythms.filter(x => x.id !== r.id); if(mm.favRhythm === r.id) mm.favRhythm = null; });
        } break;
    }
  });
  sel.addEventListener('change', () => { NS.Player.stop(); S.set({rhMel:sel.value}); });

  function rename(m, r){
    let input;
    NS.Sheet.open('Nombre del ritmo', 'Aceptar', box => {
      box.innerHTML = '<input id="lblInput" maxlength="40" value="' + esc(r.name) + '">';
      input = box.querySelector('input');
      input.addEventListener('keydown', e => { if(e.key === 'Enter'){ e.preventDefault(); $('sheetOk').click(); } });
    }, () => { const v = input.value.trim() || r.name; S.updateMelody(m.id, mm => { mm.rhythms.find(x => x.id === r.id).name = v; }); });
  }

  /* ---------- Descargar ---------- */
  function exportSheet(m, r){
    NS.Sheet.open('Descargar «' + r.name + '»', null, box => {
      box.innerHTML = '<button class="btn tpl" data-f="mid"><b>🎹 MIDI (.mid)</b><span>Las notas con su ritmo exacto. Se abre en cualquier app o programa de música.</span></button>' +
        '<button class="btn tpl" data-f="wav"><b>🔊 Audio (.wav)</b><span>Sonido ya generado (piano sintetizado) para escucharlo o enviarlo.</span></button>' +
        '<p class="small" id="exMsg">En el móvil se abrirá el menú de Android: elige «Guardar en el dispositivo», Drive, WhatsApp…</p>';
      const msg = box.querySelector('#exMsg');
      box.addEventListener('click', async e => {
        const b = e.target.closest('[data-f]'); if(!b) return;
        msg.textContent = 'Preparando…'; await new Promise(res => setTimeout(res, 30)); // deja pintar el aviso antes de generar el audio
        let res; try{ res = await RC.deliver(RC.makeFile(m, r, b.dataset.f)); }catch(err){ res = {ok:false, msg:String(err && err.message || err)}; }
        if(res.ok && !res.canceled) NS.Sheet.close(); else msg.textContent = res.ok ? 'Cancelado.' : '⚠ ' + res.msg;
      });
    }, null);
  }

  /* ---------- Grabar un ritmo con el dedo ---------- */
  function drawRec(){
    const n = rec.notes.length, acc = S.data.acc;
    $('recTitle').textContent = rec.done ? 'Ritmo grabado' : 'Nota ' + (rec.idx + 1) + ' de ' + n;
    $('recChips').innerHTML = rec.notes.map((midi, i) =>
      '<span class="rchip' + (i < rec.idx ? ' done' : i === rec.idx && !rec.done ? ' cur' : '') + '">' + N.name(midi, acc) + '</span>').join('');
    const cur = $('recChips').querySelector('.cur'); cur && cur.scrollIntoView({block:'nearest', inline:'nearest'});
    pad.hidden = rec.done; done.hidden = !rec.done;
    if(rec.done){
      $('recSummary').textContent = n + ' notas · ' + secs(RC.totalMs(rec.events));
      $('recName').value = $('recName').value || 'Ritmo ' + (rec.m.rhythms.length + 1);
      return;
    }
    $('padStep').textContent = rec.t0 === null ? 'Toca para empezar' : '';
    $('padNote').textContent = N.name(rec.notes[rec.idx], acc);
    $('padHint').textContent = 'Mantén para alargar · suelta para pasar a la siguiente';
    $('padNext').textContent = rec.idx + 1 < n ? 'Siguiente: ' + N.name(rec.notes[rec.idx + 1], acc) : 'Última nota';
  }
  function showRec(on){
    [list, info, top].forEach(el => el.hidden = on); recBox.hidden = !on;
    if(on) recBox.scrollIntoView({block:'nearest'});
  }
  function startRec(){
    const m = curMel(); if(!m || !m.notes.length) return;
    NS.Player.stop(); NS.Audio.setInstrument(S.data.inst);
    rec = {m, notes:m.notes.slice(), idx:0, events:[], t0:null, ev:null, pid:null, handle:null, done:false};
    $('recName').value = ''; showRec(true); drawRec();
  }
  function abortPress(){
    if(!rec) return;
    if(rec.handle) NS.Audio.off(rec.handle);
    rec.handle = null; rec.ev = null; rec.pid = null; pad.classList.remove('down');
  }
  function endRec(){ abortPress(); NS.Player.stop(); rec = null; showRec(false); draw(); }

  pad.addEventListener('pointerdown', e => {
    if(!rec || rec.done || rec.pid !== null) return; // un solo dedo a la vez
    e.preventDefault(); try{ pad.setPointerCapture(e.pointerId); }catch(_){}
    const now = performance.now(); if(rec.t0 === null) rec.t0 = now;
    rec.pid = e.pointerId; rec.ev = {t:Math.round(now - rec.t0)};
    rec.handle = NS.Audio.on(rec.notes[rec.idx]);
    pad.classList.add('down'); $('padStep').textContent = '';
  });
  function release(e){
    if(!rec || rec.done || rec.pid === null || e.pointerId !== rec.pid) return;
    const end = performance.now() - rec.t0;
    rec.ev.d = Math.max(40, Math.round(end - rec.ev.t));
    rec.events.push(rec.ev);
    abortPress();
    rec.idx++;
    if(rec.idx >= rec.notes.length) rec.done = true;
    drawRec();
  }
  ['pointerup', 'pointercancel'].forEach(ev => pad.addEventListener(ev, release));
  pad.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('visibilitychange', () => { if(document.hidden) abortPress(); });

  $('rhNew').addEventListener('click', startRec);
  $('recCancel').addEventListener('click', () => { if(!rec.events.length || confirm('¿Descartar este ritmo?')) endRec(); });
  $('recRestart').addEventListener('click', startRec);
  $('recAgain').addEventListener('click', startRec);
  $('recListen').addEventListener('click', () => {
    if(NS.Player.isPlaying('rec')) return NS.Player.stop();
    const b = $('recListen'); b.textContent = '⏹ Detener';
    NS.Player.playTimed('rec', rec.notes, rec.events, () => {}, () => { b.textContent = '▶ Escuchar'; });
  });
  $('recSave').addEventListener('click', () => {
    const name = $('recName').value.trim() || 'Ritmo ' + (rec.m.rhythms.length + 1), r = RC.create(name, rec.events), id = rec.m.id;
    S.updateMelody(id, mm => { mm.rhythms.push(r); if(!mm.favRhythm) mm.favRhythm = r.id; });
    endRec();
  });

  S.on(keys => {
    if(keys.includes('tab') && S.data.tab !== 'rhythm') abortPress();
    if(keys.some(k => ['melodies', 'rhMel', 'acc'].includes(k)) && !rec) draw();
  });
  draw();
})(window.NS = window.NS || {});
