/* Panel superior: notas registradas, mover/eliminar, texto, guardar. */
(function(NS){
  const S = NS.State, N = NS.Notes, $ = id => document.getElementById(id);
  const chips = $('chips'), acts = $('noteActions'), txt = $('seqText'), msg = $('seqMsg');
  const playBtn = $('playBtn'), saveBtn = $('saveBtn');
  let sel = -1, msgTimer;

  const flash = (t, ms) => { msg.textContent = t; clearTimeout(msgTimer); if(ms) msgTimer = setTimeout(() => msg.textContent = '', ms); };
  const syncText = () => { txt.value = N.format(S.data.notes, S.data.acc); };

  function drawChips(){
    const d = S.data; chips.innerHTML = '';
    if(!d.notes.length) chips.innerHTML = '<span class="empty">Sin notas. Activa «Registrar» y toca el piano, o escribe abajo.</span>';
    d.notes.forEach((m, i) => {
      const b = document.createElement('button');
      b.className = 'note' + (i === sel ? ' sel' : ''); b.dataset.i = i; b.textContent = N.name(m, d.acc);
      chips.appendChild(b);
    });
    $('count').textContent = d.notes.length + (d.notes.length === 1 ? ' nota' : ' notas');
    drawActions();
  }
  function drawActions(){
    const n = S.data.notes; acts.hidden = sel < 0; if(sel < 0) return;
    $('selLabel').textContent = N.name(n[sel], S.data.acc) + ' · posición ' + (sel + 1);
    $('actBack').disabled = sel === 0; $('actFwd').disabled = sel === n.length - 1;
  }
  function drawMeta(){
    const d = S.data;
    $('recToggle').checked = d.recording; $('accBtn').textContent = d.acc === 'b' ? '♭' : '♯';
    saveBtn.textContent = d.editingId ? '💾 Actualizar' : '💾 Guardar';
  }

  chips.addEventListener('click', e => {
    const b = e.target.closest('.note'); if(!b) return;
    const i = +b.dataset.i; sel = sel === i ? -1 : i;
    NS.Audio.blip(S.data.notes[i], .35); drawChips();
  });
  acts.addEventListener('click', e => {
    const a = e.target.closest('button'); if(!a || sel < 0) return;
    const n = S.data.notes.slice(), act = a.dataset.act;
    if(act === 'close'){ sel = -1; return drawChips(); }
    if(act === 'del'){ n.splice(sel, 1); sel = -1; }
    else{
      const j = act === 'back' ? sel - 1 : sel + 1;
      [n[sel], n[j]] = [n[j], n[sel]]; sel = j;
    }
    S.set({notes:n});
  });

  txt.addEventListener('input', () => {
    const r = N.parseSeq(txt.value);
    S.set({notes:r.notes}, 'text');
    flash(r.bad.length ? '⚠ No reconocidas: ' + r.bad.join(' ') : '');
  });
  txt.addEventListener('blur', () => { syncText(); flash(''); });

  $('recToggle').addEventListener('change', e => S.set({recording:e.target.checked}));
  $('accBtn').addEventListener('click', () => S.set({acc:S.data.acc === 'b' ? '#' : 'b'}));
  $('bpm').addEventListener('change', e => {
    const v = Math.min(300, Math.max(30, parseInt(e.target.value, 10) || 120));
    e.target.value = v; S.set({bpm:v});
  });
  $('melName').addEventListener('input', e => S.set({name:e.target.value}, 'name'));

  playBtn.addEventListener('click', () => {
    if(NS.Player.isPlaying('seq')) return NS.Player.stop();
    NS.Player.play('seq', S.data.notes, S.data.bpm,
      i => { [...chips.children].forEach((c, k) => c.classList.toggle('now', k === i)); const c = chips.children[i]; c && c.scrollIntoView({block:'nearest', inline:'nearest'}); },
      () => { playBtn.textContent = '▶ Reproducir'; });
    if(NS.Player.isPlaying('seq')) playBtn.textContent = '⏹ Detener';
  });

  saveBtn.addEventListener('click', () => {
    const d = S.data;
    if(!d.notes.length) return flash('Registra al menos una nota', 2500);
    const name = d.name.trim() || 'Melodía ' + (S.melodies.length + 1);
    const m = S.saveMelody({id:d.editingId, name, notes:d.notes.slice()});
    $('melName').value = name; S.set({editingId:m.id, name}); flash('Guardada ✓', 2000);
  });
  $('newBtn').addEventListener('click', () => {
    const d = S.data, saved = S.melodies.find(m => m.id === d.editingId);
    const same = saved && JSON.stringify(saved.notes) === JSON.stringify(d.notes);
    if(d.notes.length && !same && !confirm('¿Descartar la secuencia actual sin guardar?')) return;
    NS.Player.stop(); sel = -1; $('melName').value = ''; S.set({notes:[], name:'', editingId:null});
  });

  S.on((keys, src) => {
    if(keys.includes('notes')){
      if(sel >= S.data.notes.length) sel = -1;
      drawChips();
      if(src !== 'text') syncText();
      if(src === 'record') chips.scrollTop = chips.scrollHeight;
    }
    if(keys.includes('acc')){ drawChips(); syncText(); }
    if(keys.some(k => ['notes','name','editingId','recording','acc'].includes(k))){
      drawMeta();
      if(src !== 'name') $('melName').value = S.data.name;
    }
  });

  $('bpm').value = S.data.bpm; $('melName').value = S.data.name;
  drawChips(); syncText(); drawMeta();
})(window.NS = window.NS || {});
