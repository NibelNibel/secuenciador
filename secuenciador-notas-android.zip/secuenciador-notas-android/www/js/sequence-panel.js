/* Panel superior: notas de la frase activa, mover/eliminar/dividir, texto, copiar, guardar. */
(function(NS){
  const S = NS.State, N = NS.Notes, SG = NS.Song, $ = id => document.getElementById(id);
  const chips = $('chips'), acts = $('noteActions'), txt = $('seqText'), msg = $('seqMsg');
  const playBtn = $('playBtn'), phrPlayBtn = $('phrPlayBtn'), saveBtn = $('saveBtn');
  let sel = -1, repl = false, msgTimer, now = null; // repl: «Reemplazar» activo, la próxima tecla del piano sustituye la nota elegida // now: {s,p,i} de la nota que suena

  const flash = (t, ms) => { msg.textContent = t; clearTimeout(msgTimer); if(ms) msgTimer = setTimeout(() => msg.textContent = '', ms); };
  const syncText = () => { txt.value = N.format(S.phraseNotes(), S.data.acc); };

  function drawChips(){
    const d = S.data, notes = S.phraseNotes(); chips.innerHTML = '';
    if(!notes.length) chips.innerHTML = '<span class="empty">Frase vacía. Activa «Registrar» y toca el piano, o escribe abajo.</span>';
    notes.forEach((m, i) => {
      const b = document.createElement('button');
      const on = now && now.s === d.sec && now.p === d.phr && now.i === i;
      b.className = 'note' + (i === sel ? ' sel' : '') + (i === sel && repl ? ' armed' : '') + (on ? ' now' : ''); b.dataset.i = i; b.textContent = N.name(m, d.acc);
      chips.appendChild(b);
    });
    const total = S.allNotes().length, nf = d.sections.reduce((a, s) => a + s.phrases.length, 0);
    $('count').textContent = notes.length + (notes.length === 1 ? ' nota' : ' notas') + ' en la frase · total ' + total + ' (' + nf + (nf === 1 ? ' frase' : ' frases') + ')';
    const sec = d.sections[d.sec];
    $('mergeBtn').disabled = d.phr >= sec.phrases.length - 1;
    const lo = notes.length ? Math.min(...notes) : 0, hi = notes.length ? Math.max(...notes) : 0;
    $('octDown').disabled = !notes.length || lo - 12 < N.MIN; $('octUp').disabled = !notes.length || hi + 12 > N.MAX;
    $('octRange').textContent = notes.length ? 'Rango: ' + N.name(lo, d.acc) + ' – ' + N.name(hi, d.acc) : '';
    drawActions();
  }
  function drawActions(){
    const n = S.phraseNotes(); acts.hidden = sel < 0; if(sel < 0){ repl = false; return; }
    $('selLabel').textContent = repl ? 'Toca una tecla del piano para cambiar ' + N.name(n[sel], S.data.acc) + ' (pos. ' + (sel + 1) + ')'
                                     : N.name(n[sel], S.data.acc) + ' · pos. ' + (sel + 1);
    $('actRepl').classList.toggle('armed', repl);
    $('actBack').disabled = sel === 0; $('actFwd').disabled = sel === n.length - 1;
    $('actSplit').disabled = sel === n.length - 1; // no hay nada después que separar
  }
  function drawMeta(){
    const d = S.data;
    $('recToggle').checked = d.recording; $('accBtn').textContent = d.acc === 'b' ? '♭' : '♯';
    saveBtn.textContent = d.editingId ? '💾 Actualizar' : '💾 Guardar';
  }
  function markNow(){ // resalta la nota que suena sin redibujar todo
    const d = S.data;
    [...chips.children].forEach((c, k) => c.classList.toggle('now', !!now && now.s === d.sec && now.p === d.phr && now.i === k));
    const c = now && chips.children[now.i]; c && c.classList && c.scrollIntoView({block:'nearest', inline:'nearest'});
  }

  chips.addEventListener('click', e => {
    const b = e.target.closest('.note'); if(!b) return;
    const i = +b.dataset.i; sel = sel === i ? -1 : i;
    NS.Audio.blip(S.phraseNotes()[i], .35); drawChips();
  });
  acts.addEventListener('click', e => {
    const a = e.target.closest('button'); if(!a || sel < 0) return;
    const act = a.dataset.act;
    if(act === 'close'){ sel = -1; return drawChips(); }
    if(act === 'repl'){
      repl = !repl;
      if(repl && S.data.view === 'edit') S.set({view:'both'}); // hace falta ver el teclado
      return drawChips();
    }
    if(act === 'split'){
      const at = sel; sel = -1;
      S.mutate((secs, pos) => {
        const ph = secs[pos.sec].phrases, n = ph[pos.phr].notes;
        if(at >= n.length - 1) return;
        ph.splice(pos.phr + 1, 0, {notes:n.splice(at + 1)});
      });
      return flash('Frase dividida ✓ (la segunda es la «Frase ' + (S.data.phr + 2) + '»)', 2500);
    }
    const n = S.phraseNotes().slice();
    if(act === 'del'){ n.splice(sel, 1); sel = -1; }
    else{
      const j = act === 'back' ? sel - 1 : sel + 1;
      [n[sel], n[j]] = [n[j], n[sel]]; sel = j;
    }
    S.setPhraseNotes(n);
  });

  // Con «Reemplazar» activo, la tecla pulsada sustituye la nota elegida (lo llama app.js).
  function tryReplace(midi){
    if(!repl || sel < 0) return false;
    const n = S.phraseNotes().slice(); if(sel >= n.length){ repl = false; return false; }
    const old = n[sel]; n[sel] = midi; repl = false;
    S.setPhraseNotes(n);
    flash(N.name(old, S.data.acc) + ' → ' + N.name(midi, S.data.acc) + ' ✓', 2500);
    return true;
  }
  NS.Seq = {tryReplace};

  // Subir / bajar de octava toda la frase activa (cambia las notas, no hace falta editar el texto)
  function shiftOctave(dir){
    const n = S.phraseNotes(); if(!n.length) return;
    const out = n.map(m => m + dir * 12);
    if(out.some(m => m < N.MIN || m > N.MAX)) return flash('⚠ No se puede: alguna nota saldría del rango', 2500);
    S.setPhraseNotes(out);
    flash((dir > 0 ? 'Frase subida' : 'Frase bajada') + ' una octava ✓', 2000);
  }
  $('octDown').addEventListener('click', () => shiftOctave(-1));
  $('octUp').addEventListener('click', () => shiftOctave(1));

  // Unir / eliminar frase
  $('mergeBtn').addEventListener('click', () => {
    sel = -1;
    S.mutate((secs, pos) => {
      const ph = secs[pos.sec].phrases; if(pos.phr >= ph.length - 1) return;
      ph[pos.phr].notes = ph[pos.phr].notes.concat(ph[pos.phr + 1].notes); ph.splice(pos.phr + 1, 1);
    });
    flash('Frases unidas ✓', 2000);
  });
  $('phrDelBtn').addEventListener('click', () => {
    const n = S.phraseNotes().length;
    if(n && !confirm('¿Eliminar esta frase y sus ' + n + ' notas?')) return;
    NS.Player.stop(); sel = -1;
    S.mutate((secs, pos) => {
      const ph = secs[pos.sec].phrases;
      if(ph.length > 1){ ph.splice(pos.phr, 1); pos.phr = Math.min(pos.phr, ph.length - 1); } else ph[0].notes = [];
    });
  });

  // Copiar la melodía completa (secciones y frases) al portapapeles
  $('copyBtn').addEventListener('click', async () => {
    const text = SG.toText(S.data.sections, S.data.acc);
    if(!text) return flash('No hay notas que copiar', 2000);
    flash(await SG.copy(text) ? 'Copiada al portapapeles ✓' : '⚠ No se pudo copiar', 2500);
  });

  txt.addEventListener('input', () => {
    const r = N.parseSeq(txt.value);
    S.setPhraseNotes(r.notes, 'text');
    flash(r.bad.length ? '⚠ No reconocidas: ' + r.bad.join(' ') : '');
  });
  txt.addEventListener('blur', () => { syncText(); flash(''); });

  $('recToggle').addEventListener('change', e => S.set({recording:e.target.checked}));
  $('accBtn').addEventListener('click', () => S.set({acc:S.data.acc === 'b' ? '#' : 'b'}));
  $('bpm').addEventListener('change', e => {
    const v = Math.min(300, Math.max(30, parseInt(e.target.value, 10) || 120));
    e.target.value = v; S.set({bpm:v});
  });
  $('melName').addEventListener('input', e => S.set({name:e.target.value}, 'name'));

  /* Reproducción: solo suenan las notas (todas las secciones/frases en orden, o solo la frase activa). */
  const syncBtns = () => {
    playBtn.textContent = NS.Player.isPlaying('seq') ? '⏹ Detener' : '▶ Todo';
    phrPlayBtn.textContent = NS.Player.isPlaying('phr') ? '⏹ Frase' : '▶ Frase';
  };
  function play(owner, notes, locate){
    if(NS.Player.isPlaying(owner)) return NS.Player.stop();
    NS.Player.play(owner, notes, S.data.bpm,
      i => {
        if(i < 0){ now = null; return markNow(); }
        const pos = locate(i); now = pos;
        if(pos.s !== S.data.sec || pos.p !== S.data.phr) S.set({sec:pos.s, phr:pos.p}, 'play'); else markNow();
      },
      () => { now = null; markNow(); syncBtns(); });
    syncBtns();
  }
  playBtn.addEventListener('click', () => { const secs = S.data.sections; play('seq', S.allNotes(), i => SG.locate(secs, i)); });
  phrPlayBtn.addEventListener('click', () => { const s = S.data.sec, p = S.data.phr; play('phr', S.phraseNotes().slice(), i => ({s, p, i})); });

  saveBtn.addEventListener('click', () => {
    const d = S.data;
    if(!S.allNotes().length) return flash('Registra al menos una nota', 2500);
    const name = d.name.trim() || 'Melodía ' + (S.melodies.length + 1);
    const m = S.saveMelody({id:d.editingId, name, sections:d.sections});
    $('melName').value = name; S.set({editingId:m.id, name}); flash('Guardada ✓', 2000);
  });
  const discardOk = () => {
    const d = S.data, saved = S.melodies.find(m => m.id === d.editingId);
    const same = saved && JSON.stringify(saved.sections) === JSON.stringify(d.sections);
    return !S.allNotes().length || same || confirm('¿Descartar la secuencia actual sin guardar?');
  };

  /* Importar: pegar texto con [Secciones] y una frase por línea → melodía nueva. */
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  $('importBtn').addEventListener('click', () => {
    let ta, nameIn, prev, parsed = null;
    const refresh = () => {
      parsed = SG.parseText(ta.value);
      const total = SG.flat(parsed.sections).length;
      if(!total){ prev.innerHTML = '<span>' + (ta.value.trim() ? '<span class="warn">No se reconocieron notas.</span>' : 'Pega aquí tu melodía.') + '</span>'; return; }
      const nf = parsed.sections.reduce((a, s) => a + s.phrases.length, 0);
      prev.innerHTML = '<span><b>' + parsed.sections.length + '</b> secciones · <b>' + nf + '</b> frases · <b>' + total + '</b> notas</span>' +
        parsed.sections.map((s, i) => '<span>• <b>' + esc(SG.labelOf(s, i)) + '</b>: ' + s.phrases.map(p => p.notes.length).join(' + ') + ' notas</span>').join('') +
        (parsed.bad.length ? '<span class="warn">⚠ No reconocidas (se omiten): ' + esc(parsed.bad.join(' ')) + '</span>' : '') +
        (parsed.ignored.length ? '<span class="warn">⚠ ' + parsed.ignored.length + ' línea(s) sin notas ignoradas</span>' : '');
    };
    NS.Sheet.open('Importar melodía', 'Importar', box => {
      box.innerHTML = '<p class="small">Un título entre corchetes crea una sección y cada línea es una frase.</p>' +
        '<textarea id="impText" spellcheck="false" autocapitalize="characters" placeholder="[Introducción]&#10;A4 E5 E5 C♯5 …&#10;A4 E5 E5 C♯5 …&#10;&#10;[Estrofa]&#10;A4 B4 C5 …"></textarea>' +
        '<div class="tools"><button class="btn sm" id="impPaste">📋 Pegar del portapapeles</button></div>' +
        '<input id="impName" maxlength="60" placeholder="Nombre de la melodía (opcional)"><div id="impPrev"></div>';
      ta = box.querySelector('#impText'); nameIn = box.querySelector('#impName'); prev = box.querySelector('#impPrev');
      ta.addEventListener('input', refresh);
      box.querySelector('#impPaste').addEventListener('click', async () => {
        try{ ta.value = await navigator.clipboard.readText(); refresh(); }
        catch(e){ prev.innerHTML = '<span class="warn">No se pudo leer el portapapeles: mantén pulsado en el cuadro y elige «Pegar».</span>'; }
      });
      refresh();
    }, () => {
      refresh();
      if(!SG.flat(parsed.sections).length) return false;
      if(!discardOk()) return false;
      const name = nameIn.value.trim();
      NS.Player.stop(); sel = -1; repl = false; $('melName').value = name;
      S.set({sections:parsed.sections, sec:0, phr:0, name, editingId:null, tab:'piano'});
      flash('Melodía importada ✓ (' + parsed.sections.length + ' secciones)', 3000);
    });
  });

  // Al escribir, el panel se desplaza para dejar el campo arriba: el teclado del móvil (que se dibuja encima) no lo tapa.
  const panel = $('seqPanel'), isField = t => t && (t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && t.type !== 'checkbox'));
  panel.addEventListener('focusin', e => {
    if(!isField(e.target)) return;
    panel.classList.add('typing'); setTimeout(() => e.target.scrollIntoView({block:'start'}), 80);
  });
  panel.addEventListener('focusout', () => setTimeout(() => { if(!isField(document.activeElement)) panel.classList.remove('typing'); }, 150));

  $('newBtn').addEventListener('click', () => {
    if(!discardOk()) return;
    NS.Player.stop(); sel = -1; repl = false; $('melName').value = '';
    S.set({sections:SG.fromNotes([]), sec:0, phr:0, name:'', editingId:null});
  });

  S.on((keys, src) => {
    if(keys.includes('sec') || keys.includes('phr')){ if(src !== 'play') sel = -1; }
    if(keys.some(k => ['sections', 'sec', 'phr'].includes(k))){
      if(sel >= S.phraseNotes().length) sel = -1;
      drawChips();
      if(src !== 'text') syncText();
      if(src === 'record') chips.scrollTop = chips.scrollHeight;
    }
    if(keys.includes('acc')){ drawChips(); syncText(); }
    if(keys.some(k => ['sections', 'name', 'editingId', 'recording', 'acc'].includes(k))){
      drawMeta();
      if(src !== 'name') $('melName').value = S.data.name;
    }
  });

  $('bpm').value = S.data.bpm; $('melName').value = S.data.name;
  drawChips(); syncText(); drawMeta();
})(window.NS = window.NS || {});
