/* Modo Escritor — melodías.
   · Lista (en el menú principal, bajo el panel del Modo Escritor): al tocar una melodía se abre en el editor.
   · Sección «Escuchar» (dentro del modo): detalle de la melodía abierta, con secciones de color propio, notas en cajitas
     que se iluminan al sonar y, abajo, el reproductor de ritmos. */
(function(NS){
  const S = NS.State, N = NS.Notes, SG = NS.Song, RC = NS.RhythmCore, $ = id => document.getElementById(id);
  const list = $('melList'), panel = $('melPanel'), view = $('view-melodies'), empty = $('mpEmpty');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : many);
  const fmt = ms => { const s = Math.round(ms / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  const dateOf = m => new Date(m.updated || m.created || Date.now()).toLocaleDateString('es', {day:'numeric', month:'short'});
  const nPhrases = m => m.sections.reduce((a, s) => a + s.phrases.filter(p => p.notes.length).length, 0);
  const hasNotes = s => s.phrases.some(p => p.notes.length);

  let openId = null;   // melodía que se muestra en «Escuchar» (la que se está editando en el Escritor)
  let selR = 'none';   // ritmo elegido: id de ritmo o 'none' (pulso fijo según BPM)
  let rcount = 0;      // nº de ritmos que tenía al abrir (para elegir solo el ritmo recién creado)
  let boxes = [], evs = [], total = 0, lastSec = null;

  const curM = () => S.melodies.find(x => x.id === openId) || null;
  const owner = () => 'mp:' + openId;
  const defaultR = m => { const f = RC.favorite(m) || m.rhythms.find(r => RC.fits(m, r)); return f ? f.id : 'none'; };

  /* ---------- Lista ---------- */
  function drawList(){
    $('melCount').textContent = S.melodies.length ? 'Melodías (' + S.melodies.length + ')' : 'Melodías';
    // Borrador sin guardar (melodía nueva con notas): se ofrece seguir con él para no perderlo
    const draft = !S.data.editingId && S.allNotes().length
      ? '<button class="mcard cur" data-draft="1"><div class="mcTop"><b>' + esc(S.data.name.trim() || 'Borrador sin guardar') + '</b><span class="stBadge">Borrador</span><span class="mcGo">›</span></div>' +
        '<div class="mcMeta">🎵 ' + plural(S.allNotes().length, 'nota', 'notas') + ' · sin guardar · toca para seguir escribiendo</div></button>' : '';
    if(!S.melodies.length){
      list.innerHTML = draft + (draft ? '' : '<p class="empty">Aún no tienes melodías guardadas. Toca «＋ Nueva melodía» para componer la primera.</p>'); return;
    }
    list.innerHTML = draft + S.melodies.map(m => {
      const np = nPhrases(m), pills = m.sections.some(s => s.label)
        ? m.sections.map((s, i) => hasNotes(s) ? '<span class="pill" style="--h:' + SG.hueOf(s, i) + '">' + esc(SG.labelOf(s, i)) + '</span>' : '').join('') : '';
      return '<button class="mcard' + (m.id === S.data.editingId ? ' cur' : '') + '" data-id="' + esc(m.id) + '">' +
        '<div class="mcTop"><b>' + esc(m.name) + '</b>' + (m.id === S.data.editingId ? '<span class="stBadge">Editando</span>' : '<small>' + dateOf(m) + '</small>') + '<span class="mcGo">›</span></div>' +
        '<div class="mcMeta">🎵 ' + plural(m.notes.length, 'nota', 'notas') + ' · 🧩 ' + plural(np, 'frase', 'frases') +
          (m.rhythms.length ? ' · 🥁 ' + plural(m.rhythms.length, 'ritmo', 'ritmos') : '') + '</div>' +
        (pills ? '<div class="mcPills">' + pills + '</div>' : '') + '</button>';
    }).join('');
  }
  /* Abrir una melodía en el editor (o seguir con el borrador / empezar una nueva) */
  const discardOk = () => {
    const d = S.data, saved = S.melodies.find(m => m.id === d.editingId);
    const same = saved && JSON.stringify(saved.sections) === JSON.stringify(d.sections);
    return !S.allNotes().length || same || confirm('¿Descartar la secuencia actual sin guardar?');
  };
  // keep = true: se cambia de melodía desde dentro del Modo Escritor y se queda en la misma sección (Escribir / Ritmo / Escuchar)
  function abrir(id, keep){
    NS.Player.stop();
    if(keep && S.data.tab === 'rhythm' && !$('rhRec').hidden){ NS.Studio.toast('Termina o cancela el ritmo antes de cambiar de melodía.'); return; }
    if(id === S.data.editingId){ if(!keep) NS.Nav.go('piano'); return; }      // ya es la que se está editando: se conserva el borrador tal cual
    const m = S.melodies.find(x => x.id === id); if(!m) return;
    if(!discardOk()) return;
    const patch = {sections:JSON.parse(JSON.stringify(m.sections)), sec:0, phr:0, name:m.name, editingId:m.id};
    if(keep){ patch.recording = false; patch.rhMel = m.id; } else patch.tab = 'piano';
    S.set(patch);
  }
  function nueva(){
    NS.Player.stop();
    if(!discardOk()) return;
    S.set({sections:SG.fromNotes([]), sec:0, phr:0, name:'', editingId:null, tab:'piano', recording:false});
  }
  list.addEventListener('click', e => {
    const b = e.target.closest('.mcard'); if(!b) return;
    if(b.dataset.draft){ NS.Nav.go('piano'); return; }
    abrir(b.dataset.id);
  });
  $('wrNew').addEventListener('click', nueva);

  /* ---------- Selector rápido (botón ⇄ de la barra del Modo Escritor) ---------- */
  function elegir(){
    NS.Sheet.open('Cambiar de melodía', null, box => {
      const draft = !S.data.editingId && S.allNotes().length;
      const cards = S.melodies.map(m => {
        const cur = m.id === S.data.editingId;
        return '<button class="mcard' + (cur ? ' cur' : '') + '" data-id="' + esc(m.id) + '"><div class="mcTop"><b>' + esc(m.name) + '</b>' +
          (cur ? '<span class="stBadge">Editando</span>' : '<small>' + dateOf(m) + '</small>') + '</div>' +
          '<div class="mcMeta">🎵 ' + plural(m.notes.length, 'nota', 'notas') + ' · 🧩 ' + plural(nPhrases(m), 'frase', 'frases') +
          (m.rhythms.length ? ' · 🥁 ' + plural(m.rhythms.length, 'ritmo', 'ritmos') : '') + '</div></button>';
      }).join('');
      box.innerHTML = '<button class="btn primary" data-new="1">＋ Nueva melodía</button>' +
        (draft ? '<button class="mcard cur" data-draft="1"><div class="mcTop"><b>' + esc(S.data.name.trim() || 'Borrador sin guardar') + '</b><span class="stBadge">Editando</span></div>' +
          '<div class="mcMeta">🎵 ' + plural(S.allNotes().length, 'nota', 'notas') + ' · sin guardar</div></button>' : '') +
        (cards || (draft ? '' : '<p class="empty">Aún no tienes melodías guardadas.</p>'));
      box.addEventListener('click', e => {
        const b = e.target.closest('button'); if(!b) return;
        NS.Sheet.close();
        if(b.dataset.new) nueva(); else if(!b.dataset.draft) abrir(b.dataset.id, true);
      });
    });
  }

  /* ---------- Panel ---------- */
  function show(){
    const on = openId !== null;
    panel.hidden = !on; empty.hidden = on; view.classList.toggle('open', on);
    if(!on) empty.innerHTML = S.data.editingId ? '' : (S.allNotes().length
      ? '<b>Esta melodía aún no está guardada.</b><br>Vuelve a «Escribir» y pulsa «💾 Guardar» para poder escucharla aquí con sus ritmos.'
      : '<b>Todavía no hay melodía.</b><br>Escribe unas notas en «Escribir» y guárdalas para escucharlas aquí con sus ritmos.');
  }
  // Muestra la melodía que se está editando; si cambió de melodía, se reinicia la elección de ritmo
  function sync(){
    const id = S.melodies.some(x => x.id === S.data.editingId) ? S.data.editingId : null;
    if(id !== openId){
      NS.Player.stop(); openId = id;
      const m = curM(); if(m){ rcount = m.rhythms.length; selR = defaultR(m); } lastSec = null;
    }
    if(openId) drawPanel(); else show();
  }

  function drawPanel(){
    const m = curM(); if(!m){ openId = null; show(); return; }
    // Si se creó un ritmo nuevo (en la sección Ritmo), se elige solo; si el elegido ya no existe, se vuelve al predeterminado.
    if(m.rhythms.length > rcount) selR = m.rhythms[m.rhythms.length - 1].id;
    rcount = m.rhythms.length;
    if(selR !== 'none' && !m.rhythms.some(r => r.id === selR)) selR = defaultR(m);
    show();
    const acc = S.data.acc, notes = m.notes, secs = m.sections;
    $('mpName').textContent = m.name;
    $('mpDate').textContent = 'Actualizada el ' + dateOf(m);

    const lo = notes.length ? N.name(Math.min(...notes), acc) : '–', hi = notes.length ? N.name(Math.max(...notes), acc) : '–';
    const stat = (v, l) => '<div class="stat"><b>' + v + '</b><span>' + l + '</span></div>';
    $('mpStats').innerHTML = stat(notes.length, 'notas') + stat(secs.filter(hasNotes).length, 'secciones') + stat(nPhrases(m), 'frases') +
      stat(lo + '–' + hi, 'rango') + stat(m.rhythms.length, 'ritmos');

    let k = 0; // índice de la nota en la lista plana (el mismo que usa el reproductor)
    $('mpSecs').innerHTML = secs.map((s, si) => {
      const nn = s.phrases.reduce((a, p) => a + p.notes.length, 0), shown = s.phrases.map((p, pi) => ({p, pi})).filter(x => x.p.notes.length);
      const body = shown.length ? shown.map(x =>
        '<div class="mph">' + (shown.length > 1 ? '<div class="mphLabel">Frase ' + (x.pi + 1) + '</div>' : '') +
        '<div class="mnotes">' + x.p.notes.map(midi => '<button class="nb" data-i="' + (k++) + '" data-m="' + midi + '">' + N.name(midi, acc) + '</button>').join('') + '</div></div>'
      ).join('') : '<div class="empty">Sección vacía</div>';
      return '<div class="msec" style="--h:' + SG.hueOf(s, si) + '"><div class="msHead"><b>' + esc(SG.labelOf(s, si)) + '</b>' +
        '<small>' + plural(shown.length, 'frase', 'frases') + ' · ' + plural(nn, 'nota', 'notas') + '</small></div>' + body + '</div>';
    }).join('');
    boxes = [...$('mpSecs').querySelectorAll('.nb')]; lastSec = null;
    drawPlayer();
  }

  /* ---------- Reproductor de ritmos (parte baja) ---------- */
  function drawPlayer(){
    const m = curM(); if(!m) return;
    const r = selR === 'none' ? null : m.rhythms.find(x => x.id === selR), ok = !r || RC.fits(m, r);
    const ms = 60000 / S.data.bpm;
    evs = r ? r.events : m.notes.map((_, i) => ({t:Math.round(i * ms), d:Math.round(ms * .9)})); // sin ritmo: un pulso por nota
    total = RC.totalMs(evs) || 1;

    $('mpPicks').innerHTML = '<button class="rpick' + (selR === 'none' ? ' sel' : '') + '" data-r="none">♩ Pulso fijo · ' + S.data.bpm + ' BPM</button>' +
      m.rhythms.map(x => '<button class="rpick' + (x.id === selR ? ' sel' : '') + '" data-r="' + esc(x.id) + '">' + (m.favRhythm === x.id ? '★ ' : '') + (RC.fits(m, x) ? '' : '⚠ ') + esc(x.name) + '</button>').join('') +
      '<button class="rpick add" data-r="new">＋ Nuevo ritmo</button>';
    $('mpStrip').innerHTML = '<div class="rbars">' + evs.map((e, i) =>
      '<i data-i="' + i + '" style="left:' + (e.t / total * 100).toFixed(2) + '%;width:' + Math.max(e.d / total * 100, .8).toFixed(2) + '%"></i>').join('') + '</div>';

    $('mpFav').hidden = !r; $('mpFav').disabled = !ok;
    $('mpFav').textContent = r && m.favRhythm === r.id ? '★' : '☆';
    $('mpPlay').disabled = !ok || !m.notes.length;
    $('mpMsg').textContent = !ok ? '⚠ Este ritmo tiene ' + r.events.length + ' notas y la melodía ' + m.notes.length + ' (se editó). Crea el ritmo de nuevo.'
      : (!m.rhythms.length ? 'Esta melodía aún no tiene ritmos: suena a pulso fijo. Pulsa «＋ Nuevo ritmo» para crear uno.' : '');
    resetLights(); syncPlayBtn();
  }
  function syncPlayBtn(){ $('mpPlay').textContent = openId && NS.Player.isPlaying(owner()) ? '⏹ Detener' : '▶ Reproducir'; }
  function resetLights(){
    boxes.forEach(b => b.classList.remove('now', 'past'));
    if(lastSec){ lastSec.classList.remove('active'); lastSec = null; }
    document.querySelectorAll('#mpStrip i.now').forEach(i => i.classList.remove('now'));
    $('mpBar').style.width = '0'; $('mpTime').textContent = '0:00 / ' + fmt(total);
  }
  function step(i){
    if(i < 0 || !boxes[i]) return;
    boxes.forEach((b, k) => { b.classList.toggle('now', k === i); b.classList.toggle('past', k < i); });
    const sec = boxes[i].closest('.msec');
    if(sec !== lastSec){ lastSec && lastSec.classList.remove('active'); sec.classList.add('active'); lastSec = sec; }
    boxes[i].scrollIntoView({block:'nearest', inline:'nearest'});
    [...$('mpStrip').querySelectorAll('i')].forEach((x, k) => x.classList.toggle('now', k === i));
    const e = evs[i]; $('mpBar').style.width = (e.t / total * 100).toFixed(1) + '%'; $('mpTime').textContent = fmt(e.t) + ' / ' + fmt(total);
  }
  function play(){
    const m = curM(); if(!m || !m.notes.length) return;
    if(NS.Player.isPlaying(owner())) return NS.Player.stop();
    NS.Audio.setInstrument(S.data.inst);
    const end = () => { resetLights(); syncPlayBtn(); };
    if(selR !== 'none'){
      const r = m.rhythms.find(x => x.id === selR); if(!r || !RC.fits(m, r)) return;
      NS.Player.playTimed(owner(), m.notes, r.events, step, end);
    }else NS.Player.play(owner(), m.notes, S.data.bpm, step, end);
    syncPlayBtn();
  }

  $('mpPlay').addEventListener('click', play);
  $('mpPicks').addEventListener('click', e => {
    const b = e.target.closest('[data-r]'); if(!b) return;
    NS.Player.stop();
    if(b.dataset.r === 'new') return S.set({rhMel:openId, tab:'rhythm'});   // sección «Ritmo» del Escritor
    selR = b.dataset.r; drawPlayer();
  });
  $('mpFav').addEventListener('click', () => {
    const m = curM(); if(!m || selR === 'none') return;
    S.updateMelody(m.id, mm => { mm.favRhythm = mm.favRhythm === selR ? null : selR; });
  });
  $('mpSecs').addEventListener('click', e => { // tocar una cajita suena esa nota
    const b = e.target.closest('.nb'); if(b) NS.Audio.blip(+b.dataset.m, .35);
  });
  $('mpTools').addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    const m = curM(); if(!m) return;
    switch(b.dataset.mact){
      case 'copy':
        NS.Song.copy(NS.Song.toText(m.sections, S.data.acc)).then(ok => {
          const old = b.textContent; b.textContent = ok ? '✓ Copiada' : '⚠ Error'; setTimeout(() => { b.textContent = old; }, 1500);
        }); break;
      case 'dup': {
        S.saveMelody({name:m.name + ' (copia)', sections:m.sections, rhythms:m.rhythms, favRhythm:m.favRhythm});
        const old = b.textContent; b.textContent = '✓ Duplicada'; setTimeout(() => { b.textContent = old; }, 1500); break; }
      case 'del':
        if(confirm('¿Eliminar «' + m.name + '»?')){ const id = m.id; NS.Player.stop(); S.removeMelody(id); NS.Nav.go('home'); } break;
    }
  });

  S.on(keys => {
    if(keys.includes('tab') && S.data.tab === 'melodies') return sync();
    if(!keys.some(k => ['melodies', 'acc', 'editingId', 'bpm', 'sections', 'name'].includes(k))) return;
    drawList();
    if(S.data.tab === 'melodies' && !NS.Player.isPlaying(owner())) sync();     // no se redibuja mientras suena
  });
  drawList(); sync();
  NS.Melodies = {abrir, nueva, elegir, dibujar:drawList};
})(window.NS = window.NS || {});
