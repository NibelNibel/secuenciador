/* Pestaña «Melodías»: lista guardada, reproducir, editar, duplicar, borrar. */
(function(NS){
  const S = NS.State, N = NS.Notes, list = document.getElementById('melList');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  let playingId = null;

  function draw(){
    document.getElementById('melCount').textContent = S.melodies.length ? '(' + S.melodies.length + ')' : '';
    if(!S.melodies.length){
      list.innerHTML = '<p class="empty">Aún no tienes melodías guardadas. Registra notas en la pestaña Piano y pulsa «Guardar».</p>'; return;
    }
    list.innerHTML = S.melodies.map(m => {
      const fecha = new Date(m.updated || m.created || Date.now()).toLocaleDateString('es', {day:'numeric', month:'short'});
      return '<div class="card' + (m.id === S.data.editingId ? ' cur' : '') + '" data-id="' + esc(m.id) + '">' +
        '<div class="cardTop"><b>' + esc(m.name) + '</b><small>' + m.notes.length + ' notas · ' + fecha + '</small></div>' +
        '<div class="preview">' + esc(N.format(m.notes, S.data.acc)) + '</div>' +
        '<div class="cardBtns"><button class="btn" data-act="play">' + (m.id === playingId ? '⏹ Detener' : '▶ Reproducir') + '</button>' +
        '<button class="btn" data-act="edit">✏️ Editar</button><button class="btn" data-act="dup">⧉ Duplicar</button>' +
        '<button class="btn danger" data-act="del">🗑</button></div></div>';
    }).join('');
  }

  list.addEventListener('click', e => {
    const b = e.target.closest('button'), card = e.target.closest('.card'); if(!b || !card) return;
    const m = S.melodies.find(x => x.id === card.dataset.id); if(!m) return;
    const owner = 'mel:' + m.id;
    switch(b.dataset.act){
      case 'play':
        if(NS.Player.isPlaying(owner)) return NS.Player.stop();
        playingId = m.id;
        NS.Player.play(owner, m.notes, S.data.bpm, () => {}, () => { playingId = null; draw(); });
        draw(); break;
      case 'edit':
        NS.Player.stop();
        S.set({notes:m.notes.slice(), name:m.name, editingId:m.id, tab:'piano'}); break;
      case 'dup': S.saveMelody({name:m.name + ' (copia)', notes:m.notes.slice()}); break;
      case 'del': if(confirm('¿Eliminar «' + m.name + '»?')){ NS.Player.stop(); S.removeMelody(m.id); } break;
    }
  });

  S.on(keys => { if(keys.some(k => ['melodies','acc','editingId'].includes(k))) draw(); });
  draw();
})(window.NS = window.NS || {});
