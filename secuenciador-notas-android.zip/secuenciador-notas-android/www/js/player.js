/* Reproduce una lista de notas (una por pulso). Un solo reproductor a la vez. */
(function(NS){
  let timer = null, cb = null;
  function finish(){
    clearTimeout(timer); timer = null;
    const c = cb; cb = null;
    if(c){ c.onStep(-1); c.onEnd(); }
  }
  NS.Player = {
    isPlaying(owner){ return !!cb && cb.owner === owner; },
    stop: finish,
    play(owner, notes, bpm, onStep, onEnd){
      finish();
      if(!notes.length) return;
      cb = {owner, onStep, onEnd};
      NS.Audio.start();
      const ms = 60000 / bpm; let i = 0;
      (function tick(){
        if(i >= notes.length){ finish(); return; }
        cb.onStep(i);
        NS.Audio.blip(notes[i], ms * 0.0009);
        i++; timer = setTimeout(tick, ms);
      })();
    }
  };
})(window.NS = window.NS || {});
