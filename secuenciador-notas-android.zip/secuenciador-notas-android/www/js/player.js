/* Reproduce una lista de notas: una por pulso (play) o con ritmo propio {t,d} en ms (playTimed).
   Un solo reproductor a la vez. */
(function(NS){
  let timer = null, timers = [], cb = null;
  function finish(silent){
    clearTimeout(timer); timer = null; timers.forEach(clearTimeout); timers = [];
    const c = cb; cb = null;
    if(silent) NS.Audio.silence();            // también si no había nada en marcha (notas sueltas del teclado, etc.)
    if(c){ c.onStep(-1); c.onEnd(); }
  }
  NS.Player = {
    isPlaying(owner){ return !!cb && cb.owner === owner; },
    stop: () => finish(true),
    play(owner, notes, bpm, onStep, onEnd){
      finish(true);
      if(!notes.length) return;
      cb = {owner, onStep, onEnd};
      NS.Audio.start();
      const ms = 60000 / bpm; let i = 0;
      (function tick(){
        if(i >= notes.length){ finish(false); return; }
        cb.onStep(i);
        NS.Audio.blip(notes[i], ms * 0.0009);
        i++; timer = setTimeout(tick, ms);
      })();
    },
    // events[i] = {t, d}: la nota i empieza en t ms y dura d ms
    playTimed(owner, notes, events, onStep, onEnd){
      finish(true);
      const n = Math.min(notes.length, events.length); if(!n) return;
      cb = {owner, onStep, onEnd};
      NS.Audio.start();
      for(let i = 0; i < n; i++){
        const e = events[i];
        timers.push(setTimeout(() => { if(!cb) return; cb.onStep(i); NS.Audio.blip(notes[i], e.d / 1000); }, Math.max(0, e.t)));
      }
      timers.push(setTimeout(() => finish(false), events[n - 1].t + events[n - 1].d + 20));
    }
  };
})(window.NS = window.NS || {});
