/* Motor de audio con Tone.js: instrumentos, notas sostenidas y vista previa. */
(function(NS){
  const out = new Tone.Volume(-4).toDestination();
  const poly = (opts, Voice) => { const p = new Tone.PolySynth(Voice || Tone.Synth, opts); p.maxPolyphony = 24; p.connect(out); return p; };
  const fm = (h, mi, env, menv) => () => poly({harmonicity:h, modulationIndex:mi, envelope:env, modulationEnvelope:menv}, Tone.FMSynth);

  const INST = {
    piano:   {name:'Piano'},
    synth:   {name:'Sintetizador', make:() => poly({oscillator:{type:'triangle'}, envelope:{attack:.01,decay:.2,sustain:.4,release:.8}})},
    organ:   {name:'Órgano', make:() => poly({oscillator:{type:'fatsine',count:3,spread:18}, envelope:{attack:.02,decay:.1,sustain:.9,release:.3}})},
    electric:{name:'Piano eléctrico', make:fm(3, 8, {attack:.005,decay:.6,sustain:.2,release:1.2}, {attack:.01,decay:.4,sustain:.1,release:.6})},
    strings: {name:'Cuerdas', make:() => poly({oscillator:{type:'fatsawtooth',count:3,spread:25}, envelope:{attack:.35,decay:.2,sustain:.8,release:1.4}})},
    flute:   {name:'Flauta', make:() => poly({oscillator:{type:'sine'}, envelope:{attack:.08,decay:.1,sustain:.8,release:.4}})},
    bell:    {name:'Campanas', make:fm(8, 2, {attack:.001,decay:1.6,sustain:0,release:1.6}, {attack:.002,decay:.5,sustain:0,release:.5})},
    retro:   {name:'Retro 8-bit', make:() => poly({oscillator:{type:'square'}, envelope:{attack:.005,decay:.1,sustain:.5,release:.2}})},
    pianoFb: {name:'(respaldo)', make:() => poly({oscillator:{type:'triangle'}, envelope:{attack:.005,decay:.9,sustain:.15,release:1.2}})}
  };
  const cache = {};
  let cur = 'piano', sampler = null, samplerReady = false, started = false;

  // Piano de muestras (Salamander) incluidas en la app (audio/salamander/); si faltan, se usa un sintetizador parecido.
  function loadPiano(onStatus){
    const urls = {};
    ['A0','C1','D#1','F#1','A1','C2','D#2','F#2','A2','C3','D#3','F#3','A3','C4','D#4','F#4','A4','C5','D#5','F#5','A5','C6','D#6','F#6','A6','C7']
      .forEach(n => urls[n] = n.replace('#','s') + '.mp3');
    onStatus('Cargando piano…');
    try{
      sampler = new Tone.Sampler({urls, baseUrl:'audio/salamander/', release:1,
        onload:() => { samplerReady = true; onStatus('Piano listo'); },
        onerror:() => onStatus('Piano')}).connect(out);
    }catch(e){ onStatus('Piano'); }
    setTimeout(() => { if(!samplerReady) onStatus('Piano'); }, 6000);  // sin muestras: suena el sintetizador
  }
  function node(id){
    if(id === 'piano' && samplerReady) return sampler;
    const k = id === 'piano' ? 'pianoFb' : id;
    return cache[k] || (cache[k] = INST[k].make());
  }

  NS.Audio = {
    init(onStatus){ loadPiano(onStatus || (() => {})); },
    list(){ return Object.keys(INST).filter(k => k !== 'pianoFb').map(k => ({id:k, name:INST[k].name})); },
    setInstrument(id){ if(INST[id]) cur = id; },
    start(){
      if(!started){ started = true; Tone.start(); }
      else if(Tone.context.state !== 'running') Tone.context.resume();
    },
    on(midi){ this.start(); const n = node(cur), t = NS.Notes.tone(midi); try{ n.triggerAttack(t, Tone.now()); }catch(e){} return {n, t}; },
    off(h){ try{ h.n.triggerRelease(h.t, Tone.now()); }catch(e){} },
    blip(midi, secs){ this.start(); try{ node(cur).triggerAttackRelease(NS.Notes.tone(midi), secs || .4); }catch(e){} }
  };
})(window.NS = window.NS || {});
