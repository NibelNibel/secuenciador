/* Motor de audio con Tone.js: instrumentos, notas sostenidas, vista previa y pistas del Estudio.
   Es el ÚNICO motor de sonido de la app: el teclado, los reproductores y el Estudio usan los mismos
   instrumentos (incluido el piano de muestras) y la misma protección contra notas «congeladas». */
(function(NS){
  const out = new Tone.Volume(-4).toDestination();
  const MINDB = -40;
  /* Tone 14.5.26 tiene dos fallos en PolySynth que dejaban notas «congeladas» (un tiiii imposible de callar):
     - releaseAll() vaciaba la lista de voces activas sin devolverlas; cuando esas voces terminaban de sonar,
       _makeVoiceAvailable() hacía splice(-1) y borraba OTRA nota que sonaba en ese momento → nadie la liberaba jamás.
     - nada permitía liberar voces que ya habían quedado fuera de la lista.
     Aquí se corrigen sin tocar la librería. */
  function harden(p){
    p._makeVoiceAvailable = function(v){
      const i = this._activeVoices.findIndex(a => a.voice === v);
      if(i >= 0) this._activeVoices.splice(i, 1);            // el original borraba la última (i = -1)
      if(!this._availableVoices.includes(v)) this._availableVoices.push(v);
    };
    p.releaseAll = function(){                              // suelta todo, pero conserva el registro de voces
      const t = this.now();
      this._activeVoices.forEach(a => { try{ a.voice.triggerRelease(t); }catch(e){} a.released = true; });
      return this;
    };
    p.hardRelease = function(){                             // suelta TODA voz que no esté libre, aunque se haya «perdido»
      const t = this.now(), idle = this._availableVoices;
      this._voices.forEach(v => { if(!idle.includes(v)){ try{ v.triggerRelease(t); }catch(e){} } });
      this._activeVoices.forEach(a => { a.released = true; });
    };
    return p;
  }
  // Los instrumentos se crean sin conectar: quien los pide decide a dónde van (salida general o una pista).
  const poly = (opts, Voice) => { const p = new Tone.PolySynth(Voice || Tone.Synth, opts); p.maxPolyphony = 24; return harden(p); };
  const fm = (h, mi, env, menv) => () => poly({harmonicity:h, modulationIndex:mi, envelope:env, modulationEnvelope:menv}, Tone.FMSynth);
  // Timbre definido por armónicos (partials[0] = fundamental, [1] = 2.º armónico…). fat = [copias, desafinación en cents]: varias copias → efecto de conjunto.
  const par = (partials, env, fat) => () => poly({oscillator: fat ? {type:'fatcustom', partials, count:fat[0], spread:fat[1]} : {type:'custom', partials}, envelope:env});
  // Cuerda pulsada: ataque brillante que se suaviza solo (FM cuyo índice de modulación cae rápido) y se apaga sin sostenido.
  const pluck = (mi, dec, mdec, h, ms) => () => poly({harmonicity:h || 1, modulationIndex:mi, envelope:{attack:.002,decay:dec,sustain:0,release:Math.min(dec, .6)}, modulationEnvelope:{attack:.002,decay:mdec,sustain:ms == null ? .12 : ms,release:mdec}}, Tone.FMSynth);
  // Láminas y barras afinadas: parciales inarmónicos (h) y golpe seco, sin sostenido.
  const bar = (h, mi, dec, mdec) => fm(h, mi, {attack:.001,decay:dec,sustain:0,release:Math.min(dec, 1.2)}, {attack:.001,decay:mdec,sustain:0,release:mdec});

  // Familias para ordenar la lista de instrumentos.
  const GRUPOS = [['key','Teclados'], ['arco','Cuerdas frotadas'], ['puls','Cuerdas pulsadas'], ['perc','Percusión melódica'], ['vien','Vientos y voz'], ['sint','Sintetizadores']];

  /* grp = familia · p = programa MIDI General MIDI (0-127) que se escribe al exportar a .mid/.musicxml
     g = ajuste de volumen (dB) que solo se aplica en las pistas del Estudio, para que al mezclar no destaquen unos sobre otros. */
  const INST = {
    // Teclados
    piano:   {name:'Piano', grp:'key', p:0, g:0},
    electric:{name:'Piano eléctrico', grp:'key', p:4, g:-2, make:fm(3, 8, {attack:.005,decay:.6,sustain:.2,release:1.2}, {attack:.01,decay:.4,sustain:.1,release:.6})},
    organ:   {name:'Órgano', grp:'key', p:19, g:-3, make:() => poly({oscillator:{type:'fatsine',count:3,spread:18}, envelope:{attack:.02,decay:.1,sustain:.9,release:.3}})},
    // Cuerdas frotadas
    strings: {name:'Cuerdas', grp:'arco', p:48, g:-6, make:() => poly({oscillator:{type:'fatsawtooth',count:3,spread:25}, envelope:{attack:.35,decay:.2,sustain:.8,release:1.4}})},
    violin:  {name:'Violín', grp:'arco', p:40, g:0, make:par([1,.6,.45,.35,.22,.15,.1,.06,.03], {attack:.08,decay:.12,sustain:.85,release:.3}, [2,8])},
    cello:   {name:'Chelo', grp:'arco', p:42, g:0, make:par([1,.75,.5,.3,.2,.1,.05], {attack:.12,decay:.15,sustain:.85,release:.5}, [2,6])},
    // Cuerdas pulsadas
    harp:    {name:'Arpa', grp:'puls', p:46, g:0, make:par([1,.4,.2,.08,.03], {attack:.003,decay:1.6,sustain:0,release:1})},
    guitar:  {name:'Guitarra acústica', grp:'puls', p:25, g:0, make:pluck(5, 1.2, .35, 1, .3)},
    nylon:   {name:'Guitarra clásica', grp:'puls', p:24, g:0, make:pluck(3, 1, .3, 1, .25)},
    eguitar: {name:'Guitarra eléctrica', grp:'puls', p:27, g:0, make:fm(1, 4, {attack:.003,decay:.7,sustain:.3,release:.5}, {attack:.003,decay:.4,sustain:.25,release:.4})},
    ukulele: {name:'Ukelele', grp:'puls', p:24, g:0, make:pluck(3, .5, .15, 1, .3)},
    mandolin:{name:'Mandolina', grp:'puls', p:25, g:0, make:pluck(3.5, .4, .1, 1.006, .3)},
    banjo:   {name:'Banjo', grp:'puls', p:105, g:0, make:pluck(8, .45, .2, 1, .45)},
    pizz:    {name:'Pizzicato', grp:'puls', p:45, g:0, make:pluck(2.5, .25, .1, 1, .3)},
    // Percusión melódica
    xylophone:{name:'Xilófono', grp:'perc', p:13, g:0, make:bar(3.9, 1.8, .32, .08)},
    marimba: {name:'Marimba', grp:'perc', p:12, g:0, make:bar(4, .9, .7, .15)},
    vibes:   {name:'Vibráfono', grp:'perc', p:11, g:0, make:bar(4, .7, 2, .5)},
    glock:   {name:'Glockenspiel', grp:'perc', p:9, g:0, make:bar(6, 1.4, 1.1, .2)},
    musicbox:{name:'Caja de música', grp:'perc', p:10, g:0, make:bar(2.76, .6, .9, .12)},
    kalimba: {name:'Kalimba', grp:'perc', p:108, g:0, make:bar(3.6, 1.1, 1, .2)},
    steeldrum:{name:'Steel drum', grp:'perc', p:114, g:0, make:bar(2, 3.5, .9, .35)},
    bell:    {name:'Campanas', grp:'perc', p:14, g:-4, make:fm(8, 2, {attack:.001,decay:1.6,sustain:0,release:1.6}, {attack:.002,decay:.5,sustain:0,release:.5})},
    // Vientos y voz
    flute:   {name:'Flauta', grp:'vien', p:73, g:0, make:() => poly({oscillator:{type:'sine'}, envelope:{attack:.08,decay:.1,sustain:.8,release:.4}})},
    clarinet:{name:'Clarinete', grp:'vien', p:71, g:0, make:par([1,0,.45,0,.25,0,.12,0,.06], {attack:.05,decay:.1,sustain:.85,release:.2})},
    oboe:    {name:'Oboe', grp:'vien', p:68, g:0, make:par([1,.9,.8,.5,.35,.25,.15,.1], {attack:.05,decay:.1,sustain:.85,release:.2})},
    sax:     {name:'Saxofón', grp:'vien', p:65, g:0, make:par([1,.75,.55,.4,.3,.2,.12,.07], {attack:.04,decay:.15,sustain:.8,release:.2}, [2,5])},
    trumpet: {name:'Trompeta', grp:'vien', p:56, g:0, make:par([1,.9,.75,.6,.45,.3,.2,.12,.07], {attack:.04,decay:.1,sustain:.85,release:.15})},
    horn:    {name:'Corno francés', grp:'vien', p:60, g:0, make:par([1,.7,.4,.25,.12,.06], {attack:.12,decay:.15,sustain:.85,release:.35})},
    accordion:{name:'Acordeón', grp:'vien', p:21, g:0, make:par([1,.5,.7,.35,.4,.2,.2,.1], {attack:.05,decay:.1,sustain:.9,release:.12}, [2,14])},
    choir:   {name:'Coro', grp:'vien', p:52, g:0, make:par([1,.5,.8,.4,.2,.1], {attack:.35,decay:.3,sustain:.85,release:1}, [3,20])},
    // Sintetizadores
    synth:   {name:'Sintetizador', grp:'sint', p:81, g:0, make:() => poly({oscillator:{type:'triangle'}, envelope:{attack:.01,decay:.2,sustain:.4,release:.8}})},
    retro:   {name:'Retro 8-bit', grp:'sint', p:80, g:-6, make:() => poly({oscillator:{type:'square'}, envelope:{attack:.005,decay:.1,sustain:.5,release:.2}})},
    bass:    {name:'Bajo', grp:'sint', p:38, g:-4, make:() => poly({oscillator:{type:'square'}, envelope:{attack:.01,decay:.2,sustain:.5,release:.15}})},
    pad:     {name:'Pad', grp:'sint', p:89, g:-2, make:() => poly({oscillator:{type:'sine'}, envelope:{attack:.4,decay:.3,sustain:.8,release:1}})},
    pianoFb: {name:'(respaldo)', p:0, g:0, make:() => poly({oscillator:{type:'triangle'}, envelope:{attack:.005,decay:.9,sustain:.15,release:1.2}})}
  };
  /* Nivelación de los instrumentos nuevos (dB, aplicada a la propia voz): los sintetizados con FM suenan mucho más flojos que el piano o el órgano.
     Esta ganancia pasa tanto por el teclado como por el Estudio, así que al cambiar de instrumento el volumen es parecido.
     Calibrada con una frase de 4 notas (nivel percibido con ponderación A, objetivo -21 dB) y sin pasar de pico 0.45 en una nota. */
  const NIVEL = {violin:0, cello:-0.5, harp:-3, guitar:7, nylon:8, eguitar:7, ukulele:10.5, mandolin:10.5, banjo:9.5, pizz:10.5, xylophone:10.5, marimba:9.5, vibes:7, glock:8, musicbox:8.5, kalimba:8.5, steeldrum:9, clarinet:-7.5, oboe:-4, sax:1, trumpet:-4, horn:-4.5, accordion:0.5, choir:-0.5};
  Object.keys(NIVEL).forEach(k => { const mk = INST[k].make; INST[k].make = () => { const v = mk(); v.volume.value = NIVEL[k]; return v; }; });
  const trimOf = id => (INST[id] && INST[id].g) || 0;
  const cache = {};
  let cur = 'piano', sampler = null, samplerReady = false, started = false;

  // Piano de muestras (Salamander) incluidas en la app (audio/salamander/); si faltan, se usa un sintetizador parecido.
  function loadPiano(onStatus){
    const urls = {};
    ['A0','C1','D#1','F#1','A1','C2','D#2','F#2','A2','C3','D#3','F#3','A3','C4','D#4','F#4','A4','C5','D#5','F#5','A5','C6','D#6','F#6','A6','C7']
      .forEach(n => urls[n] = n.replace('#','s') + '.mp3');
    onStatus('Cargando piano…');
    try{
      sampler = new Tone.Sampler({urls, baseUrl:'audio/salamander/', release:1,
        onload:() => { samplerReady = true; onStatus('Piano listo'); },
        onerror:() => onStatus('Piano')}).connect(out);
    }catch(e){ onStatus('Piano'); }
    setTimeout(() => { if(!samplerReady) onStatus('Piano'); }, 6000);  // sin muestras: suena el sintetizador
  }
  // Instrumento compartido del teclado (uno por tipo, conectado a la salida general)
  function node(id){
    if(id === 'piano' && samplerReady) return sampler;
    const k = id === 'piano' ? 'pianoFb' : id;
    return cache[k] || (cache[k] = INST[k].make().connect(out));
  }

  /* ---------- Pistas del Estudio ----------
     Cada pista tiene su propio instrumento + volumen + pan, y todas van a un bus común con limitador
     (así al sumar pistas el sonido no satura). El piano de cada pista reutiliza las muestras ya cargadas
     (no se descargan ni se decodifican otra vez). */
  const bus = new Tone.Volume(0), antesLimitador = new Tone.Gain(1), limiter = new Tone.Limiter(-1);
  limiter.connect(out); antesLimitador.connect(limiter);
  const tracks = new Set();
  const dbOf = v => (v <= MINDB ? -Infinity : v);
  const release = n => { try{ n.hardRelease ? n.hardRelease() : n.releaseAll(); }catch(e){} };

  /* ---------- Mezcla: efectos, cadenas y medidores ----------
     Nibel: cada pista tiene una ganancia de entrada y hasta cuatro efectos. Un efecto solo existe (y gasta procesador) mientras su cantidad sea mayor que cero. */
  const M = NS.Mezcla;

  // Nibel: une  inicio -> efectos activos -> fin ; al cambiar los efectos activos se vuelve a armar el camino del sonido
  function crearCadena(inicio, fin){
    let anteriores = [];
    return efectos => {
      try{ inicio.disconnect(); }catch(e){}
      anteriores.forEach(f => { try{ f.salida.disconnect(); }catch(e){} });
      anteriores = efectos;
      let origen = inicio;
      efectos.forEach(f => { origen.connect(f.entrada); origen = f.salida; });
      origen.connect(fin);
    };
  }

  // Nibel: una sala falsa hecha con ruido que se apaga poco a poco (semilla fija: suena igual cada vez)
  function crearImpulso(segundos, semilla){
    const tasa = Tone.getContext().sampleRate, largo = Math.max(2, Math.floor(tasa * segundos)), canales = [];
    for(let c = 0; c < 2; c++){
      const datos = new Float32Array(largo); let estado = (semilla + c * 7919) >>> 0, previo = 0;
      for(let i = 0; i < largo; i++){
        estado = (Math.imul(estado, 1664525) + 1013904223) >>> 0;
        previo = previo * 0.4 + (estado / 2147483648 - 1) * 0.6;
        datos[i] = previo * Math.pow(1 - i / largo, 3);
      }
      canales.push(datos);
    }
    return Tone.ToneAudioBuffer.fromArray(canales);
  }

  // Nibel: deja pasar el sonido original y le suma el efecto en la cantidad que se pida (de 0 a 1)
  function enviar(id, nodo){
    const entrada = new Tone.Gain(1), salida = new Tone.Gain(1), cantidad = new Tone.Gain(0);
    entrada.connect(salida); entrada.connect(nodo); nodo.connect(cantidad); cantidad.connect(salida);
    return {id, entrada, salida,
      poner(v){ cantidad.gain.value = v; },
      soltar(){ [entrada, salida, cantidad, nodo].forEach(n => { try{ n.dispose(); }catch(e){} }); }};
  }
  function crearEfecto(id, esGeneral){
    if(id === 'filtro'){
      const f = new Tone.Filter({frequency:20000, type:'lowpass', rolloff:-12});
      return {id, entrada:f, salida:f,
        poner(v){ f.frequency.value = 20000 * Math.pow(350 / 20000, v); },   // Nibel: de 20000 Hz (sin filtro) bajando hasta 350 Hz
        soltar(){ try{ f.dispose(); }catch(e){} }};
    }
    if(id === 'coro') return enviar(id, new Tone.Chorus({frequency:1.6, delayTime:3.5, depth:0.7}).start());
    if(id === 'eco') return enviar(id, new Tone.FeedbackDelay({delayTime:esGeneral ? 0.42 : 0.3, feedback:0.35}));
    return enviar('rev', new Tone.Convolver(crearImpulso(esGeneral ? 2.8 : 1.8, esGeneral ? 77 : 41)));
  }
  function crearEcualizador(){
    const eq = new Tone.EQ3({low:0, mid:0, high:0, lowFrequency:250, highFrequency:3500});
    return {id:'tono', entrada:eq, salida:eq,
      poner(g){ eq.low.value = g.graves; eq.high.value = g.agudos; },
      soltar(){ try{ eq.dispose(); }catch(e){} }};
  }

  /* Nibel: pone al dia los efectos de toda la cancion. `almacen` guarda los efectos ya creados y devuelve la clave del camino actual
     (si no cambia, no se vuelve a conectar nada). */
  function ajustarGeneral(general, almacen, armarCadena, claveActual){
    const g = M.limpiarGeneral(general), activos = [];
    if(g.graves !== 0 || g.agudos !== 0){
      const eq = almacen.tono || (almacen.tono = crearEcualizador());
      eq.poner(g); activos.push(eq);
    }
    if(g.eco > 0){
      const f = almacen.eco || (almacen.eco = crearEfecto('eco', true));
      f.poner(g.eco); activos.push(f);
    }
    if(g.rev > 0){
      const f = almacen.rev || (almacen.rev = crearEfecto('rev', true));
      f.poner(g.rev); activos.push(f);
    }
    const clave = activos.map(f => f.id).join(',');
    if(clave !== claveActual) armarCadena(activos);
    return clave;
  }
  const cadenaGeneral = crearCadena(bus, antesLimitador), efectosGenerales = {};
  let claveGeneral = '', medidorMaestro = null;
  cadenaGeneral([]);

  /* Nibel: medidor de nivel en estereo. Lee una ventana corta del sonido y devuelve el pico y la fuerza media (rms) de cada lado,
     en valores lineales (1 = 0 dB). Solo se crea cuando alguien lo pide. */
  function crearMedidor(origen){
    const contexto = Tone.getContext().rawContext, divisor = new Tone.Split(2), datos = new Float32Array(1024);
    const analisis = [0, 1].map(i => {
      const a = contexto.createAnalyser(); a.fftSize = 1024; a.smoothingTimeConstant = 0;
      divisor.connect(a, i, 0); return a;
    });
    origen.connect(divisor);
    return {
      leer(){
        const pico = [0, 0], rms = [0, 0];
        for(let c = 0; c < 2; c++){
          analisis[c].getFloatTimeDomainData(datos);
          let p = 0, suma = 0;
          for(let i = 0; i < datos.length; i++){ const v = datos[i], a = v < 0 ? -v : v; if(a > p) p = a; suma += v * v; }
          pico[c] = p; rms[c] = Math.sqrt(suma / datos.length);
        }
        return {pico, rms};
      },
      soltar(){ try{ origen.disconnect(divisor); }catch(e){} try{ divisor.dispose(); }catch(e){} }
    };
  }

  function sampleUrls(){ const u = {}; sampler._buffers._buffers.forEach((b, k) => { u[k] = b; }); return u; }
  // Crea un instrumento nuevo para la pista (o para el render) conectado a `dest`.
  function makeNode(id, dest){
    let n;
    if(id === 'piano' && samplerReady && sampler){
      try{ n = new Tone.Sampler({urls:sampleUrls(), release:1}); }catch(e){ n = null; }
    }
    if(!n) n = INST[id === 'piano' ? 'pianoFb' : id].make();
    if(n instanceof Tone.PolySynth) n.maxPolyphony = 16;   // limita la carga en teléfonos modestos
    return n.connect(dest);
  }

  function createTrack(o){
    let inst = INST[o.inst] && o.inst !== 'pianoFb' ? o.inst : 'piano', db = Number.isFinite(o.vol) ? o.vol : 0;
    let pv = Number.isFinite(o.pan) ? o.pan : 0;            // balance «en reposo» (el del deslizador)
    const ent = new Tone.Volume(M.limpiarGanancia(o.gan)), vol = new Tone.Volume(0), pan = new Tone.Panner(pv);   // ent: ganancia de entrada, antes de los efectos
    const cadenaFx = crearCadena(ent, vol), efectosPista = {};
    let claveFx = '', medidor = null;
    cadenaFx([]); vol.connect(pan); pan.connect(bus);
    let nd = null, key = null;
    const want = () => (inst === 'piano' ? (samplerReady ? 'sampler' : 'pianoFb') : inst);
    const retire = n => { release(n); setTimeout(() => { try{ n.dispose(); }catch(e){} }, 2500); };
    const get = () => {                                    // si el piano de muestras termina de cargar, la pista lo adopta sola
      const w = want();
      if(w !== key){ const old = nd; nd = makeNode(inst, ent); key = w; if(old) retire(old); }
      return nd;
    };
    const applyVol = () => { vol.volume.value = db <= MINDB ? -Infinity : db + trimOf(inst); };
    applyVol();
    const t = {
      get inst(){ return inst; },
      setInst(id){
        if(!INST[id] || id === 'pianoFb' || id === inst) return;
        inst = id; const old = nd; nd = null; key = null; if(old) retire(old); applyVol();
      },
      setVol(v){ db = v; applyVol(); },
      setPan(v){ pv = v; pan.pan.value = v; },
      setGanancia(v){ ent.volume.value = M.limpiarGanancia(v); },
      // Nibel: cantidades de 0 a 1 de {filtro, coro, eco, rev}; los que valen 0 no se crean ni gastan procesador
      setEfectos(valores){
        const fx = M.limpiarEfectos(valores), activos = [];
        M.EFECTOS_PISTA.forEach(e => {
          if(fx[e.id] <= 0) return;
          const f = efectosPista[e.id] || (efectosPista[e.id] = crearEfecto(e.id, false));
          f.poner(fx[e.id]); activos.push(f);
        });
        const clave = activos.map(f => f.id).join(',');
        if(clave !== claveFx){ claveFx = clave; cadenaFx(activos); }
      },
      // Nibel: nivel actual de la pista (despues del volumen y el balance): {pico:[izq, der], rms:[izq, der]}
      nivel(){ if(!medidor) medidor = crearMedidor(pan); return medidor.leer(); },
      /* Automatización en tiempo real: del valor a al valor b entre `time` y `time + secs` (segundos del reloj de audio).
         La curva completa vive en NS.Auto; quien reproduce pide un tramo corto cada vez. */
      autoVol(a, b, time, secs){
        const p = vol.volume, g = v => (v <= MINDB ? -Infinity : v + trimOf(inst));
        try{ p.setValueAtTime(g(a), time); if(b !== a && secs > 0) p.linearRampToValueAtTime(g(b), time + secs); }catch(e){}
      },
      autoPan(a, b, time, secs){
        const p = pan.pan;
        try{ p.setValueAtTime(a, time); if(b !== a && secs > 0) p.linearRampToValueAtTime(b, time + secs); }catch(e){}
      },
      // Quita lo programado por la automatización y devuelve volumen y balance a lo que marcan los deslizadores
      restaurar(){
        const n = Tone.now();
        try{ vol.volume.cancelScheduledValues(n); pan.pan.cancelScheduledValues(n); }catch(e){}
        applyVol(); pan.pan.value = pv;
      },
      // Nota con duración fija (reproducción del Roll, vista previa)
      play(midi, secs, time, vel){ NS.Audio.start(); try{ get().triggerAttackRelease(NS.Notes.tone(midi), secs, time, vel); }catch(e){} },
      // Nota sostenida mientras dura el toque (teclas del Roll)
      on(midi){ NS.Audio.start(); const n = get(), tn = NS.Notes.tone(midi), t0 = Tone.now(); try{ n.triggerAttack(tn, t0); }catch(e){} return {n, t:tn, t0}; },
      off(h){ try{ h.n.triggerRelease(h.t, Math.max(Tone.now(), h.t0 + 0.03)); }catch(e){} },
      silence(){ if(nd) release(nd); },
      reset(){ const old = nd; nd = null; key = null; if(old) retire(old); },
      dispose(){
        tracks.delete(t); const old = nd; nd = null; key = null; if(old) retire(old);
        setTimeout(() => {
          try{ vol.dispose(); pan.dispose(); ent.dispose(); }catch(e){}
          Object.keys(efectosPista).forEach(k => efectosPista[k].soltar());
          if(medidor) medidor.soltar();
        }, 2600);
      }
    };
    t.setEfectos(o.fx);
    tracks.add(t); return t;
  }

  let clickSynth = null;

  NS.Audio = {
    init(onStatus){ loadPiano(onStatus || (() => {})); },
    list(){ return Object.keys(INST).filter(k => k !== 'pianoFb').map(k => ({id:k, name:INST[k].name, group:INST[k].grp})); },
    // Lista agrupada por familia (para los <select> con <optgroup>): [{name, items:[{id, name}]}]
    groups(){ const l = this.list(); return GRUPOS.map(([id, name]) => ({name, items:l.filter(i => i.group === id)})).filter(g => g.items.length); },
    // Programa MIDI (General MIDI, 0-127) del instrumento, para exportar
    program(id){ return (INST[id] && INST[id].p) || 0; },
    setInstrument(id){ if(INST[id]) cur = id; },
    start(){
      if(!started){ started = true; return Tone.start(); }
      if(Tone.context.state !== 'running') return Tone.context.resume();
      return Promise.resolve();
    },
    on(midi){ this.start(); const n = node(cur), t = NS.Notes.tone(midi), t0 = Tone.now(); try{ n.triggerAttack(t, t0); }catch(e){} return {n, t, t0}; },
    // La liberación nunca puede ser anterior al ataque (si el contexto aún no corría, Tone la ignoraba y la nota quedaba sonando).
    off(h){ try{ h.n.triggerRelease(h.t, Math.max(Tone.now(), h.t0 + 0.03)); }catch(e){} },
    silence(){
      Object.values(cache).forEach(release);
      if(sampler){ try{ sampler.releaseAll(); }catch(e){} }
      tracks.forEach(t => t.silence());
    },
    // Último recurso (botón 🔇): además destruye los sintetizadores; se recrean solos al volver a tocar.
    panic(){
      this.silence();
      Object.keys(cache).forEach(k => { const n = cache[k]; delete cache[k]; setTimeout(() => { try{ n.dispose(); }catch(e){} }, 60); });
      tracks.forEach(t => t.reset());
    },
    blip(midi, secs){ this.start(); try{ node(cur).triggerAttackRelease(NS.Notes.tone(midi), secs || .4); }catch(e){} },

    // --- Estudio ---
    createTrack,
    setMaster(db){ bus.volume.value = dbOf(db); },
    // Nibel: efectos de toda la cancion {rev, eco, graves, agudos}
    setGeneral(g){ claveGeneral = ajustarGeneral(g, efectosGenerales, cadenaGeneral, claveGeneral); },
    // Nibel: nivel de la mezcla total justo antes del limitador (ahi es donde se ve si la suma de pistas se pasa de 0 dB)
    nivelMaestro(){ if(!medidorMaestro) medidorMaestro = crearMedidor(antesLimitador); return medidorMaestro.leer(); },
    // Nibel: cuantos dB esta bajando el limitador en este momento (0 = no esta actuando)
    reduccionLimitador(){ try{ const r = limiter.reduction; return Number.isFinite(r) ? r : 0; }catch(e){ return 0; } },
    // Metrónomo (se programa en el Transport con `time`)
    click(accent, time){
      if(!clickSynth){
        clickSynth = new Tone.Synth({oscillator:{type:'square'}, envelope:{attack:.001,decay:.05,sustain:0,release:.02}}).connect(out);
        clickSynth.volume.value = -14;
      }
      try{ clickSynth.triggerAttackRelease(accent ? 'C6' : 'C5', '32n', time); }catch(e){}
    },
    /* Render sin conexión con el mismo sonido de la app.
       specs: [{id, inst, vol, pan, gan?, fx?, autoVol?, autoPan?}] (autoVol / autoPan: eventos de NS.Auto.muestras)  notes: [{t: id de pista, p: MIDI, s: inicio en s, d: duración en s, v: fuerza (opcional)}]
       sampleRate: opcional (por defecto 44100)  general: opcional, efectos de toda la cancion {rev, eco, graves, agudos} */
    render(specs, notes, seconds, masterDb, sampleRate, general){
      return Tone.Offline(() => {
        const o = new Tone.Volume(-4).toDestination(), lim = new Tone.Limiter(-1).connect(o), antes = new Tone.Gain(1).connect(lim), b = new Tone.Volume(dbOf(masterDb || 0));
        ajustarGeneral(general, {}, crearCadena(b, antes), null);          // Nibel: mismos efectos de toda la cancion que suenan en la app
        specs.forEach(sp => {
          const mine = notes.filter(n => n.t === sp.id); if(!mine.length) return;
          const inst = INST[sp.inst] && sp.inst !== 'pianoFb' ? sp.inst : 'piano';
          const pn = new Tone.Panner(sp.pan || 0).connect(b), vl = new Tone.Volume(sp.vol <= MINDB ? -Infinity : (sp.vol || 0) + trimOf(inst)).connect(pn);
          const en = new Tone.Volume(M.limpiarGanancia(sp.gan)), fx = M.limpiarEfectos(sp.fx), activos = [];
          M.EFECTOS_PISTA.forEach(e => { if(fx[e.id] > 0){ const f = crearEfecto(e.id, false); f.poner(fx[e.id]); activos.push(f); } });
          crearCadena(en, vl)(activos);                                      // Nibel: ganancia de entrada y efectos de la pista, antes del volumen
          const nd = makeNode(inst, en);
          const aplica = (param, ev, conv) => { if(!ev || !ev.length) return; ev.forEach((e, i) => { const x = conv(e.v); if(i === 0 || e.salto) param.setValueAtTime(x, e.t); else param.linearRampToValueAtTime(x, e.t); }); };
          aplica(vl.volume, sp.autoVol, v => (v <= MINDB ? -Infinity : v + trimOf(inst)));
          aplica(pn.pan, sp.autoPan, v => v);
          mine.forEach(n => nd.triggerAttackRelease(NS.Notes.tone(n.p), n.d, n.s + 0.005, n.v));   // n.v (fuerza 0-1) es opcional
        });
      }, seconds, 2, sampleRate || 44100);
    }
  };
})(window.NS = window.NS || {});
