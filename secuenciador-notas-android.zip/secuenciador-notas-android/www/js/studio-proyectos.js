/* Estudio — varios proyectos: lista con información básica, crear, abrir, renombrar, duplicar y eliminar.
   Almacenamiento (localStorage, con el prefijo de storage.js):
     studio.index      → lista de proyectos con sus datos básicos (para dibujar la lista sin cargar cada proyecto)
     studio.cur        → id del proyecto abierto
     studio.p.<id>     → estado completo de cada proyecto (el mismo que devuelve ST.exportState())
   El proyecto único de versiones anteriores (clave «studio») se migra solo al primer arranque y se deja intacto como respaldo. */
(function(NS){
  'use strict';
  const ST = NS.Studio, S = NS.Storage, $ = id => document.getElementById(id);
  const K_INDEX = 'studio.index', K_CUR = 'studio.cur', K_OLD = 'studio', kp = id => 'studio.p.' + id;
  const MAXNAME = 40;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : many);

  let index = [], curId = null, lastSig = '', warned = false;

  const newId = () => 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const cleanName = v => String(v == null ? '' : v).trim().slice(0, MAXNAME);
  const entryOf = id => index.find(e => e.id === id);
  const byRecent = () => index.slice().sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const defaultName = () => {
    let n = index.length + 1; const used = new Set(index.map(e => e.name));
    while(used.has('Proyecto ' + n)) n++;
    return 'Proyecto ' + n;
  };

  // Datos básicos que se muestran en la lista, sacados del estado completo del proyecto
  function metaOf(st){
    const tracks = Array.isArray(st.tracks) ? st.tracks : [], ids = new Set(tracks.map(t => t.id));
    const notes = (st.roll && Array.isArray(st.roll.notes) ? st.roll.notes : []).filter(n => ids.has(n.t));
    const bpm = Number.isFinite(st.bpm) ? st.bpm : 120;
    const fin = notes.reduce((m, n) => Math.max(m, n.s + n.d), 0);
    return {tracks:tracks.length, notes:notes.length, bpm, secs:Math.round(fin * 60 / bpm / 8),
      insts:[...new Set(tracks.map(t => t.inst))], colors:tracks.map(t => t.color)};
  }
  // Firma del contenido (sin la posición de la vista del Roll): «modificado» solo cambia si cambió el contenido de verdad
  const sigOf = st => JSON.stringify([st.name, st.bpm, st.metro, st.master, st.general, st.tracks, st.roll && st.roll.notes]);

  const saveIndex = () => S.set(K_INDEX, index);
  function failed(){
    if(warned) return; warned = true;
    ST.toast('⚠ No hay espacio para guardar. Elimina proyectos que ya no uses.');
  }

  /* ---------- Guardado del proyecto abierto (lo llama studio-core.js) ---------- */
  ST.persist = () => {
    if(!curId) return;
    const st = ST.exportState(), sig = sigOf(st);
    if(!S.set(kp(curId), st)){ failed(); return; }
    let e = entryOf(curId);
    if(!e){ e = {id:curId, name:'', created:Date.now(), updated:Date.now()}; index.push(e); }
    else if(sig !== lastSig) e.updated = Date.now();
    lastSig = sig;
    Object.assign(e, {name:cleanName(st.name)}, metaOf(st));
    saveIndex();
  };

  /* ---------- Operaciones ---------- */
  // Carga un estado en el Estudio como proyecto abierto (sin guardar nada todavía)
  function enter(id, state){
    curId = id; S.set(K_CUR, id);
    ST.stop(); ST.load(state);
    lastSig = sigOf(ST.exportState());
  }
  // keep = true: se cambia de proyecto desde dentro del Estudio y se queda en la misma sección (Roll / Pistas / Proyecto / Cascada)
  function open(id, quiet, keep){
    if(id === curId){ if(!keep) ST.showSub('roll'); return; }
    const st = S.get(kp(id), null);
    if(!st){
      ST.toast('No se pudo abrir ese proyecto (sus datos no están).');
      index = index.filter(e => e.id !== id); saveIndex(); draw(); return;
    }
    ST.saveNow();                                        // guarda el proyecto que se deja
    enter(id, st); if(!keep) ST.showSub('roll');
    if(!quiet) ST.toast('Abierto: ' + (ST.name || 'Sin título'));
  }
  // Crea un proyecto (vacío o con un estado dado), lo deja guardado y lo abre
  function create(name, state){
    ST.saveNow();
    const id = newId();
    enter(id, state || null);
    ST.name = cleanName(name) || defaultName();
    ST.listeners.forEach(f => f());                      // refresca el nombre en pantalla
    ST.saveNow(); ST.showSub('roll');
    return id;
  }
  // Tras abrir o crear desde el menú principal, se entra al modo Estudio (eliminar no navega: usa open/create internos)
  const irAlEstudio = () => { const St = NS.State; if(St && St.data.tab !== 'studio' && St.data.tab !== 'cascada') St.set({tab:'studio'}); };
  function abrir(id){ open(id); if(entryOf(id)) irAlEstudio(); }   // si el proyecto no existe, open() ya avisó y lo quitó de la lista
  // Cambio rápido desde la barra del modo: mantiene la sección y, si se está en la Cascada, la actualiza
  function cambiar(id){
    if(id === curId) return;
    open(id, false, true);
    if(NS.State && NS.State.data.tab === 'cascada' && NS.Cascada) NS.Cascada.alEntrar();
  }
  async function nuevo(){
    const name = await ST.ask({title:'Nuevo proyecto', msg:'Se abrirá vacío; el proyecto actual queda guardado en la lista.', input:defaultName(), max:MAXNAME, ok:'Crear'});
    if(name === null) return;
    create(name); irAlEstudio(); ST.toast('Proyecto creado');
  }
  function agregar(estado, nombre){
    create(nombre, estado); irAlEstudio(); ST.toast('Proyecto importado');
  }
  async function renombrar(id){
    const e = entryOf(id); if(!e) return;
    const name = await ST.ask({title:'Nombre del proyecto', input:e.name, max:MAXNAME, ok:'Guardar'});
    if(name === null) return;
    const nuevoNombre = cleanName(name);
    if(id === curId){ ST.name = nuevoNombre; ST.listeners.forEach(f => f()); ST.saveNow(); }
    else{
      const st = S.get(kp(id), null);
      if(st){ st.name = nuevoNombre; S.set(kp(id), st); }
      e.name = nuevoNombre; saveIndex();
    }
    draw();
  }
  function duplicar(id){
    ST.saveNow();
    const st = S.get(kp(id), null), e = entryOf(id); if(!st || !e){ ST.toast('No se pudo duplicar.'); return; }
    const copy = JSON.parse(JSON.stringify(st)), nid = newId(), now = Date.now();
    copy.name = cleanName('Copia de ' + (e.name || 'Sin título'));
    if(!S.set(kp(nid), copy)){ failed(); return; }
    index.push(Object.assign({id:nid, name:copy.name, created:now, updated:now}, metaOf(copy)));
    saveIndex(); draw(); ST.toast('Duplicado: ' + copy.name);
  }
  async function eliminar(id){
    const e = entryOf(id); if(!e) return;
    const ok = await ST.ask({title:'Eliminar proyecto', msg:'Se eliminará «' + (e.name || 'Sin título') + '» con todas sus pistas y notas. Esto no se puede deshacer.', ok:'Eliminar'});
    if(!ok) return;
    const eraCurrent = id === curId;
    if(eraCurrent){ ST.stop(); curId = null; }          // curId nulo: el guardado automático no vuelve a escribirlo
    S.remove(kp(id)); index = index.filter(x => x.id !== id); saveIndex();
    if(eraCurrent){
      const next = byRecent()[0];
      if(next) open(next.id, true); else create('Proyecto 1');
    }
    draw(); ST.toast('Proyecto eliminado');
  }

  /* ---------- Lista ---------- */
  const fmtDur = s => s < 60 ? s + ' s' : Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') + ' min';
  const fmtDate = t => {
    const d = new Date(t || Date.now()), hoy = new Date();
    const mismoDia = d.toDateString() === hoy.toDateString();
    return mismoDia ? 'Hoy ' + d.toLocaleTimeString('es', {hour:'2-digit', minute:'2-digit'})
      : d.toLocaleDateString('es', {day:'numeric', month:'short', year:d.getFullYear() === hoy.getFullYear() ? undefined : 'numeric'});
  };
  function draw(){
    const list = $('stProjList'); if(!list) return;
    const items = byRecent();
    $('stProjCount').textContent = 'Proyectos (' + items.length + ')';
    list.innerHTML = items.map(e => {
      const cur = e.id === curId, empty = !e.notes;
      const insts = (e.insts || []).map(i => ST.instName(i));
      const shown = insts.slice(0, 3).map(n => '<span class="pill stInst">' + esc(n) + '</span>').join('') + (insts.length > 3 ? '<span class="pill stInst">+' + (insts.length - 3) + '</span>' : '');
      const dots = (e.colors || []).map(c => '<i style="background:' + esc(/^#[0-9a-f]{6}$/i.test(c) ? c : '#888') + '"></i>').join('');
      return '<div class="mcard stProj' + (cur ? ' cur' : '') + '" data-id="' + esc(e.id) + '">' +
        '<div class="mcTop"><b>' + esc(e.name || 'Sin título') + '</b>' + (cur ? '<span class="stBadge">Abierto</span>' : '') + '</div>' +
        '<div class="mcMeta">🎚 ' + plural(e.tracks || 0, 'pista', 'pistas') + ' · 🎵 ' + (empty ? 'vacío' : plural(e.notes, 'nota', 'notas')) +
          ' · ♩ ' + e.bpm + ' BPM' + (empty ? '' : ' · ⏱ ' + fmtDur(e.secs || 0)) + '</div>' +
        '<div class="stProjRow"><span class="stDots">' + dots + '</span>' + shown + '</div>' +
        '<div class="mcMeta">Modificado: ' + fmtDate(e.updated) + '</div>' +
        '<div class="cardBtns">' +
          '<button class="btn sm' + (cur ? '' : ' primary') + '" data-a="open">' + (cur ? '🎹 Seguir editando' : '▶ Abrir') + '</button>' +
          '<button class="btn sm" data-a="rename">✏️ Nombre</button>' +
          '<button class="btn sm" data-a="dup">⧉ Duplicar</button>' +
          '<button class="btn sm danger" data-a="del" aria-label="Eliminar">🗑</button>' +
        '</div></div>';
    }).join('');
  }
  $('stProjList').addEventListener('click', e => {
    const card = e.target.closest('.stProj'); if(!card) return;
    const id = card.dataset.id, b = e.target.closest('[data-a]'), a = b ? b.dataset.a : 'open';   // tocar la tarjeta también abre
    if(a === 'open') abrir(id);
    else if(a === 'rename') renombrar(id);
    else if(a === 'dup') duplicar(id);
    else if(a === 'del') eliminar(id);
  });
  $('stProjNew').addEventListener('click', nuevo);

  // Selector rápido (botón ⇄ de la barra del Modo Estudio)
  function elegir(){
    ST.saveNow();                                        // los datos básicos de la lista quedan al día
    NS.Sheet.open('Cambiar de proyecto', null, box => {
      box.innerHTML = '<button class="btn primary" data-new="1">＋ Nuevo proyecto</button>' + byRecent().map(e => {
        const cur = e.id === curId, empty = !e.notes;
        return '<button class="mcard' + (cur ? ' cur' : '') + '" data-id="' + esc(e.id) + '"><div class="mcTop"><b>' + esc(e.name || 'Sin título') + '</b>' +
          (cur ? '<span class="stBadge">Abierto</span>' : '<small>' + fmtDate(e.updated) + '</small>') + '</div>' +
          '<div class="mcMeta">🎚 ' + plural(e.tracks || 0, 'pista', 'pistas') + ' · 🎵 ' + (empty ? 'vacío' : plural(e.notes, 'nota', 'notas')) + ' · ♩ ' + e.bpm + ' BPM</div></button>';
      }).join('');
      box.addEventListener('click', e => {
        const b = e.target.closest('button'); if(!b) return;
        NS.Sheet.close();
        if(b.dataset.new) nuevo(); else cambiar(b.dataset.id);
      });
    });
  }

  // Al mostrar la lista (menú principal) se guarda el proyecto abierto, para que sus datos básicos estén al día, y se redibuja
  const mostrarLista = () => { ST.saveNow(); draw(); };

  /* ---------- Arranque ---------- */
  function iniciar(){
    const saved = S.get(K_INDEX, []);
    index = (Array.isArray(saved) ? saved : []).filter(e => e && typeof e.id === 'string' && S.get(kp(e.id), null));
    if(index.length !== (Array.isArray(saved) ? saved.length : 0)) saveIndex();
    if(!index.length){
      // Primera vez con proyectos múltiples: el proyecto único anterior pasa a ser el primero de la lista
      const old = S.get(K_OLD, null), id = newId();
      curId = id;
      ST.load(old);
      if(old && !ST.name) ST.name = 'Mi proyecto';
      lastSig = '';                                      // se escribe ya, con su fecha de creación
      ST.persist();
      S.set(K_CUR, id);
      return;
    }
    const want = S.get(K_CUR, null), start = entryOf(want) ? want : byRecent()[0].id;
    curId = start; S.set(K_CUR, start);
    ST.load(S.get(kp(start), null));
    lastSig = sigOf(ST.exportState());
  }

  ST.proyectos = {iniciar, nuevo, agregar, abrir, cambiar, elegir, mostrarLista, list:() => byRecent(), actual:() => curId};
})(window.NS = window.NS || {});
