/* Mezcla: datos y validaciones (sin pantalla ni audio).
   Nibel: aqui viven los limites y la limpieza de la ganancia y los efectos, para que el Estudio, la Cascada y el audio usen las mismas reglas.
   Cada pista guarda:  gan (ganancia de entrada en dB)  y  fx = {rev, eco, coro, filtro}  (cada uno de 0 a 1).
   Toda la cancion guarda:  general = {rev, eco, graves, agudos}  (rev y eco de 0 a 1; graves y agudos en dB). */
(function(NS){
  'use strict';
  const GANANCIA_MIN = -12, GANANCIA_MAX = 12;
  const TONO_MIN = -12, TONO_MAX = 12;

  // Nibel: el orden de las listas es el orden en que el sonido pasa por los efectos (la reverb siempre al final)
  const EFECTOS_PISTA = [
    {id:'filtro', nombre:'Filtro', ayuda:'Apaga los agudos: mas a la derecha, mas apagado.'},
    {id:'coro', nombre:'Coro', ayuda:'Duplica el sonido para que suene mas ancho.'},
    {id:'eco', nombre:'Eco', ayuda:'Repite el sonido unos instantes despues.'},
    {id:'rev', nombre:'Reverb', ayuda:'Sensacion de sala: el sonido se alarga.'}
  ];
  const EFECTOS_GENERALES = [
    {id:'rev', nombre:'Reverb', ayuda:'Sala para toda la cancion.', tipo:'cantidad'},
    {id:'eco', nombre:'Eco', ayuda:'Eco para toda la cancion.', tipo:'cantidad'},
    {id:'graves', nombre:'Graves', ayuda:'Sube o baja los sonidos graves.', tipo:'tono'},
    {id:'agudos', nombre:'Agudos', ayuda:'Sube o baja los sonidos agudos.', tipo:'tono'}
  ];

  const limitar = (v, minimo, maximo, porDefecto) => (Number.isFinite(v) ? Math.max(minimo, Math.min(maximo, v)) : porDefecto);
  const redondear = (v, paso) => Math.round(v / paso) * paso;

  function limpiarGanancia(valor){
    return redondear(limitar(valor, GANANCIA_MIN, GANANCIA_MAX, 0), 0.5);
  }
  function efectosVacios(){
    return {filtro:0, coro:0, eco:0, rev:0};
  }
  // Nibel: acepta cualquier cosa (proyectos viejos, archivos importados) y devuelve siempre un objeto valido
  function limpiarEfectos(crudo){
    const salida = efectosVacios();
    if(!crudo || typeof crudo !== 'object') return salida;
    EFECTOS_PISTA.forEach(e => { salida[e.id] = redondear(limitar(crudo[e.id], 0, 1, 0), 0.01); });
    return salida;
  }
  const hayEfectos = efectos => !!efectos && EFECTOS_PISTA.some(e => efectos[e.id] > 0);

  function generalVacio(){
    return {rev:0, eco:0, graves:0, agudos:0};
  }
  function limpiarGeneral(crudo){
    const salida = generalVacio();
    if(!crudo || typeof crudo !== 'object') return salida;
    salida.rev = redondear(limitar(crudo.rev, 0, 1, 0), 0.01);
    salida.eco = redondear(limitar(crudo.eco, 0, 1, 0), 0.01);
    salida.graves = Math.round(limitar(crudo.graves, TONO_MIN, TONO_MAX, 0));
    salida.agudos = Math.round(limitar(crudo.agudos, TONO_MIN, TONO_MAX, 0));
    return salida;
  }
  const hayGeneral = general => !!general && (general.rev > 0 || general.eco > 0 || general.graves !== 0 || general.agudos !== 0);

  NS.Mezcla = {
    GANANCIA_MIN, GANANCIA_MAX, TONO_MIN, TONO_MAX, EFECTOS_PISTA, EFECTOS_GENERALES,
    limpiarGanancia, efectosVacios, limpiarEfectos, hayEfectos, generalVacio, limpiarGeneral, hayGeneral
  };
})(window.NS = window.NS || {});
