/* Nibel: Lectores de la Cascada. Convierten cualquier fuente en una "cancion" lista para animar:
   { nombre, bpm, duracion, pistas:[{nombre, inst, color, vol, pan, estaOculta}], notas:[{pista, p, i, d}], compases:[{t, fin, etiqueta, tiempos}], aviso }
   Todos los tiempos (i = inicio, d = duracion, t, fin) estan en segundos. p es el numero MIDI de la nota (C4 = 60).
   Fuentes: proyecto del Estudio (JSON, o un archivo JS que lo contenga), partitura MusicXML (.musicxml / .xml) y MusicXML comprimido (.mxl). */
(function(NS){
  'use strict';
  const NOTA_MINIMA = 12, NOTA_MAXIMA = 119;
  const MAXIMO_PISTAS = 8;
  const DURACION_MINIMA = 0.05;
  const PALETA_PISTAS = ['#4dd0a1', '#64b5f6', '#ba68c8', '#ff8a65', '#f06292', '#aed581', '#4dd0e1', '#a1887f'];
  const LETRAS_BASE = {C:0, D:2, E:4, F:5, G:7, A:9, B:11};
  const FACTORES_NEGRA = {whole:4, half:2, quarter:1, eighth:0.5, '16th':0.25, '32nd':0.125};

  const limitar = (v, bajo, alto, defecto) => (Number.isFinite(v) ? Math.max(bajo, Math.min(alto, v)) : defecto);
  const recortarNombre = (texto, defecto) => String(texto || '').trim().slice(0, 20) || defecto;
  const hayInstrumento = id => NS.Audio.list().some(i => i.id === id);

  /* ---------- Instrumento que mas se parece al de la partitura ---------- */
  // Nibel: el programa MIDI va de 1 a 128 (como lo escribe MusicXML)
  function instrumentoDePrograma(programa, nombre){
    let id = 'piano';
    if(Number.isFinite(programa)){
      const p = programa - 1;
      if(p === 4 || p === 5) id = 'electric';
      else if(p === 8 || p === 14 || p === 15) id = 'bell';          // celesta, campanas, dulcémele
      else if(p === 9) id = 'glock';
      else if(p === 10) id = 'musicbox';
      else if(p === 11) id = 'vibes';
      else if(p === 12) id = 'marimba';
      else if(p === 13) id = 'xylophone';
      else if(p >= 16 && p <= 20) id = 'organ';
      else if(p >= 21 && p <= 23) id = 'accordion';                   // acordeón, armónica, bandoneón
      else if(p === 24) id = 'nylon';
      else if(p === 25) id = 'guitar';
      else if(p >= 26 && p <= 31) id = 'eguitar';
      else if(p >= 32 && p <= 39) id = 'bass';
      else if(p === 40 || p === 41) id = 'violin';                    // violín, viola
      else if(p === 42 || p === 43) id = 'cello';                     // chelo, contrabajo
      else if(p === 45) id = 'pizz';
      else if(p === 46) id = 'harp';
      else if(p >= 40 && p <= 51) id = 'strings';
      else if(p >= 52 && p <= 54) id = 'choir';
      else if(p === 55) id = 'strings';
      else if(p >= 56 && p <= 59) id = 'trumpet';                     // trompeta, trombón, tuba, trompeta con sordina
      else if(p === 60) id = 'horn';
      else if(p >= 61 && p <= 63) id = 'trumpet';
      else if(p >= 64 && p <= 67) id = 'sax';
      else if(p === 68 || p === 69) id = 'oboe';                      // oboe, corno inglés
      else if(p === 70 || p === 71) id = 'clarinet';                  // fagot, clarinete
      else if(p >= 72 && p <= 79) id = 'flute';
      else if(p >= 80 && p <= 87) id = 'retro';
      else if(p >= 88 && p <= 103) id = 'pad';
      else if(p === 105) id = 'banjo';
      else if(p === 108) id = 'kalimba';
      else if(p === 114) id = 'steeldrum';
    }else{
      const t = String(nombre || '').toLowerCase();
      if(/flaut|flute|fl[uû]te|piccolo|flautín/.test(t)) id = 'flute';
      else if(/cello|chelo|violonc|contrabaj|double bass/.test(t)) id = 'cello';
      else if(/viol|fiddle/.test(t)) id = 'violin';                   // violín, viola
      else if(/pizz/.test(t)) id = 'pizz';
      else if(/string|cuerda/.test(t)) id = 'strings';
      else if(/organ|[oó]rgano/.test(t)) id = 'organ';
      else if(/acord|accordion|armónica|harmonica/.test(t)) id = 'accordion';
      else if(/harp|arpa/.test(t)) id = 'harp';
      else if(/ukul|ukel/.test(t)) id = 'ukulele';
      else if(/mandol/.test(t)) id = 'mandolin';
      else if(/banjo/.test(t)) id = 'banjo';
      else if(/guitar/.test(t)) id = /electr|el[eé]ctr/.test(t) ? 'eguitar' : /nylon|cl[aá]sic|classic/.test(t) ? 'nylon' : 'guitar';
      else if(/xil[oó]f|xylo/.test(t)) id = 'xylophone';
      else if(/marimba/.test(t)) id = 'marimba';
      else if(/vibr[aá]f|vibraph|vibes/.test(t)) id = 'vibes';
      else if(/glock/.test(t)) id = 'glock';
      else if(/music box|caja de m[uú]sica/.test(t)) id = 'musicbox';
      else if(/kalimba|sanza/.test(t)) id = 'kalimba';
      else if(/steel ?drum|steel ?pan/.test(t)) id = 'steeldrum';
      else if(/clarin|clarinet/.test(t)) id = 'clarinet';
      else if(/oboe|oboé|english horn|corno ingl/.test(t)) id = 'oboe';
      else if(/sax/.test(t)) id = 'sax';
      else if(/trump|trompet|cornet|trombone|trombón|tuba/.test(t)) id = 'trumpet';
      else if(/horn|corno/.test(t)) id = 'horn';
      else if(/choir|coro|voz|voice|vocal/.test(t)) id = 'choir';
      else if(/bass|bajo/.test(t)) id = 'bass';
      else if(/bell|campan|celesta/.test(t)) id = 'bell';
      else if(/synth|sinte/.test(t)) id = 'synth';
    }
    return hayInstrumento(id) ? id : 'piano';
  }

  /* ---------- Proyecto del Estudio (el estado exportado por NS.Studio.exportState o el archivo JSON) ---------- */
  function cancionDeProyecto(datos, nombreArchivo){
    if(!datos || !Array.isArray(datos.tracks) || !datos.roll || !Array.isArray(datos.roll.notes)) throw new Error('Ese archivo no es un proyecto del Estudio.');
    const bpm = limitar(datos.bpm, 40, 240, 120), segundosPorUnidad = 60 / bpm / 8;   // Nibel: una negra mide 8 unidades
    const indicesPorId = new Map(), pistas = [];
    const haySolo = datos.tracks.some(r => r && r.solo);
    for(const r of datos.tracks){
      if(pistas.length >= MAXIMO_PISTAS) break;
      if(!r || typeof r !== 'object' || indicesPorId.has(r.id)) continue;
      indicesPorId.set(r.id, pistas.length);
      pistas.push({
        nombre:recortarNombre(r.name, 'Pista ' + (pistas.length + 1)),
        inst:hayInstrumento(r.inst) ? r.inst : 'piano',
        color:typeof r.color === 'string' && /^#[0-9a-f]{6}$/i.test(r.color) ? r.color : PALETA_PISTAS[pistas.length % PALETA_PISTAS.length],
        vol:limitar(r.vol, -40, 6, 0), pan:limitar(r.pan, -1, 1, 0), gan:NS.Mezcla.limpiarGanancia(r.gan), fx:NS.Mezcla.limpiarEfectos(r.fx), auto:NS.Auto ? NS.Auto.limpiar(r.auto) : undefined,   // curvas de automatización del Estudio
        estaOculta:!!r.mute || (haySolo && !r.solo)                       // Nibel: igual que en el Estudio, lo silenciado no se ve ni suena
      });
    }
    if(!pistas.length) throw new Error('El proyecto no tiene pistas.');
    const notas = [];
    for(const n of datos.roll.notes){
      if(!n || !indicesPorId.has(n.t)) continue;
      if(!Number.isInteger(n.p) || n.p < NOTA_MINIMA || n.p > NOTA_MAXIMA) continue;
      if(!Number.isFinite(n.s) || n.s < 0 || !Number.isFinite(n.d) || n.d <= 0) continue;
      notas.push({pista:indicesPorId.get(n.t), p:n.p, i:n.s * segundosPorUnidad, d:Math.max(DURACION_MINIMA, n.d * segundosPorUnidad)});
    }
    if(!notas.length) throw new Error('El proyecto no tiene notas todavia.');
    const fin = Math.max(...notas.map(n => n.i + n.d)), segundosPorCompas = 32 * segundosPorUnidad, compases = [];
    for(let k = 0, total = Math.ceil(fin / segundosPorCompas); k < total; k++){
      compases.push({t:k * segundosPorCompas, fin:(k + 1) * segundosPorCompas, etiqueta:String(k + 1), tiempos:4});
    }
    const nombre = String(datos.name || '').trim().slice(0, 40) || nombreArchivo || 'Proyecto';
    return {nombre, bpm, pistas, notas, compases, aviso:'', segundosPorUnidad};
  }

  /* ---------- Partitura MusicXML ---------- */
  const hijos = (el, nombre) => Array.from(el.children).filter(h => h.nodeName === nombre);
  const primero = (el, nombre) => (el ? hijos(el, nombre)[0] || null : null);
  const textoDe = el => (el ? el.textContent.trim() : '');
  const numeroDe = (el, nombre, defecto) => { const v = parseFloat(textoDe(primero(el, nombre))); return Number.isFinite(v) ? v : defecto; };

  // Nibel: lee una parte (un instrumento) con sus notas, el largo de cada compas y los cambios de tempo.
  // Las posiciones se guardan en negras (una negra = 1) dentro de su compas; luego se convierten a segundos.
  function leerParte(parteEl){
    const notasParte = [], largosCompas = [], tiemposCompas = [], etiquetas = [], tempos = [], abiertas = new Map();
    let divisiones = 1, latidos = 4, tipoLatido = 4, metronomo = null;
    hijos(parteEl, 'measure').forEach((compasEl, m) => {
      let cursor = 0, ultimoInicio = 0, maximo = 0;
      etiquetas.push(compasEl.getAttribute('number'));
      const anotarTempo = sonido => {
        const bpm = parseFloat(sonido.getAttribute('tempo'));
        if(bpm > 0) tempos.push({m, q:cursor / divisiones, bpm});
      };
      for(const h of Array.from(compasEl.children)){
        const nombre = h.nodeName;
        if(nombre === 'attributes'){
          const d = numeroDe(h, 'divisions', 0); if(d > 0) divisiones = d;
          const tiempo = primero(h, 'time');
          if(tiempo){
            const a = parseInt(textoDe(primero(tiempo, 'beats')), 10), b = parseInt(textoDe(primero(tiempo, 'beat-type')), 10);
            if(a > 0 && b > 0){ latidos = a; tipoLatido = b; }
          }
        }else if(nombre === 'direction'){
          hijos(h, 'sound').forEach(anotarTempo);
          if(!metronomo){
            const marca = h.getElementsByTagName('per-minute')[0], unidad = h.getElementsByTagName('beat-unit')[0];
            const bpm = marca ? parseFloat(marca.textContent) : NaN;
            if(bpm > 0 && unidad && FACTORES_NEGRA[textoDe(unidad)]) metronomo = bpm * FACTORES_NEGRA[textoDe(unidad)] * (h.getElementsByTagName('beat-unit-dot').length ? 1.5 : 1);
          }
        }else if(nombre === 'sound'){
          anotarTempo(h);
        }else if(nombre === 'backup'){
          cursor -= numeroDe(h, 'duration', 0);
        }else if(nombre === 'forward'){
          cursor += numeroDe(h, 'duration', 0); maximo = Math.max(maximo, cursor);
        }else if(nombre === 'note'){
          const esAcorde = !!primero(h, 'chord'), esAdorno = !!primero(h, 'grace'), esNotaGuia = !!primero(h, 'cue');
          const duracion = numeroDe(h, 'duration', 0), inicio = esAcorde ? ultimoInicio : cursor, tono = primero(h, 'pitch');
          if(tono && !esAdorno && !esNotaGuia && duracion > 0){
            const paso = textoDe(primero(tono, 'step')), octava = numeroDe(tono, 'octave', NaN);
            if(LETRAS_BASE[paso] !== undefined && Number.isFinite(octava)){
              const p = (octava + 1) * 12 + LETRAS_BASE[paso] + Math.round(numeroDe(tono, 'alter', 0));
              if(p >= NOTA_MINIMA && p <= NOTA_MAXIMA){
                let ligas = hijos(h, 'tie').map(x => x.getAttribute('type'));
                if(!ligas.length){ const nota = primero(h, 'notations'); if(nota) ligas = hijos(nota, 'tied').map(x => x.getAttribute('type')); }
                const clave = p + '|' + textoDe(primero(h, 'voice')) + '|' + textoDe(primero(h, 'staff'));
                const previa = ligas.includes('stop') ? abiertas.get(clave) : null;
                if(previa){                                              // Nibel: una nota ligada se une con la anterior en una sola, mas larga
                  previa.d += duracion / divisiones;
                  if(!ligas.includes('start')) abiertas.delete(clave);
                }else{
                  const nota = {m, q:inicio / divisiones, d:duracion / divisiones, p};
                  notasParte.push(nota);
                  if(ligas.includes('start')) abiertas.set(clave, nota); else abiertas.delete(clave);
                }
              }
            }
          }
          if(!esAcorde && !esAdorno){ ultimoInicio = cursor; cursor += duracion; maximo = Math.max(maximo, cursor); }
        }
      }
      largosCompas.push(maximo > 0 ? maximo / divisiones : latidos * 4 / tipoLatido);
      tiemposCompas.push(latidos);
    });
    return {notas:notasParte, largosCompas, tiemposCompas, etiquetas, tempos, metronomo};
  }

  function cancionDeMusicXml(texto, nombreArchivo){
    const doc = new DOMParser().parseFromString(texto, 'application/xml');
    if(doc.getElementsByTagName('parsererror').length) throw new Error('La partitura esta danada o no es MusicXML.');
    const raiz = doc.documentElement;
    if(raiz.nodeName === 'score-timewise') throw new Error('Esta partitura esta en formato timewise. Exportala como partwise.');
    if(raiz.nodeName !== 'score-partwise') throw new Error('Ese archivo no es una partitura MusicXML.');

    // Nombre de cada parte y su instrumento
    const infoPartes = new Map();
    hijos(primero(raiz, 'part-list') || raiz, 'score-part').forEach(sp => {
      const midi = primero(sp, 'midi-instrument');
      infoPartes.set(sp.getAttribute('id'), {nombre:textoDe(primero(sp, 'part-name')), programa:midi ? numeroDe(midi, 'midi-program', NaN) : NaN});
    });
    const elementosPartes = hijos(raiz, 'part');
    if(!elementosPartes.length) throw new Error('La partitura no tiene partes.');
    const partes = elementosPartes.map(el => Object.assign(leerParte(el), {id:el.getAttribute('id')})).filter(p => p.notas.length);
    if(!partes.length) throw new Error('La partitura no tiene notas.');

    // Largo de cada compas (el mayor entre todas las partes) y donde empieza cada uno, medido en negras
    const totalCompases = Math.max(...partes.map(p => p.largosCompas.length));
    const inicios = [0];
    for(let m = 0; m < totalCompases; m++){
      const largos = partes.map(p => p.largosCompas[m]).filter(v => v > 0);
      inicios.push(inicios[m] + (largos.length ? Math.max(...largos) : 4));
    }

    // Mapa de tempo: tramos con tempo constante para pasar de negras a segundos
    const eventosTempo = [];
    partes.forEach(p => p.tempos.forEach(t => eventosTempo.push({q:inicios[t.m] + t.q, bpm:t.bpm})));
    eventosTempo.sort((a, b) => a.q - b.q);
    const metronomo = partes.map(p => p.metronomo).find(v => v > 0);
    const bpmInicial = limitar(eventosTempo.length && eventosTempo[0].q < 0.001 ? eventosTempo[0].bpm : metronomo, 20, 400, 120);
    const tramos = [{q:0, t:0, bpm:bpmInicial}];
    for(const e of eventosTempo){
      const ultimo = tramos[tramos.length - 1];
      if(e.q < 0.001 || Math.abs(e.bpm - ultimo.bpm) < 0.01) continue;
      tramos.push({q:e.q, t:ultimo.t + (e.q - ultimo.q) * 60 / ultimo.bpm, bpm:limitar(e.bpm, 20, 400, 120)});
    }
    const aSegundos = q => {
      let tramo = tramos[0];
      for(const x of tramos){ if(x.q <= q) tramo = x; else break; }
      return tramo.t + (q - tramo.q) * 60 / tramo.bpm;
    };

    // Pistas y notas
    const pistas = [], notas = [];
    let aviso = '';
    partes.forEach((parte, k) => {
      if(k >= MAXIMO_PISTAS){ aviso = 'Solo se leyeron las primeras ' + MAXIMO_PISTAS + ' partes.'; return; }
      const info = infoPartes.get(parte.id) || {nombre:'', programa:NaN};
      pistas.push({nombre:recortarNombre(info.nombre, 'Parte ' + (k + 1)), inst:instrumentoDePrograma(info.programa, info.nombre),
        color:PALETA_PISTAS[k % PALETA_PISTAS.length], vol:0, pan:0, estaOculta:false});
      for(const n of parte.notas){
        const q0 = inicios[n.m] + n.q, i = aSegundos(q0);
        notas.push({pista:k, p:n.p, i, d:Math.max(DURACION_MINIMA, aSegundos(q0 + n.d) - i)});
      }
    });
    const compases = [];
    for(let m = 0; m < totalCompases; m++){
      const etiqueta = partes[0].etiquetas[m];
      compases.push({t:aSegundos(inicios[m]), fin:aSegundos(inicios[m + 1]), etiqueta:/^\d+$/.test(etiqueta || '') ? etiqueta : String(m + 1),
        tiempos:partes[0].tiemposCompas[m] || 4});
    }
    const titulo = textoDe(primero(primero(raiz, 'work'), 'work-title')) || textoDe(primero(raiz, 'movement-title'));
    return {nombre:(titulo || nombreArchivo || 'Partitura').slice(0, 40), bpm:bpmInicial, pistas, notas, compases, aviso};
  }

  /* ---------- MusicXML comprimido (.mxl): un zip con la partitura adentro ---------- */
  async function descomprimir(bytes){
    if(typeof DecompressionStream !== 'function') throw new Error('Este dispositivo no puede abrir archivos .mxl. Exporta la partitura como .musicxml.');
    const flujo = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(flujo).arrayBuffer());
  }
  async function extraerMxl(bytes){
    const vista = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), decodificador = new TextDecoder('utf-8');
    let fin = -1;
    for(let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65600); i--){ if(vista.getUint32(i, true) === 0x06054b50){ fin = i; break; } }
    if(fin < 0) throw new Error('El archivo .mxl esta danado.');
    const cantidad = vista.getUint16(fin + 10, true), entradas = new Map();
    let pos = vista.getUint32(fin + 16, true);
    for(let k = 0; k < cantidad; k++){
      if(pos + 46 > bytes.length || vista.getUint32(pos, true) !== 0x02014b50) break;
      const metodo = vista.getUint16(pos + 10, true), tamano = vista.getUint32(pos + 20, true), largoNombre = vista.getUint16(pos + 28, true);
      const largoExtra = vista.getUint16(pos + 30, true), largoComentario = vista.getUint16(pos + 32, true), local = vista.getUint32(pos + 42, true);
      entradas.set(decodificador.decode(bytes.subarray(pos + 46, pos + 46 + largoNombre)), {metodo, tamano, local});
      pos += 46 + largoNombre + largoExtra + largoComentario;
    }
    const leer = async nombre => {
      const e = entradas.get(nombre); if(!e) throw new Error('El archivo .mxl no trae la partitura.');
      const inicio = e.local + 30 + vista.getUint16(e.local + 26, true) + vista.getUint16(e.local + 28, true);
      const datos = bytes.subarray(inicio, inicio + e.tamano);
      if(e.metodo === 0) return datos;
      if(e.metodo === 8) return descomprimir(datos);
      throw new Error('El archivo .mxl usa una compresion que no se puede leer.');
    };
    let principal = '';
    if(entradas.has('META-INF/container.xml')){
      const contenedor = new DOMParser().parseFromString(decodificador.decode(await leer('META-INF/container.xml')), 'application/xml');
      const raizArchivo = contenedor.getElementsByTagName('rootfile')[0];
      if(raizArchivo) principal = raizArchivo.getAttribute('full-path') || '';
    }
    if(!principal || !entradas.has(principal)) principal = [...entradas.keys()].find(n => /\.(musicxml|xml)$/i.test(n) && !/^META-INF\//i.test(n)) || '';
    if(!principal) throw new Error('El archivo .mxl no trae la partitura.');
    return decodificador.decode(await leer(principal));
  }

  /* ---------- Entrada: cualquier archivo ---------- */
  function decodificar(bytes){
    if(bytes[0] === 0xff && bytes[1] === 0xfe) return new TextDecoder('utf-16le').decode(bytes);
    if(bytes[0] === 0xfe && bytes[1] === 0xff) return new TextDecoder('utf-16be').decode(bytes);
    return new TextDecoder('utf-8').decode(bytes);
  }
  const quitarExtension = nombre => String(nombre || '').replace(/\.[^.]*$/, '');

  async function leerArchivo(archivo){
    const bytes = new Uint8Array(await archivo.arrayBuffer()), nombre = quitarExtension(archivo.name);
    if(bytes[0] === 0x50 && bytes[1] === 0x4b) return cancionDeMusicXml(await extraerMxl(bytes), nombre);   // Nibel: "PK" = archivo zip (.mxl)
    const texto = decodificar(bytes);
    if(texto.trimStart().startsWith('<')) return cancionDeMusicXml(texto, nombre);
    // Nibel: un archivo JS puede traer el proyecto dentro (por ejemplo: const proyecto = {...};), se toma lo que va entre llaves
    const desde = texto.indexOf('{'), hasta = texto.lastIndexOf('}');
    if(desde < 0 || hasta <= desde) throw new Error('No reconoci ese archivo. Usa un proyecto (JSON o JS) o una partitura MusicXML.');
    let datos;
    try{ datos = JSON.parse(texto.slice(desde, hasta + 1)); }
    catch(e){ throw new Error('No pude leer ese archivo. Debe ser el proyecto exportado por la app.'); }
    return cancionDeProyecto(datos, nombre);
  }

  NS.CascadaLectores = {leerArchivo, cancionDeProyecto, cancionDeMusicXml, instrumentoDePrograma};
})(window.NS = window.NS || {});
