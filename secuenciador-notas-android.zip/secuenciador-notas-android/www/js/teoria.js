/* Teoría musical (sin interfaz): escalas, acordes, progresiones y arpegios.
   Todo es OPCIONAL: el Roll solo usa esto para resaltar, ajustar o generar notas; nunca impide poner una nota fuera de la escala.
   Las notas son números MIDI (C4 = 60); las clases de nota (pc) van de 0 (Do) a 11 (Si). */
(function(NS){
  'use strict';
  const LOW = 24, HIGH = 96;                                   // mismo rango que el piano roll del Estudio (C1..C7)
  const SOST = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
  const BEMOL = ['C','D♭','D','E♭','E','F','G♭','G','A♭','A','B♭','B'];
  const SOLFEO = ['Do','Do♯','Re','Re♯','Mi','Fa','Fa♯','Sol','Sol♯','La','La♯','Si'];
  const mod = n => ((n % 12) + 12) % 12;
  const pcName = (pc, bem) => (bem ? BEMOL : SOST)[mod(pc)];
  const pcLabel = pc => {                                       // «C (Do)» · «C♯ / D♭ (Do♯)»
    pc = mod(pc);
    return SOST[pc] === BEMOL[pc] ? SOST[pc] + ' (' + SOLFEO[pc] + ')' : SOST[pc] + ' / ' + BEMOL[pc] + ' (' + SOLFEO[pc] + ')';
  };

  /* ---------- Escalas: intervalos en semitonos desde la tónica ---------- */
  const ESCALAS = [
    {id:'cromatica', g:'Sin escala', n:'Sin escala (todas las notas)', i:[0,1,2,3,4,5,6,7,8,9,10,11]},
    {id:'mayor', g:'Básicas', n:'Mayor (jónica)', i:[0,2,4,5,7,9,11]},
    {id:'menor', g:'Básicas', n:'Menor natural (eólica)', i:[0,2,3,5,7,8,10]},
    {id:'menorArm', g:'Básicas', n:'Menor armónica', i:[0,2,3,5,7,8,11]},
    {id:'menorMel', g:'Básicas', n:'Menor melódica', i:[0,2,3,5,7,9,11]},
    {id:'dorica', g:'Modos', n:'Dórica', i:[0,2,3,5,7,9,10]},
    {id:'frigia', g:'Modos', n:'Frigia', i:[0,1,3,5,7,8,10]},
    {id:'lidia', g:'Modos', n:'Lidia', i:[0,2,4,6,7,9,11]},
    {id:'mixolidia', g:'Modos', n:'Mixolidia', i:[0,2,4,5,7,9,10]},
    {id:'locria', g:'Modos', n:'Locria', i:[0,1,3,5,6,8,10]},
    {id:'pentMayor', g:'Pentatónicas y blues', n:'Pentatónica mayor', i:[0,2,4,7,9]},
    {id:'pentMenor', g:'Pentatónicas y blues', n:'Pentatónica menor', i:[0,3,5,7,10]},
    {id:'blues', g:'Pentatónicas y blues', n:'Blues', i:[0,3,5,6,7,10]},
    {id:'bluesMayor', g:'Pentatónicas y blues', n:'Blues mayor', i:[0,2,3,4,7,9]},
    {id:'egipcia', g:'Del mundo', n:'Egipcia (pentatónica suspendida)', i:[0,2,5,7,10]},
    {id:'arabe', g:'Del mundo', n:'Árabe (doble armónica / Hiyaz)', i:[0,1,4,5,7,8,11]},
    {id:'frigDom', g:'Del mundo', n:'Frigia dominante (flamenca)', i:[0,1,4,5,7,8,10]},
    {id:'hungara', g:'Del mundo', n:'Húngara menor (gitana)', i:[0,2,3,6,7,8,11]},
    {id:'persa', g:'Del mundo', n:'Persa', i:[0,1,4,5,6,8,11]},
    {id:'hirajoshi', g:'Del mundo', n:'Japonesa (Hirajoshi)', i:[0,2,3,7,8]},
    {id:'insen', g:'Del mundo', n:'Japonesa (In Sen)', i:[0,1,5,7,10]},
    {id:'tonos', g:'Simétricas', n:'Tonos enteros', i:[0,2,4,6,8,10]},
    {id:'disminuida', g:'Simétricas', n:'Disminuida (tono–semitono)', i:[0,2,3,5,6,8,9,11]}
  ];
  const escalaDe = id => ESCALAS.find(e => e.id === id) || ESCALAS[0];

  /* ---------- Acordes: intervalos desde la fundamental (14 = novena) ---------- */
  const ACORDES = [
    {id:'maj',   s:'',       n:'Mayor',                    i:[0,4,7]},
    {id:'min',   s:'m',      n:'Menor',                    i:[0,3,7]},
    {id:'dim',   s:'dim',    n:'Disminuido',               i:[0,3,6]},
    {id:'aug',   s:'aug',    n:'Aumentado',                i:[0,4,8]},
    {id:'sus2',  s:'sus2',   n:'Suspendido 2 (sus2)',      i:[0,2,7]},
    {id:'sus4',  s:'sus4',   n:'Suspendido 4 (sus4)',      i:[0,5,7]},
    {id:'5',     s:'5',      n:'Quinta (power chord)',     i:[0,7]},
    {id:'6',     s:'6',      n:'Sexta (6)',                i:[0,4,7,9]},
    {id:'m6',    s:'m6',     n:'Menor con sexta (m6)',     i:[0,3,7,9]},
    {id:'7',     s:'7',      n:'Séptima dominante (7)',    i:[0,4,7,10]},
    {id:'maj7',  s:'maj7',   n:'Séptima mayor (maj7)',     i:[0,4,7,11]},
    {id:'m7',    s:'m7',     n:'Menor séptima (m7)',       i:[0,3,7,10]},
    {id:'m7b5',  s:'m7♭5',   n:'Semidisminuido (m7♭5)',    i:[0,3,6,10]},
    {id:'dim7',  s:'dim7',   n:'Disminuido séptima (dim7)',i:[0,3,6,9]},
    {id:'mMaj7', s:'m(maj7)',n:'Menor con séptima mayor',  i:[0,3,7,11]},
    {id:'7sus4', s:'7sus4',  n:'Séptima suspendida (7sus4)',i:[0,5,7,10]},
    {id:'add9',  s:'add9',   n:'Añadida novena (add9)',    i:[0,4,7,14]},
    {id:'9',     s:'9',      n:'Novena (9)',               i:[0,4,7,10,14]},
    {id:'maj9',  s:'maj9',   n:'Novena mayor (maj9)',      i:[0,4,7,11,14]},
    {id:'m9',    s:'m9',     n:'Menor novena (m9)',        i:[0,3,7,10,14]}
  ];
  const acordeDe = id => ACORDES.find(a => a.id === id) || ACORDES[0];
  const TRIADAS = ['maj','min','dim','aug'], SEPTIMAS = ['maj7','7','m7','m7b5','dim7','mMaj7'];

  // Cómo se pueden escribir los acordes a mano (Am, F#m7, Bb, Cmaj7, Do, Lam, Sol7…)
  const ALIAS = {'':'maj','maj':'maj','M':'maj','m':'min','min':'min','-':'min','mi':'min','dim':'dim','°':'dim','o':'dim','aug':'aug','+':'aug',
    'sus2':'sus2','sus4':'sus4','sus':'sus4','5':'5','6':'6','m6':'m6','7':'7','maj7':'maj7','M7':'maj7','Δ':'maj7','Δ7':'maj7','△':'maj7',
    'm7':'m7','min7':'m7','-7':'m7','m7b5':'m7b5','m7♭5':'m7b5','ø':'m7b5','ø7':'m7b5','dim7':'dim7','°7':'dim7','mmaj7':'mMaj7','m(maj7)':'mMaj7',
    'mM7':'mMaj7','7sus4':'7sus4','add9':'add9','9':'9','maj9':'maj9','M9':'maj9','m9':'m9'};
  const ALIAS_MIN = {};
  Object.keys(ALIAS).forEach(k => { if(!['M','M7','M9','mM7'].includes(k)) ALIAS_MIN[k.toLowerCase()] = ALIAS[k]; });
  const BASE_PC = {c:0, d:2, e:4, f:5, g:7, a:9, b:11};
  const BASE_ES = {do:0, re:2, mi:4, fa:5, sol:7, la:9, si:11};

  // «Am» → {root:9, tipo:'min'}; null si no se entiende
  function parsear(txt){
    txt = String(txt).trim(); if(!txt) return null;
    let base, resto, m = /^(do|re|mi|fa|sol|la|si)([#♯b♭]?)(.*)$/i.exec(txt);
    if(m){ base = BASE_ES[m[1].toLowerCase()]; }
    else{ m = /^([A-Ga-g])([#♯b♭]?)(.*)$/.exec(txt); if(!m) return null; base = BASE_PC[m[1].toLowerCase()]; }
    const acc = m[2] === '#' || m[2] === '♯' ? 1 : (m[2] === 'b' || m[2] === '♭' ? -1 : 0);
    resto = m[3].trim();
    const tipo = ALIAS[resto] || ALIAS_MIN[resto.toLowerCase()];
    return tipo ? {root:mod(base + acc), tipo} : null;
  }
  const simbolo = (root, tipo, bem) => pcName(root, bem) + acordeDe(tipo).s;

  // Notas MIDI de un acorde. inv: 0 fundamental, 1 primera inversión… ; oct: octava de la fundamental (C4 = octava 4)
  function construir(root, tipo, oct, inv){
    const a = acordeDe(tipo), base = 12 * (oct + 1) + mod(root);
    let ps = a.i.map(x => base + x).sort((x, y) => x - y);
    for(let k = 0; k < (inv || 0) && k < ps.length - 1; k++) ps.push(ps.shift() + 12);
    while(Math.max(...ps) > HIGH && Math.min(...ps) - 12 >= LOW) ps = ps.map(p => p - 12);
    while(Math.min(...ps) < LOW && Math.max(...ps) + 12 <= HIGH) ps = ps.map(p => p + 12);
    return ps.sort((x, y) => x - y);
  }

  /* ---------- Estado: tonalidad y escala elegidas (se guarda con el proyecto) ---------- */
  const estado = {root:0, escala:'cromatica', resaltar:true, ajustar:false};
  let mascara = [];
  const recalcular = () => {
    mascara = new Array(12).fill(false);
    escalaDe(estado.escala).i.forEach(i => { mascara[mod(estado.root + i)] = true; });
  };
  recalcular();
  const activa = () => estado.escala !== 'cromatica';
  const enEscala = p => !activa() || mascara[mod(p)];
  const esRaiz = p => activa() && mod(p) === estado.root;
  const ajusta = () => activa() && estado.ajustar;
  const notasEscala = () => escalaDe(estado.escala).i.map(i => mod(estado.root + i));
  const flatKey = () => {                                        // ¿se escribe mejor con bemoles en esta tonalidad?
    const menor = escalaDe(estado.escala).i.includes(3) && !escalaDe(estado.escala).i.includes(4);
    return (menor ? [0,2,3,5,7,10] : [1,3,5,8,10]).includes(estado.root);
  };

  function ponerEscala(root, id){
    estado.root = mod(Number.isFinite(+root) ? +root : 0);
    estado.escala = ESCALAS.some(e => e.id === id) ? id : 'cromatica';
    if(!activa()) estado.ajustar = false;
    recalcular();
  }
  // «E · Mixolidia» (para mostrar la tonalidad elegida)
  const etiqueta = () => pcName(estado.root, flatKey()) + ' · ' + escalaDe(estado.escala).n.replace(/\s*\(.*$/, '');
  const exportar = () => ({root:estado.root, escala:estado.escala, resaltar:!!estado.resaltar, ajustar:!!estado.ajustar});
  function importar(d){
    d = d && typeof d === 'object' ? d : {};
    ponerEscala(d.root, d.escala);
    estado.resaltar = d.resaltar !== false;
    estado.ajustar = activa() && !!d.ajustar;
  }

  // Nota de la escala más cercana a p (en empate, la grave). Sin escala activa devuelve p.
  function cercana(p){
    if(!activa() || mascara[mod(p)]) return p;
    for(let d = 1; d <= 6; d++){
      if(p - d >= LOW && mascara[mod(p - d)]) return p - d;
      if(p + d <= HIGH && mascara[mod(p + d)]) return p + d;
    }
    return p;
  }
  // Siguiente nota de la escala, estrictamente por encima (dir = 1) o por debajo (dir = −1) de p; null si no hay en el rango
  function siguiente(p, dir){
    for(let d = 1; d <= 12; d++){
      const q = p + dir * d;
      if(q < LOW || q > HIGH) return null;
      if(mascara[mod(q)]) return q;
    }
    return null;
  }

  /* ---------- Acordes compatibles con la escala ---------- */
  const ROMANOS = ['I','II','III','IV','V','VI','VII'];
  // grupo: 'triadas' | 'septimas'. Devuelve [{root, tipo, grado, romano}] con los acordes cuyas notas están todas en la escala.
  function compatibles(grupo){
    if(!activa()) return [];
    const esc = escalaDe(estado.escala), tipos = grupo === 'septimas' ? SEPTIMAS : TRIADAS, res = [];
    esc.i.forEach((iv, idx) => {
      const root = mod(estado.root + iv);
      tipos.forEach(t => {
        if(!acordeDe(t).i.every(x => mascara[mod(root + x)])) return;
        let romano = '';
        if(esc.i.length === 7){
          const ter = acordeDe(t).i[1], r = ROMANOS[idx];
          romano = ter === 3 ? r.toLowerCase() : r;
          if(t === 'dim' || t === 'm7b5') romano += '°'; else if(t === 'dim7') romano += '°7'; else if(t === 'aug') romano += '+';
          else if(t === '7') romano += '7'; else if(t === 'maj7') romano += 'Δ'; else if(t === 'm7') romano += '7'; else if(t === 'mMaj7') romano += 'mΔ';
        }
        res.push({root, tipo:t, grado:idx + 1, romano});
      });
    });
    return res;
  }

  /* ---------- Progresiones (grados relativos a la tónica: [semitonos, tipo de acorde]) ---------- */
  const P = (n, g, c) => ({n, g, c});
  const PROGRESIONES = [
    P('I–V–vi–IV (pop)', 'Mayor', [[0,'maj'],[7,'maj'],[9,'min'],[5,'maj']]),
    P('vi–IV–I–V', 'Mayor', [[9,'min'],[5,'maj'],[0,'maj'],[7,'maj']]),
    P('I–vi–IV–V (años 50)', 'Mayor', [[0,'maj'],[9,'min'],[5,'maj'],[7,'maj']]),
    P('I–IV–V–I', 'Mayor', [[0,'maj'],[5,'maj'],[7,'maj'],[0,'maj']]),
    P('I–IV–vi–V', 'Mayor', [[0,'maj'],[5,'maj'],[9,'min'],[7,'maj']]),
    P('ii–V–I (jazz)', 'Mayor', [[2,'m7'],[7,'7'],[0,'maj7']]),
    P('I–vi–ii–V (jazz)', 'Mayor', [[0,'maj7'],[9,'m7'],[2,'m7'],[7,'7']]),
    P('Canon de Pachelbel', 'Mayor', [[0,'maj'],[7,'maj'],[9,'min'],[4,'min'],[5,'maj'],[0,'maj'],[5,'maj'],[7,'maj']]),
    P('Blues de 12 compases', 'Mayor', [[0,'7'],[0,'7'],[0,'7'],[0,'7'],[5,'7'],[5,'7'],[0,'7'],[0,'7'],[7,'7'],[5,'7'],[0,'7'],[7,'7']]),
    P('i–VI–III–VII (Am–F–C–G)', 'Menor', [[0,'min'],[8,'maj'],[3,'maj'],[10,'maj']]),
    P('i–iv–v–i', 'Menor', [[0,'min'],[5,'min'],[7,'min'],[0,'min']]),
    P('i–iv–VII–III', 'Menor', [[0,'min'],[5,'min'],[10,'maj'],[3,'maj']]),
    P('i–VII–VI–VII', 'Menor', [[0,'min'],[10,'maj'],[8,'maj'],[10,'maj']]),
    P('i–VII–VI–V (andaluza)', 'Menor', [[0,'min'],[10,'maj'],[8,'maj'],[7,'maj']]),
    P('ii°–V7–i', 'Menor', [[2,'m7b5'],[7,'7'],[0,'min']]),
    P('I–♭VII–IV–I', 'Mixolidio', [[0,'maj'],[10,'maj'],[5,'maj'],[0,'maj']]),
    P('I–♭VII–♭VI–♭VII', 'Mixolidio', [[0,'maj'],[10,'maj'],[8,'maj'],[10,'maj']]),
    P('i–IV–i–IV', 'Dórica', [[0,'min'],[5,'maj'],[0,'min'],[5,'maj']]),
    P('i–♭II–i–♭II', 'Frigia / flamenca', [[0,'min'],[1,'maj'],[0,'min'],[1,'maj']]),
    P('I–♭II–I–♭II', 'Frigia / flamenca', [[0,'maj'],[1,'maj'],[0,'maj'],[1,'maj']]),
    P('I–II–I–II', 'Lidia', [[0,'maj'],[2,'maj'],[0,'maj'],[2,'maj']])
  ];
  // Texto «Am F C G» de una progresión en la tonalidad elegida
  function textoProgresion(p, root, bem){
    return p.c.map(([sem, tipo]) => simbolo(root + sem, tipo, bem)).join(' ');
  }
  // «Am - F, C  G» → [{root, tipo}…] o {error:'texto no entendido'}
  function parsearProgresion(txt){
    const partes = String(txt).split(/[\s,;|–—-]+(?!\d)/).map(s => s.trim()).filter(Boolean), res = [];
    for(const t of partes){ const c = parsear(t); if(!c) return {error:t}; res.push(c); }
    return {acordes:res};
  }

  /* ---------- Arpegiador ---------- */
  const PATRONES = [['sube','Subiendo ↑'],['baja','Bajando ↓'],['subebaja','Subiendo y bajando ↑↓'],['bajasube','Bajando y subiendo ↓↑'],['alberti','Alberti (grave–agudo–medio–agudo)'],['azar','Aleatorio']];
  // Agrupa notas {p,s,d}: las que empiezan a la vez forman un acorde. Si ninguna coincide, todas se tratan como un solo grupo.
  function agrupar(notas){
    const m = new Map();
    notas.forEach(n => { if(!m.has(n.s)) m.set(n.s, []); m.get(n.s).push(n); });
    let grupos = [...m.values()].map(g => ({ini:g[0].s, fin:Math.max(...g.map(n => n.s + n.d)), ps:[...new Set(g.map(n => n.p))].sort((a, b) => a - b), ids:g.map(n => n.id)}));
    if(grupos.every(g => g.ps.length < 2) && notas.length > 1){
      grupos = [{ini:Math.min(...notas.map(n => n.s)), fin:Math.max(...notas.map(n => n.s + n.d)), ps:[...new Set(notas.map(n => n.p))].sort((a, b) => a - b), ids:notas.map(n => n.id)}];
    }
    return grupos.filter(g => g.ps.length > 1).sort((a, b) => a.ini - b.ini);
  }
  // o: {patron, paso (unidades de 1/32), octavas (1–3), largo (0.25–1)} → [{p, s, d}]
  function arpegiar(grupo, o){
    let pool = [];
    for(let k = 0; k < o.octavas; k++) grupo.ps.forEach(p => { if(p + 12 * k <= HIGH) pool.push(p + 12 * k); });
    pool = [...new Set(pool)].sort((a, b) => a - b);
    const n = pool.length; if(n < 2) return [];
    let seq;
    switch(o.patron){
      case 'baja': seq = pool.slice().reverse(); break;
      case 'subebaja': seq = pool.concat(pool.slice(1, -1).reverse()); break;
      case 'bajasube': seq = pool.slice().reverse().concat(pool.slice(1, -1)); break;
      case 'alberti': seq = [pool[0], pool[n - 1], pool[1], pool[n - 1]]; break;
      default: seq = pool;
    }
    const total = grupo.fin - grupo.ini, cuenta = Math.max(1, Math.ceil(total / o.paso)), res = [];
    let ant = -1;
    for(let i = 0; i < cuenta; i++){
      const s = grupo.ini + i * o.paso; if(s >= grupo.fin) break;
      let p;
      if(o.patron === 'azar'){ do{ p = pool[Math.floor(Math.random() * n)]; }while(p === ant && n > 1); ant = p; }
      else p = seq[i % seq.length];
      res.push({p, s, d:Math.max(1, Math.round(Math.min(o.paso, grupo.fin - s) * o.largo))});
    }
    return res;
  }

  NS.Teoria = {LOW, HIGH, estado, ESCALAS, ACORDES, PROGRESIONES, PATRONES, TRIADAS, SEPTIMAS,
    escalaDe, acordeDe, pcName, pcLabel, parsear, simbolo, construir, activa, enEscala, esRaiz, ajusta, notasEscala, flatKey,
    ponerEscala, etiqueta, exportar, importar, cercana, siguiente, compatibles, textoProgresion, parsearProgresion, agrupar, arpegiar};
})(window.NS = window.NS || {});
