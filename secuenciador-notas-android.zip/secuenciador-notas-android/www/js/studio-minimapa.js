/* Nibel: Panel de navegacion del Roll. Tiene un boton para ir al comienzo, un minimapa de toda la pista
   (se toca o se arrastra el dedo para ir a esa parte) y un boton para ir al final (ultima nota). */
(function(NS){
  'use strict';
  const ST = NS.Studio, $ = id => document.getElementById(id);
  const lienzo = $('stMinimapa'), botonInicio = $('stIrInicio'), botonFinal = $('stIrFinal');
  let ctx = null, ancho = 0, alto = 0, arrastre = null;

  const nav = () => ST.roll.navegacion;
  // Nibel: cuanto mide toda la pista en el minimapa (hasta la ultima nota, o lo que se ve si es mas)
  const calcularRango = v => Math.max(1, v.fin + v.margen / v.u, (v.x + v.ancho) / v.u, v.ancho / v.u);

  function ajustar(){
    const r = lienzo.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    ancho = r.width; alto = r.height;
    lienzo.width = Math.round(ancho * d); lienzo.height = Math.round(alto * d);
    ctx = lienzo.getContext('2d'); ctx.setTransform(d, 0, 0, d, 0, 0);
    dibujar();
  }

  function dibujar(){
    if(!ctx || !ancho || !alto || !ST.roll) return;
    const v = nav().leer(), rango = calcularRango(v), px = u => u / rango * ancho, C = NS.Theme.palette();
    ctx.clearRect(0, 0, ancho, alto);
    ctx.fillStyle = C.minimapaFondo; ctx.fillRect(0, 0, ancho, alto);

    // Nibel: rayitas de los compases (se separan mas cuando la pista es larga)
    const pxCompas = px(32); let salto = 1;
    while(pxCompas > 0 && pxCompas * salto < 28) salto *= 2;
    ctx.fillStyle = C.minimapaRayas;
    for(let c = 0; c * 32 <= rango; c += salto) ctx.fillRect(Math.round(px(c * 32)), 0, 1, alto);

    // Nibel: las notas de todas las pistas, cada una con el color de su pista
    const colores = new Map(ST.tracks.map(t => [t.id, t.color]));
    let bajo = 127, agudo = 0;
    for(const n of v.notas){ if(n.p < bajo) bajo = n.p; if(n.p > agudo) agudo = n.p; }
    const filas = Math.max(8, agudo - bajo + 1), margenV = 4, area = alto - margenV * 2;
    const altoNota = Math.max(2, Math.min(4, area / filas));
    for(const n of v.notas){
      const color = colores.get(n.t); if(!color) continue;
      const y = margenV + (agudo - n.p) * (area - altoNota) / Math.max(1, filas - 1);
      ctx.globalAlpha = n.t === ST.curId ? 1 : 0.45;
      ctx.fillStyle = color; ctx.fillRect(px(n.s), y, Math.max(1.5, px(n.d)), altoNota);
    }
    ctx.globalAlpha = 1;

    // Nibel: el cuadro marca la parte que estas viendo en el Roll
    const w = Math.max(10, px(v.ancho / v.u)), x0 = Math.max(0, Math.min(px(v.x / v.u), ancho - w));
    ctx.fillStyle = C.vistaRelleno; ctx.fillRect(x0, 0, w, alto);
    ctx.strokeStyle = C.vistaBorde; ctx.lineWidth = 1.5; ctx.strokeRect(x0 + 0.75, 0.75, w - 1.5, alto - 1.5);

    // Nibel: la linea roja marca por donde va la reproduccion
    if(v.unidadActual >= 0){ ctx.fillStyle = C.cursor; ctx.fillRect(Math.min(px(v.unidadActual), ancho - 2), 0, 2, alto); }
  }

  /* ---------- Tocar y arrastrar ---------- */
  function mover(e){
    const v = nav().leer(), r = lienzo.getBoundingClientRect();
    const unidad = (e.clientX - r.left) / r.width * calcularRango(v) - arrastre.desfase;
    nav().ir(unidad * v.u - v.ancho / 2); // Nibel: el centro de la vista va hacia donde tocas
  }
  lienzo.addEventListener('pointerdown', e => {
    if(arrastre) return;
    e.preventDefault(); try{ lienzo.setPointerCapture(e.pointerId); }catch(_){}
    const v = nav().leer(), r = lienzo.getBoundingClientRect();
    const unidad = (e.clientX - r.left) / r.width * calcularRango(v);
    const inicio = v.x / v.u, fin = inicio + v.ancho / v.u;
    // Nibel: si tocas dentro del cuadro lo agarras donde estaba; si tocas fuera, el cuadro salta hasta ahi
    arrastre = {id:e.pointerId, desfase:(unidad >= inicio && unidad <= fin) ? unidad - (inicio + fin) / 2 : 0};
    nav().empezar(); mover(e);
  });
  lienzo.addEventListener('pointermove', e => { if(arrastre && e.pointerId === arrastre.id) mover(e); });
  function soltar(e){
    if(!arrastre || e.pointerId !== arrastre.id) return;
    arrastre = null; nav().terminar(); ST.changed();
  }
  ['pointerup', 'pointercancel'].forEach(ev => lienzo.addEventListener(ev, soltar));
  lienzo.addEventListener('contextmenu', e => e.preventDefault());

  /* ---------- Botones de inicio y final ---------- */
  botonInicio.addEventListener('click', () => { nav().ir(0); nav().saltarSiSuena(); ST.changed(); });
  botonFinal.addEventListener('click', () => { nav().ir(Infinity); nav().saltarSiSuena(); ST.changed(); });

  ST.minimapa = {dibujar};
  new ResizeObserver(ajustar).observe(lienzo);
})(window.NS = window.NS || {});
