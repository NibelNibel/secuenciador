/* Arranque: pestañas, instrumento, octavas, teclado, registro de notas. */
(function(NS){
  const S = NS.State, $ = id => document.getElementById(id);
  const tabs = [...document.querySelectorAll('.tab')];

  NS.Audio.init(t => $('status').textContent = t);
  NS.Audio.setInstrument(S.data.inst);

  // Instrumento
  const inst = $('inst');
  NS.Audio.list().forEach(i => inst.add(new Option(i.name, i.id)));
  inst.value = S.data.inst;
  inst.addEventListener('change', () => { NS.Piano.releaseAll(); NS.Audio.setInstrument(inst.value); S.set({inst:inst.value}); });

  // Teclado + octavas
  NS.Piano.init($('piano'), midi => {
    if(S.data.recording) S.set({notes:S.data.notes.concat(midi)}, 'record');
  });
  const car = NS.Piano.mountCarousel($('carousel'), o => { if(o !== S.data.lowOct) S.set({lowOct:o}); });

  function drawPiano(){
    const {lowOct, acc} = S.data;
    NS.Piano.render(lowOct, acc); car.mark(lowOct);
    $('info').innerHTML = 'Abajo: <b>C' + lowOct + '</b> · Arriba: <b>C' + (lowOct + 1) + '</b>';
  }
  const recenter = () => setTimeout(() => car.center(S.data.lowOct, false), 30);

  // Pestañas y panel del teclado
  function drawLayout(){
    const {tab, kbHidden} = S.data;
    tabs.forEach(b => b.classList.toggle('sel', b.dataset.tab === tab));
    $('view-piano').hidden = tab !== 'piano'; $('view-melodies').hidden = tab !== 'melodies';
    $('kbPanel').hidden = kbHidden; $('seqPanel').classList.toggle('full', kbHidden);
    $('kbToggle').textContent = kbHidden ? '▴ Mostrar teclado' : '▾ Ocultar teclado';
    if(tab === 'piano' && !kbHidden) recenter(); else NS.Piano.releaseAll();
  }
  tabs.forEach(b => b.addEventListener('click', () => { NS.Player.stop(); S.set({tab:b.dataset.tab}); }));
  $('kbToggle').addEventListener('click', () => S.set({kbHidden:!S.data.kbHidden}));

  S.on(keys => {
    if(keys.includes('lowOct') || keys.includes('acc')) drawPiano();
    if(keys.includes('tab') || keys.includes('kbHidden')) drawLayout();
  });
  window.addEventListener('resize', recenter);

  drawPiano(); drawLayout();
})(window.NS = window.NS || {});
