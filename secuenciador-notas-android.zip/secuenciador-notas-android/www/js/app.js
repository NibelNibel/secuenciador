/* Arranque: pantallas (menú principal y modos), instrumento, octavas, teclado, registro de notas. */
(function(NS){
  const S = NS.State, $ = id => document.getElementById(id);

  /* Altura fija: el teclado del móvil no debe encoger ni deformar la interfaz.
     (Principal: AndroidManifest con adjustNothing, ver build-android.sh. Esto es el respaldo si la WebView se redimensiona.) */
  let stableH = 0, lastW = 0;
  function lockHeight(){
    const a = document.activeElement;
    const typing = !!a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && !['checkbox', 'button'].includes(a.type)));
    if(!typing || !stableH || window.innerWidth !== lastW){ stableH = window.innerHeight; lastW = window.innerWidth; }
    document.documentElement.style.setProperty('--h', stableH + 'px');
  }
  window.addEventListener('resize', lockHeight);
  document.addEventListener('focusout', () => setTimeout(lockHeight, 250));
  lockHeight();

  NS.Audio.init(t => $('status').textContent = t);
  NS.Audio.setInstrument(S.data.inst);

  // Instrumento
  const inst = $('inst');
  NS.Audio.groups().forEach(g => {   // instrumentos agrupados por familia
    const og = document.createElement('optgroup'); og.label = g.name;
    g.items.forEach(i => og.appendChild(new Option(i.name, i.id)));
    inst.appendChild(og);
  });
  inst.value = S.data.inst;
  inst.addEventListener('change', () => { NS.Piano.releaseAll(); NS.Audio.setInstrument(inst.value); S.set({inst:inst.value}); });

  // Teclado + octavas
  NS.Piano.init($('piano'), midi => {
    if(NS.Seq.tryReplace(midi)) return; // con «Reemplazar» activo, la tecla sustituye la nota elegida
    if(S.data.recording) S.setPhraseNotes(S.phraseNotes().concat(midi), 'record');
  });
  const car = NS.Piano.mountCarousel($('carousel'), o => { if(o !== S.data.lowOct) S.set({lowOct:o}); });

  function drawPiano(){
    const {lowOct, acc} = S.data;
    NS.Piano.render(lowOct, acc); car.mark(lowOct);
    drawInfo();
  }
  function drawInfo(){
    const {lowOct, recording} = S.data;
    $('info').innerHTML = 'Abajo: <b>C' + lowOct + '</b> · Arriba: <b>C' + (lowOct + 1) + '</b>' +
      (recording ? ' · <b>● Registrando</b> (' + S.allNotes().length + ' notas)' : '');
  }
  const recenter = () => setTimeout(() => car.center(S.data.lowOct, false), 30);

  // 🔇 Silenciar todo: el botón está en la barra del Modo Escritor (js/menu.js). Aquí, silencio al salir de la app
  document.addEventListener('visibilitychange', () => { if(document.hidden) NS.Player.stop(); });

  // Pantallas y panel del teclado
  function drawLayout(){
    const {tab, view} = S.data, showKb = view !== 'edit', showSeq = view !== 'keys';
    [...document.querySelectorAll('#viewSwitch button')].forEach(b => b.classList.toggle('sel', b.dataset.view === view));
    $('view-home').hidden = tab !== 'home'; $('view-piano').hidden = tab !== 'piano'; $('view-melodies').hidden = tab !== 'melodies'; $('view-rhythm').hidden = tab !== 'rhythm'; $('view-studio').hidden = tab !== 'studio'; $('view-cascada').hidden = tab !== 'cascada';
    NS.Nav.render();                              // barra fina del modo (← y secciones); oculta en el menú principal
    if(tab !== 'cascada') NS.Cascada.alSalir(); else NS.Cascada.alEntrar();   // Nibel: la cascada se detiene al salir y se actualiza al entrar
    if(tab !== 'studio') NS.Studio.stop();       // al salir del Estudio se detiene su reproducción y se sueltan sus notas
    $('kbPanel').hidden = !showKb; $('seqPanel').hidden = !showSeq; $('seqPanel').classList.toggle('full', !showKb);
    if(tab === 'piano' && showKb) recenter(); else NS.Piano.releaseAll();
  }
  $('viewSwitch').addEventListener('click', e => {
    const b = e.target.closest('button'); if(b && b.dataset.view !== S.data.view) S.set({view:b.dataset.view});
  });

  S.on(keys => {
    if(keys.includes('lowOct') || keys.includes('acc')) drawPiano();
    if(keys.includes('tab') || keys.includes('view')) drawLayout();
    if(keys.includes('recording') || keys.includes('sections')) drawInfo();
  });
  window.addEventListener('resize', recenter);

  drawPiano(); drawLayout();
})(window.NS = window.NS || {});
