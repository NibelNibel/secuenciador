/* Estudio — exportar (WAV y MIDI) e importar una melodía guardada a la pista actual.
   Los archivos se entregan con NS.RhythmCore.deliver: en el APK abre el menú «Compartir» de Android;
   en el navegador se descarga directamente. */
(function(NS){
  'use strict';
  const ST = NS.Studio, RC = NS.RhythmCore, $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const baseName = () => String(ST.name || 'Estudio').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w\- .]+/g, '_').trim().slice(0, 40) || 'Estudio';
  const allNotes = () => ST.roll.exportState().notes.filter(n => ST.trackById(n.t));
  const msg = t => { $('stExportMsg').textContent = t || ''; };
  const busy = on => { $('stWav').disabled = on; $('stMidi').disabled = on; };

  async function send(file){
    const r = await RC.deliver(file);
    if(!r.ok) msg(r.msg || 'No se pudo entregar el archivo');
    else if(!r.canceled) msg('Listo: ' + file.name);
    return r;
  }

  /* ---------- WAV (estéreo, 16 bits): se renderiza sin conexión con el mismo sonido de la app ---------- */
  function wavBytes(ab){
    const ch = ab.numberOfChannels, len = ab.length, out = new Uint8Array(44 + len * ch * 2), dv = new DataView(out.buffer);
    const str = (o, t) => { for(let i = 0; i < t.length; i++) dv.setUint8(o + i, t.charCodeAt(i)); };
    str(0, 'RIFF'); dv.setUint32(4, 36 + len * ch * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
    dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, ch, true);
    dv.setUint32(24, ab.sampleRate, true); dv.setUint32(28, ab.sampleRate * ch * 2, true);
    dv.setUint16(32, ch * 2, true); dv.setUint16(34, 16, true); str(36, 'data'); dv.setUint32(40, len * ch * 2, true);
    const chans = []; for(let c = 0; c < ch; c++) chans.push(ab.getChannelData(c));
    let o = 44;
    for(let i = 0; i < len; i++) for(let c = 0; c < ch; c++){
      const v = Math.max(-1, Math.min(1, chans[c][i])); dv.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2;
    }
    return out;
  }
  async function exportWav(){
    const notes = allNotes().filter(n => ST.audible(ST.trackById(n.t)));
    if(!notes.length){ msg('No hay notas sonando que exportar.'); return; }
    ST.stop(); busy(true); msg('Preparando el audio…');
    try{
      const u = 60 / ST.bpm / 8, end = Math.max(...notes.map(n => n.s + n.d)) * u;
      const A = NS.Auto, specs = ST.tracks.map(t => ({id:t.id, inst:t.inst, vol:t.vol, pan:t.pan, gan:t.gan, fx:t.fx,
        autoVol:A.muestras(t.auto && t.auto.vol, u), autoPan:A.muestras(t.auto && t.auto.pan, u)}));   // curvas de automatización (si las hay)
      const buf = await NS.Audio.render(specs, notes.map(n => ({t:n.t, p:n.p, s:n.s * u, d:n.d * u})), end + 2.5, ST.master(), undefined, ST.general());
      await send({name:baseName() + '.wav', mime:'audio/wav', bytes:wavBytes(buf.get())});
    }catch(e){ msg('No se pudo crear el audio.'); console.error(e); }
    busy(false);
  }

  /* ---------- MIDI (formato 1, 480 pulsos por negra, una pista MIDI por pista del Estudio) ---------- */
  const CHAN = [0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15]; // el canal 10 (índice 9) es batería
  const vlq = v => { const b = [v & 0x7f]; while((v >>= 7)) b.unshift((v & 0x7f) | 0x80); return b; };
  const txt = (type, s) => { const e = new TextEncoder().encode(s); return [0xff, type, ...vlq(e.length), ...e]; };
  const u32 = v => [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255];
  const chunk = (id, bytes) => [...[...id].map(c => c.charCodeAt(0)), ...u32(bytes.length), ...bytes];
  const TPU = 60; // 480 pulsos por negra / 8 unidades por negra

  async function exportMidi(){
    const notes = allNotes();
    if(!notes.length){ msg('No hay notas que exportar.'); return; }
    const mpq = Math.round(60e6 / ST.bpm);
    const trks = [chunk('MTrk', [0, ...txt(0x03, baseName()), 0, 0xff, 0x51, 3, (mpq >> 16) & 255, (mpq >> 8) & 255, mpq & 255,
      0, 0xff, 0x58, 4, 4, 2, 24, 8, 0, 0xff, 0x2f, 0])];
    ST.tracks.forEach((t, i) => {
      const mine = notes.filter(n => n.t === t.id); if(!mine.length) return;
      const ch = CHAN[i % CHAN.length], ev = [];
      for(const n of mine){ ev.push({tk:n.s * TPU, o:1, b:[0x90 | ch, n.p, 100]}); ev.push({tk:(n.s + n.d) * TPU, o:0, b:[0x80 | ch, n.p, 0]}); }
      ev.sort((a, b) => a.tk - b.tk || a.o - b.o); // al empatar, primero se apaga y luego se enciende
      let last = 0; const bytes = [0, ...txt(0x03, t.name), 0, 0xc0 | ch, NS.Audio.program(t.inst)];
      for(const e of ev){ bytes.push(...vlq(e.tk - last), ...e.b); last = e.tk; }
      bytes.push(0, 0xff, 0x2f, 0); trks.push(chunk('MTrk', bytes));
    });
    const head = chunk('MThd', [0, 1, 0, trks.length, 0x01, 0xe0]);
    await send({name:baseName() + '.mid', mime:'audio/midi', bytes:new Uint8Array([...head, ...trks.flat()])});
  }

  /* ---------- Traer una melodía guardada a la pista actual ---------- */
  // Convierte la melodía a notas del Roll. Con ritmo: respeta cuándo empieza y cuánto dura cada nota (ajustado a 1/32 al tempo actual).
  // Sin ritmo («pulso fijo»): una negra por nota.
  function convert(m, rid){
    const u = 60 / ST.bpm / 8, list = [], R = ST.roll; let moved = 0;
    const fit = p => { let q = p; while(q < R.LOW) q += 12; while(q > R.HIGH) q -= 12; if(q !== p) moved++; return q; };
    const r = rid === 'none' ? null : m.rhythms.find(x => x.id === rid);
    if(r) r.events.forEach((e, i) => list.push({p:fit(m.notes[i]), s:Math.round(e.t / 1000 / u), d:Math.max(1, Math.round(e.d / 1000 / u))}));
    else m.notes.forEach((p, i) => list.push({p:fit(p), s:i * 8, d:7}));
    return {list, moved};
  }
  function openImport(){
    const mels = NS.State.melodies.filter(m => m.notes.length);
    let selM, selR, info;
    const fill = () => {
      const m = mels.find(x => x.id === selM.value); if(!m) return;
      const fav = RC.favorite(m);
      selR.innerHTML = '<option value="none">♩ Pulso fijo (una negra por nota)</option>' + m.rhythms.map(r =>
        '<option value="' + esc(r.id) + '"' + (RC.fits(m, r) ? '' : ' disabled') + '>🥁 ' + (RC.fits(m, r) ? '' : '⚠ ') + esc(r.name) + '</option>').join('');
      selR.value = fav ? fav.id : 'none';
      info.textContent = m.notes.length + ' notas · se añadirán a «' + ST.cur().name + '» desde el compás visible, a ' + ST.bpm + ' BPM.';
    };
    NS.Sheet.open('Traer melodía a la pista', mels.length ? 'Traer' : null, box => {
      if(!mels.length){ box.innerHTML = '<p class="small">Aún no tienes melodías guardadas. Regístralas en el Modo Escritor y pulsa «Guardar».</p>'; return; }
      box.innerHTML = '<label class="stLbl">Melodía</label><select id="stImpMel"></select><label class="stLbl">Ritmo</label><select id="stImpRh"></select><p id="stImpInfo" class="small"></p>';
      selM = box.querySelector('#stImpMel'); selR = box.querySelector('#stImpRh'); info = box.querySelector('#stImpInfo');
      selM.innerHTML = mels.map(m => '<option value="' + esc(m.id) + '">' + esc(m.name) + ' (' + m.notes.length + ')</option>').join('');
      selM.addEventListener('change', fill); fill();
    }, () => {
      const m = mels.find(x => x.id === selM.value); if(!m) return false;
      const c = convert(m, selR.value), r = ST.roll.addNotes(c.list);
      ST.showSub('roll');
      ST.toast(r.added + ' notas añadidas a «' + ST.cur().name + '»' + (c.moved ? ' · ' + c.moved + ' movidas de octava para caber' : '') + (r.cut ? ' · ' + r.cut + ' no cupieron' : ''));
    });
  }

  ST.openImport = openImport;
  ST.exportWav = exportWav; ST.exportMidi = exportMidi;
  $('stWav').addEventListener('click', exportWav);
  $('stMidi').addEventListener('click', exportMidi);
  $('stImport').addEventListener('click', openImport);
})(window.NS = window.NS || {});
