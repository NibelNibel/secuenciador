/* Estudio — sección «Pistas»: tarjetas desplegables (nombre, instrumento, volumen, pan, silencio / solo)
   y volumen general. Solo se despliega una pista a la vez para no saturar la pantalla. */
(function(NS){
  'use strict';
  const ST = NS.Studio, $ = id => document.getElementById(id);
  const list = $('stTrackList');
  let openId = null; // pista desplegada
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const fmtVol = v => (v <= ST.MINDB ? '−∞' : v + ' dB');
  const fmtPan = v => (Math.abs(v) < 0.025 ? 'Centro' : Math.round(Math.abs(v) * 100) + (v < 0 ? ' I' : ' D'));
  const nNotes = n => n + (n === 1 ? ' nota' : ' notas');

  function slider(label, min, max, stp, val, k, fmt){
    return '<div class="stRow"><span>' + label + '</span><input type="range" min="' + min + '" max="' + max + '" step="' + stp +
      '" value="' + val + '" data-k="' + k + '" aria-label="' + label + '"><span class="val">' + fmt(val) + '</span></div>';
  }

  // Aviso cuando la pista tiene curvas: mientras suena manda la curva; el deslizador vale con la reproducción detenida
  function autoNota(t){
    const A = NS.Auto, ks = Object.keys(A.PARAMS).filter(k => A.hay(t.auto, k));
    return ks.length ? '<p class="small">📈 Automatizado: ' + ks.map(k => A.PARAMS[k].nombre.toLowerCase()).join(' y ') + '. Al sonar manda la curva; el deslizador vale con la reproducción detenida.</p>' : '';
  }

  function render(){
    if(!openId || !ST.trackById(openId)) openId = ST.curId;
    list.innerHTML = ST.tracks.map(t => {
      const open = t.id === openId;
      return '<div class="stTrk' + (open ? ' open' : '') + (t.id === ST.curId ? ' cur' : '') + '" data-id="' + t.id + '" style="--c:' + t.color + '">' +
        '<div class="stTrkHead" data-act="toggle"><span class="dot"></span>' +
          '<div class="ttl"><b>' + esc(t.name) + '</b><small>' + esc(ST.instName(t.inst)) + ' · ' + nNotes(ST.roll.countNotes(t.id)) + '</small></div>' +
          '<button class="btn sm' + (t.mute ? ' on' : '') + '" data-act="mute" title="Silenciar esta pista" aria-label="Silenciar">M</button>' +
          '<button class="btn sm' + (t.solo ? ' on' : '') + '" data-act="solo" title="Escuchar solo esta pista" aria-label="Solo">S</button>' +
          '<span class="chev">' + (open ? '▴' : '▾') + '</span></div>' +
        (open ? '<div class="stTrkBody">' +
          '<div class="stRow"><span>Nombre</span><input type="text" class="stName" data-act="name" maxlength="20" value="' + esc(t.name) + '" aria-label="Nombre de la pista"><span></span></div>' +
          '<div class="stRow"><span>Sonido</span><select data-act="inst" aria-label="Instrumento">' +
            NS.Audio.groups().map(g => '<optgroup label="' + esc(g.name) + '">' + g.items.map(i => '<option value="' + i.id + '"' + (i.id === t.inst ? ' selected' : '') + '>' + esc(i.name) + '</option>').join('') + '</optgroup>').join('') + '</select><span></span></div>' +
          slider('Vol', ST.MINDB, ST.MAXDB, 1, t.vol, 'vol', fmtVol) + slider('Pan', -1, 1, 0.05, t.pan, 'pan', fmtPan) +
          autoNota(t) +
          '<div class="tools"><button class="btn sm" data-act="use">🎹 Editar en el Roll</button>' +
          '<button class="btn sm" data-act="auto" title="Volumen y balance que cambian durante la canción">📈 Automatización</button>' +
          '<button class="btn sm" data-act="clear">🧹 Limpiar</button>' +
          '<button class="btn sm danger" data-act="del"' + (ST.tracks.length < 2 ? ' disabled' : '') + '>🗑 Eliminar</button></div>' +
        '</div>' : '') + '</div>';
    }).join('');
    $('stAddTrack').disabled = ST.tracks.length >= ST.MAX;
  }

  // Los cambios pequeños (nombre, deslizadores) no redibujan: así no se pierde el foco ni se corta el arrastre.
  const trackOf = el => ST.trackById(+el.closest('.stTrk').dataset.id);
  list.addEventListener('click', e => {
    if(e.target.closest('input,select,textarea')) return;   // tocar un campo o la lista de instrumentos no debe quitarle el foco
    const card = e.target.closest('.stTrk'); if(!card) return;
    const t = ST.trackById(+card.dataset.id), b = e.target.closest('button'), head = e.target.closest('.stTrkHead');
    if(!t) return;
    const ae = document.activeElement; if(ae && ae !== document.body && list.contains(ae) && ae !== b) ae.blur();
    const act = b ? b.dataset.act : (head ? 'toggle' : null);
    if(act === 'mute'){ t.mute = !t.mute; if(t.mute) t.audio.silence(); ST.emit(); }
    else if(act === 'solo'){ t.solo = !t.solo; ST.stopSound(); ST.emit(); }
    else if(act === 'toggle'){ openId = openId === t.id ? null : t.id; ST.selectTrack(t.id); ST.emit(); }
    else if(act === 'use'){ ST.selectTrack(t.id); ST.showSub('roll'); }
    else if(act === 'auto') ST.auto.abrirPara(t.id, NS.Auto.hay(t.auto, 'pan') && !NS.Auto.hay(t.auto, 'vol') ? 'pan' : 'vol');
    else if(act === 'clear') ST.roll.clearTrack(t.id);
    else if(act === 'del'){
      ST.ask({title:'Eliminar pista', msg:'Se eliminará «' + t.name + '» con sus ' + nNotes(ST.roll.countNotes(t.id)) + '.', ok:'Eliminar'})
        .then(ok => { if(ok) ST.removeTrack(t.id); });
    }
  });
  list.addEventListener('input', e => {
    const t = trackOf(e.target); if(!t) return;
    if(e.target.dataset.act === 'name'){
      t.name = e.target.value;
      const b = e.target.closest('.stTrk').querySelector('.ttl b'); if(b) b.textContent = t.name || ' ';
      ST.listeners.forEach(f => f()); ST.changed(); return;
    }
    const k = e.target.dataset.k; if(!k) return;
    const v = +e.target.value;
    if(k === 'vol'){ t.vol = v; t.audio.setVol(v); } else { t.pan = v; t.audio.setPan(v); }
    e.target.nextElementSibling.textContent = k === 'vol' ? fmtVol(v) : fmtPan(v);
    ST.changed();
  });
  list.addEventListener('change', e => {
    const t = trackOf(e.target); if(!t) return;
    if(e.target.dataset.act === 'name'){ t.name = ST.cleanName(e.target.value, t); e.target.value = t.name; ST.emit(); }
    else if(e.target.dataset.act === 'inst') ST.setInst(t.id, e.target.value);
  });

  $('stAddTrack').addEventListener('click', () => { if(ST.addTrack()) openId = ST.curId; render(); });
  $('stMaster').addEventListener('input', e => {
    const v = +e.target.value; $('stMasterLbl').textContent = fmtVol(v); ST.setMaster(v);
  });

  (ST.subHooks = ST.subHooks || []).push(name => {
    if(name !== 'tracks') return;
    const m = ST.master(); $('stMaster').value = m; $('stMasterLbl').textContent = fmtVol(m);   // Nibel: el total pudo moverse desde la Mezcla
    render();
  });   // al abrir «Pistas»: notas y automatización al día
  ST.listeners.push(() => {
    const m = ST.master(); $('stMaster').value = m; $('stMasterLbl').textContent = fmtVol(m);
    // no redibujar mientras se escribe el nombre o se arrastra un deslizador
    const a = document.activeElement;
    if(a && list.contains(a) && (a.classList.contains('stName') || a.type === 'range')) return;
    render();
  });
})(window.NS = window.NS || {});
