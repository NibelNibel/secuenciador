/* Teclado de dos pisos (multitáctil con glissando) y carrusel de octavas. */
(function(NS){
  const N = NS.Notes;
  const WHITES = [0,2,4,5,7,9,11];
  const BLACKS = [[1,1],[3,2],[6,4],[8,5],[10,6]]; // [semitono, posición entre blancas]
  let el = null, onPress = null;
  const active = {}; // pointerId -> {h, el}

  const div = cls => { const d = document.createElement('div'); d.className = cls; return d; };

  function octave(o, acc){
    const row = div('octave'), base = (o + 1) * 12, w = 100 / 7;
    WHITES.forEach(pc => { const k = div('white'); k.dataset.midi = base + pc; k.textContent = N.name(base + pc, acc); row.appendChild(k); });
    BLACKS.forEach(([pc, pos]) => {
      const k = div('black'); k.dataset.midi = base + pc; k.style.left = (pos * w - 4.3) + '%';
      k.textContent = N.name(base + pc, acc); row.appendChild(k);
    });
    return row;
  }
  function keyAt(x, y){
    let t = document.elementFromPoint(x, y);
    while(t && t !== el){ if(t.dataset && t.dataset.midi) return t; t = t.parentElement; }
    return null;
  }
  function down(pid, k){ active[pid] = {h:NS.Audio.on(+k.dataset.midi), el:k}; k.classList.add('down'); }
  function up(pid){ const a = active[pid]; if(!a) return; NS.Audio.off(a.h); a.el.classList.remove('down'); delete active[pid]; }
  function releaseAll(){ Object.keys(active).forEach(up); }

  function init(root, cb){
    el = root; onPress = cb;
    el.addEventListener('pointerdown', e => {
      const k = keyAt(e.clientX, e.clientY); if(!k) return;
      e.preventDefault();
      try{ el.setPointerCapture(e.pointerId); }catch(_){}
      down(e.pointerId, k);
      onPress && onPress(+k.dataset.midi); // solo se registra al pulsar, no al deslizar
    });
    el.addEventListener('pointermove', e => {
      const a = active[e.pointerId]; if(!a) return;
      const k = keyAt(e.clientX, e.clientY);
      if(k && k !== a.el){ up(e.pointerId); down(e.pointerId, k); }
    });
    ['pointerup','pointercancel','lostpointercapture'].forEach(ev => el.addEventListener(ev, e => up(e.pointerId)));
    el.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('visibilitychange', () => { if(document.hidden) releaseAll(); });
  }
  function render(low, acc){
    releaseAll(); el.innerHTML = '';
    el.appendChild(octave(low + 1, acc)); // arriba: la siguiente
    el.appendChild(octave(low, acc));     // abajo: la elegida
  }

  function mountCarousel(box, onSelect){
    let cur = -1, timer;
    for(let o = 0; o <= 7; o++){
      const c = div('oct'); c.dataset.o = o; c.textContent = 'C' + o;
      c.addEventListener('click', () => { onSelect(o); center(o, true); });
      box.appendChild(c);
    }
    const mark = o => { cur = o; [...box.children].forEach(c => c.classList.toggle('sel', +c.dataset.o === o)); };
    function center(o, smooth){
      const c = box.children[o];
      box.scrollTo({left:c.offsetLeft - box.clientWidth / 2 + c.clientWidth / 2, behavior:smooth ? 'smooth' : 'auto'});
    }
    box.addEventListener('scroll', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const mid = box.scrollLeft + box.clientWidth / 2; let best = cur, bd = 1e9;
        [...box.children].forEach(c => { const d = Math.abs(c.offsetLeft + c.clientWidth / 2 - mid); if(d < bd){ bd = d; best = +c.dataset.o; } });
        if(best !== cur) onSelect(best);
      }, 90);
    });
    return {mark, center};
  }

  NS.Piano = {init, render, releaseAll, mountCarousel};
})(window.NS = window.NS || {});
