/* Sonavia — menú principal y navegación entre modos.
   Pantallas (S.data.tab):  home · piano · rhythm · melodies  (Modo Escritor)  ·  studio · cascada  (Modo Estudio)
   · El menú principal tiene el título, el botón de Ajustes y un panel por modo; al tocar un panel se despliega debajo
     su lista (melodías / proyectos) para elegir antes de entrar.
   · Dentro de un modo solo hay una barra fina: «←» para volver al menú, «⇄» para cambiar de melodía / proyecto sin salir, y las secciones de ese modo. */
(function(NS){
  'use strict';
  const S = NS.State, $ = id => document.getElementById(id);
  const bar = $('tabs');

  const MODES = {
    writer: {name:'Escritor', sections:[
      {id:'piano',    icon:'✏️', label:'Escribir'},
      {id:'rhythm',   icon:'🥁', label:'Ritmo'},
      {id:'melodies', icon:'▶',  label:'Escuchar'}]},
    studio: {name:'Estudio', sections:[
      {id:'roll',    icon:'🎹', label:'Roll'},
      {id:'tracks',  icon:'🎚', label:'Pistas'},
      {id:'mixer',   icon:'🎛', label:'Mezcla'},
      {id:'cascada', icon:'🌠', label:'Cascada'},
      {id:'project', icon:'💾', label:'Proyecto'}]}
  };
  const modeOf = tab => ['piano', 'rhythm', 'melodies'].includes(tab) ? 'writer' : (['studio', 'cascada'].includes(tab) ? 'studio' : null);
  // Sección marcada en la barra: en el Estudio depende de qué panel interno está abierto
  const currentSection = () => {
    const t = S.data.tab;
    if(t === 'studio') return NS.Studio.currentSub ? NS.Studio.currentSub() : 'roll';
    return t;
  };

  /* ---------- Barra del modo ---------- */
  let builtFor = null;
  function render(){
    const tab = S.data.tab, mode = modeOf(tab);
    bar.hidden = !mode;
    if(!mode) { builtFor = null; return; }
    if(builtFor !== mode){
      builtFor = mode;
      const m = MODES[mode];
      bar.className = 'n' + m.sections.length;
      const sw = mode === 'writer' ? ['Cambiar de melodía', 'Melodías'] : ['Cambiar de proyecto', 'Proyectos'];
      bar.innerHTML = '<button class="tab back" data-nav="home" aria-label="Volver al menú principal" title="Menú principal"><span class="ti">←</span></button>' +
        '<button class="tab swap" data-swap="' + mode + '" aria-label="' + sw[0] + '" title="' + sw[0] + '"><span class="ti">⇄</span></button>' +
        m.sections.map(s => '<button class="tab" data-nav="' + s.id + '"><span class="ti">' + s.icon + '</span><span class="tl">' + s.label + '</span></button>').join('') +
        (mode === 'writer' ? '<button id="panicBtn" class="panic" title="Silenciar todo el sonido" aria-label="Silenciar todo">🔇</button>' : '');
    }
    const cur = currentSection();
    [...bar.querySelectorAll('[data-nav]')].forEach(b => b.classList.toggle('sel', b.dataset.nav === cur));
  }

  function go(id){
    NS.Player.stop();
    if(id === 'home') return S.set({tab:'home'});
    if(['roll', 'tracks', 'mixer', 'project'].includes(id)){        // paneles internos del Estudio
      NS.Studio.showSub(id);
      if(S.data.tab !== 'studio') S.set({tab:'studio'}); else render();
      return;
    }
    if(id === 'rhythm'){                                    // el ritmo se crea para la melodía que se está editando
      const ed = S.melodies.some(m => m.id === S.data.editingId) ? S.data.editingId : S.data.rhMel;
      return S.set({tab:'rhythm', rhMel:ed});
    }
    S.set({tab:id});
  }

  bar.addEventListener('click', e => {
    const sw = e.target.closest('[data-swap]');
    if(sw){ NS.Player.stop(); if(sw.dataset.swap === 'writer') NS.Melodies.elegir(); else NS.Studio.proyectos.elegir(); return; }
    if(e.target.closest('#panicBtn')){ NS.Piano.releaseAll(); NS.Player.stop(); NS.Studio.panic(); NS.Cascada.detener(); NS.Audio.panic(); return; }
    const b = e.target.closest('[data-nav]'); if(b) go(b.dataset.nav);
  });
  NS.Studio.subHooks = (NS.Studio.subHooks || []).concat(() => render());   // cambia el panel interno del Estudio → se re-marca la barra

  /* ---------- Menú principal: paneles desplegables ---------- */
  const modes = [...document.querySelectorAll('.mode')];
  let lastMode = null;
  const refreshList = mode => {
    if(mode === 'writer') NS.Melodies.dibujar();
    else NS.Studio.proyectos.mostrarLista();
  };
  function toggleMode(el, want){
    const open = want === undefined ? !el.classList.contains('open') : want;
    modes.forEach(m => {
      const o = m === el && open;
      m.classList.toggle('open', o);
      m.querySelector('.modeCard').setAttribute('aria-expanded', String(o));
      m.querySelector('.mList').hidden = !o;
    });
    if(open){
      refreshList(el.dataset.mode);
      setTimeout(() => { try{ el.scrollIntoView({block:'nearest', behavior:'smooth'}); }catch(_){} }, 40);
    }
  }
  modes.forEach(el => {
    const card = el.querySelector('.modeCard');
    card.addEventListener('click', () => toggleMode(el));
    card.addEventListener('keydown', e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); toggleMode(el); } });
  });

  /* ---------- Cambios de pantalla ---------- */
  let pushed = false;
  S.on(keys => {
    if(!keys.includes('tab')) return;
    const tab = S.data.tab, mode = modeOf(tab);
    if(mode) lastMode = mode;
    if(tab === 'home'){                                     // al volver, se reabre el panel del modo del que se viene
      const el = lastMode && document.getElementById('mode-' + lastMode);
      if(el) toggleMode(el, true);
    }
    // Botón «atrás» de Android: dentro de un modo vuelve al menú en vez de cerrar la app
    if(mode && !pushed){ try{ history.pushState({sonavia:1}, ''); pushed = true; }catch(_){} }
    else if(!mode && pushed){ pushed = false; try{ if(history.state && history.state.sonavia) history.back(); }catch(_){} }
  });
  window.addEventListener('popstate', () => {
    if(pushed){ pushed = false; if(S.data.tab !== 'home') S.set({tab:'home'}); }
  });

  NS.Nav = {go, render, modeOf};
})(window.NS = window.NS || {});
