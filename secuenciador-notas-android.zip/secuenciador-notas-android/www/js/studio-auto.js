/* Estudio — «📈 Automatización»: curvas de volumen y balance que cambian durante la canción.
   Panel bajo el Roll que comparte desplazamiento, zoom y cuadrícula con él (la curva siempre queda alineada con las notas).
   Cada pista guarda sus curvas en pista.auto (datos y matemáticas: js/automation.js).
   Mientras suena, la curva manda sobre los deslizadores de Pistas; al detener o pausar vuelven a valer los deslizadores. */
(function(NS){
  'use strict';
  const T = window.Tone, ST = NS.Studio, R = ST.roll, A = NS.Auto, $ = id => document.getElementById(id);
  const panel = $('stAuto'), toggle = document.querySelector('[data-auto-toggle]');
  const eje = $('stAutoEje'), lienzo = $('stAutoLienzo'), box = $('stAutoBox'), info = $('stAutoInfo');
  const teoPanel = $('stTeoria'), teoToggle = document.querySelector('[data-teo-toggle]');
  const PAD = 12, RADIO = 7, TOQUE = 22, ORDEN = ['lineal', 'suave', 'escalon'];
  const ui = {param:'vol', curva:'lineal'};
  let w = 0, h = 0, ew = 0, cx = null, ex = null, raf = 0, sel = null, g = null, ultimaPista = null;
  const hist = new Map();                                   // id de pista → {u:[], r:[]}  (Deshacer / Rehacer de la automatización)

  const pista = () => ST.cur();
  const laneDe = (t, k) => (t && t.auto && t.auto[k]) || null;
  const lane = () => laneDe(pista(), ui.param);
  const P = () => A.PARAMS[ui.param];

  /* ---------- Reproducción: un tramo de curva por cada 1/32 que programa el Roll ---------- */
  let tocadas = false;
  function tick(st, time, sec){
    for(const t of ST.tracks){
      const a = t.auto; if(!a) continue;
      const lv = a.vol, lp = a.pan;
      if(lv && lv.pts.length){ const v0 = A.valorEn(lv, st); t.audio.autoVol(v0, lv.curva === 'escalon' ? v0 : A.valorEn(lv, st + 1), time, sec); tocadas = true; }
      if(lp && lp.pts.length){ const v0 = A.valorEn(lp, st); t.audio.autoPan(v0, lp.curva === 'escalon' ? v0 : A.valorEn(lp, st + 1), time, sec); tocadas = true; }
    }
  }
  const restaurar = () => {
    if(!tocadas) return; tocadas = false;
    ST.tracks.forEach(t => { try{ t.audio.restaurar(); }catch(e){} });
  };
  T.Transport.on('stop', restaurar);
  T.Transport.on('pause', restaurar);

  /* ---------- Historial ---------- */
  const H = t => { let x = hist.get(t.id); if(!x){ x = {u:[], r:[]}; hist.set(t.id, x); } return x; };
  const snap = t => JSON.stringify(t.auto || null);
  const poner = (t, json) => {                              // vuelve a un estado guardado
    const v = JSON.parse(json); t.auto = v ? A.limpiar(v) : undefined;
    sel = null; try{ t.audio.restaurar(); }catch(e){}
  };
  function commit(t, pre){
    if(snap(t) === pre) return;
    const x = H(t); x.u.push(pre); if(x.u.length > 40) x.u.shift(); x.r = [];
    ST.changed();
  }
  function deshacer(){ const t = pista(); if(!t) return; const x = H(t); if(!x.u.length) return; x.r.push(snap(t)); poner(t, x.u.pop()); ST.changed(); refrescar(); }
  function rehacer(){ const t = pista(); if(!t) return; const x = H(t); if(!x.r.length) return; x.u.push(snap(t)); poner(t, x.r.pop()); ST.changed(); refrescar(); }

  /* ---------- Edición de datos ---------- */
  function asegurar(t){                                     // la curva del parámetro actual (se crea si no existe)
    if(!t.auto) t.auto = {};
    if(!t.auto[ui.param]) t.auto[ui.param] = {curva:ui.curva, pts:[]};
    return t.auto[ui.param];
  }
  function limpiarVacias(t){
    if(t.auto){
      for(const k of Object.keys(t.auto)) if(!t.auto[k].pts.length) delete t.auto[k];
      if(!Object.keys(t.auto).length) t.auto = undefined;
    }
    if(!A.alguna(t.auto)){ try{ t.audio.restaurar(); }catch(e){} }
  }
  const snapV = v => { const p = P(); v = Math.max(p.min, Math.min(p.max, v)); return ui.param === 'vol' ? Math.round(v) : Math.round(v * 20) / 20; };

  /* ---------- Medidas y coordenadas ---------- */
  const yDe = v => PAD + (1 - (v - P().min) / (P().max - P().min)) * (h - PAD * 2);
  const vDe = y => snapV(P().min + (1 - (y - PAD) / (h - PAD * 2)) * (P().max - P().min));
  function fit(c){
    const r = c.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    c.width = Math.round(r.width * d); c.height = Math.round(r.height * d);
    const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0);
    return [r.width, r.height, x];
  }
  const pedirDibujo = () => { if(!raf) raf = requestAnimationFrame(() => { raf = 0; dibujar(); }); };

  /* ---------- Dibujo ---------- */
  function dibujar(){
    if(panel.hidden || !w || !h || !cx) return;
    const V = R.vista(), C = NS.Theme.palette(), t = pista(), l = lane(), p = P(), col = t ? t.color : C.escalaPunto;
    cx.clearRect(0, 0, w, h); ex.clearRect(0, 0, ew, h);

    // cuadrícula (la misma del Roll)
    cx.fillStyle = C.fila; cx.fillRect(0, 0, w, h);
    const st = Math.max(1, V.paso), k0 = Math.floor(V.x / (V.u * st)), k1 = Math.ceil((V.x + w) / (V.u * st));
    cx.lineWidth = 1;
    for(let k = k0; k <= k1; k++){
      const q = k * st; if(q < 0) continue;
      const compas = q % 32 === 0, tiempo = q % 8 === 0;
      if(!compas && !tiempo && V.u * st < 7) continue;
      const x = Math.round(q * V.u - V.x) + 0.5;
      cx.strokeStyle = compas ? C.cuadriculaCompas : tiempo ? C.cuadriculaTiempo : C.cuadriculaFina;
      cx.beginPath(); cx.moveTo(x, 0); cx.lineTo(x, h); cx.stroke();
    }
    // líneas de nivel
    ex.font = '10px system-ui'; ex.textAlign = 'right'; ex.textBaseline = 'middle'; ex.fillStyle = C.numeroCompas;
    for(const m of p.marcas){
      const y = Math.round(yDe(m)) + 0.5, cero = m === 0;
      cx.strokeStyle = cero ? C.cuadriculaCompas : C.cuadriculaFina; cx.setLineDash(cero ? [] : [3, 4]);
      cx.beginPath(); cx.moveTo(0, y); cx.lineTo(w, y); cx.stroke(); cx.setLineDash([]);
      const txt = ui.param === 'vol' ? (m <= -40 ? '−∞' : (m > 0 ? '+' : m < 0 ? '−' : '') + Math.abs(m) + ' dB') : (m > 0 ? 'Der' : m < 0 ? 'Izq' : 'Centro');
      ex.fillText(txt, ew - 6, Math.max(7, Math.min(h - 7, y)));
    }
    ex.fillStyle = col; ex.fillRect(0, 0, 4, h);

    // curva
    if(l && l.pts.length){
      const X = s => s * V.u - V.x, pts = l.pts;
      cx.beginPath();
      if(l.curva === 'escalon'){
        cx.moveTo(0, yDe(pts[0].v));
        for(let i = 0; i < pts.length; i++){
          const x = X(pts[i].s);
          if(i) cx.lineTo(x, yDe(pts[i - 1].v));
          cx.lineTo(x, yDe(pts[i].v));
        }
        cx.lineTo(w, yDe(pts[pts.length - 1].v));
      }else{
        for(let x = 0; x <= w; x += 2){ const y = yDe(A.valorEn(l, (x + V.x) / V.u)); x ? cx.lineTo(x, y) : cx.moveTo(x, y); }
      }
      cx.lineJoin = 'round'; cx.lineWidth = 2.5; cx.strokeStyle = col; cx.stroke();
      cx.lineTo(w, h); cx.lineTo(0, h); cx.closePath(); cx.globalAlpha = 0.16; cx.fillStyle = col; cx.fill(); cx.globalAlpha = 1;
      for(const q of pts){
        const x = X(q.s); if(x < -RADIO || x > w + RADIO) continue;
        const y = yDe(q.v), on = q === sel;
        cx.beginPath(); cx.arc(x, y, on ? RADIO + 2 : RADIO, 0, 6.2832);
        cx.fillStyle = on ? C.notaElegida : col; cx.fill();
        cx.lineWidth = on ? 2.5 : 1.5; cx.strokeStyle = on ? C.notaElegidaBorde : C.fila; cx.stroke();
      }
    }else{
      // sin curva: el valor del deslizador y una pista de qué hacer
      const y = yDe(ui.param === 'vol' ? (t ? t.vol : 0) : (t ? t.pan : 0));
      cx.setLineDash([6, 5]); cx.lineWidth = 2; cx.strokeStyle = col; cx.globalAlpha = 0.6;
      cx.beginPath(); cx.moveTo(0, y); cx.lineTo(w, y); cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1;
      cx.font = '600 12px system-ui'; cx.textAlign = 'center'; cx.textBaseline = 'middle'; cx.fillStyle = C.etiquetaTexto;
      const ty = y < h / 2 ? Math.min(h - 14, y + 22) : Math.max(14, y - 22);
      cx.globalAlpha = 0.8; cx.fillText('Toca aquí para añadir el primer punto', w / 2, ty); cx.globalAlpha = 1;
    }
    // cursor de reproducción
    if(V.cursor >= 0){ cx.fillStyle = C.cursor; cx.fillRect(V.cursor * V.u - V.x, 0, 2, h); }
  }

  /* ---------- Controles ---------- */
  const ubicacion = s => { const c = Math.floor(s / 32) + 1, tm = Math.floor((s % 32) / 8) + 1, r = s % 8; return 'compás ' + c + ' · tiempo ' + tm + (r ? ' +' + r + '/32' : ''); };
  function refrescar(){
    const t = pista(), l = lane(), x = t ? H(t) : {u:[], r:[]}, abierto = !panel.hidden;
    toggle.classList.toggle('on', abierto); toggle.setAttribute('aria-expanded', abierto);
    toggle.classList.toggle('tiene', !!t && A.alguna(t.auto));        // punto de aviso: esta pista tiene curvas
    if(!abierto) return;
    panel.querySelectorAll('#stAutoParam button').forEach(b => {
      const k = b.dataset.p; b.classList.toggle('sel', k === ui.param); b.classList.toggle('tiene', !!t && A.hay(t.auto, k));
    });
    const bc = panel.querySelector('[data-a="curva"]'); bc.textContent = A.CURVAS[l ? l.curva : ui.curva];
    panel.querySelector('[data-a="undo"]').disabled = !x.u.length;
    panel.querySelector('[data-a="redo"]').disabled = !x.r.length;
    panel.querySelector('[data-a="del"]').disabled = !sel;
    panel.querySelector('[data-a="clear"]').disabled = !(l && l.pts.length);
    const n = l ? l.pts.length : 0;
    info.textContent = sel ? 'Punto: ' + P().fmt(sel.v) + ' · ' + ubicacion(sel.s)
      : (t ? '«' + t.name + '» · ' + P().nombre + ': ' + (n ? n + (n === 1 ? ' punto' : ' puntos') + ' · toca para añadir, arrastra para mover' : 'sin curva (vale el deslizador de Pistas)') : '');
    pedirDibujo();
  }
  function mostrar(on){
    if(on && !teoPanel.hidden) teoToggle.click();           // un solo panel a la vez: el Roll conserva su espacio
    panel.hidden = !on;
    refrescar(); R.redibujar();
  }
  toggle.addEventListener('click', () => mostrar(panel.hidden));
  teoToggle.addEventListener('click', () => { if(!teoPanel.hidden && !panel.hidden) mostrar(false); });

  panel.addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b || b.disabled) return;
    const t = pista(); if(!t) return;
    if(b.dataset.p){ ui.param = b.dataset.p; sel = null; refrescar(); return; }
    const a = b.dataset.a;
    if(a === 'undo') deshacer();
    else if(a === 'redo') rehacer();
    else if(a === 'curva'){
      const l = lane(), sig = ORDEN[(ORDEN.indexOf(l ? l.curva : ui.curva) + 1) % ORDEN.length];
      ui.curva = sig;
      if(l){ const pre = snap(t); l.curva = sig; commit(t, pre); }
      refrescar();
    }else if(a === 'del' && sel){
      const l = lane(), i = l ? l.pts.indexOf(sel) : -1; if(i < 0) return;
      const pre = snap(t); l.pts.splice(i, 1); sel = null; limpiarVacias(t); commit(t, pre); refrescar();
    }else if(a === 'clear'){
      const l = lane(); if(!l || !l.pts.length) return;
      ST.ask({title:'Borrar la curva', msg:'Se quitarán los ' + l.pts.length + ' puntos de «' + P().nombre + '» en «' + t.name + '». Podrás recuperarlos con Deshacer (↶).', ok:'Borrar curva'}).then(ok => {
        if(!ok || ST.cur() !== t) return;
        const pre = snap(t); delete t.auto[ui.param]; sel = null; limpiarVacias(t); commit(t, pre); refrescar();
      });
    }
  });

  /* ---------- Gestos sobre la curva ---------- */
  const pos = e => { const r = lienzo.getBoundingClientRect(); return {x:e.clientX - r.left, y:e.clientY - r.top}; };
  function puntoEn(px, py){                                  // el punto más cercano al dedo (si está dentro del radio de toque)
    const l = lane(); if(!l) return null;
    const V = R.vista(); let mejor = null, dm = TOQUE;
    for(const q of l.pts){
      const d = Math.hypot(q.s * V.u - V.x - px, yDe(q.v) - py);
      if(d <= dm){ dm = d; mejor = q; }
    }
    return mejor;
  }
  lienzo.addEventListener('pointerdown', e => {
    if(g || !pista()) return;
    lienzo.setPointerCapture(e.pointerId);
    const p = pos(e), hit = puntoEn(p.x, p.y);
    if(hit) sel = hit;
    g = {id:e.pointerId, x0:p.x, y0:p.y, hit, moved:false, mode:null, vx:R.vista().x, pre:snap(pista())};
    refrescar();
  });
  lienzo.addEventListener('pointermove', e => {
    if(!g || e.pointerId !== g.id) return;
    const p = pos(e), dx = p.x - g.x0, dy = p.y - g.y0, V = R.vista();
    if(!g.moved && Math.hypot(dx, dy) > 8){ g.moved = true; g.mode = g.hit ? 'mover' : 'desplazar'; }
    if(!g.moved) return;
    if(g.mode === 'desplazar'){ R.desplazarX(g.vx - dx); return; }
    const l = lane(); if(!l) return;
    const i = l.pts.indexOf(g.hit), prev = l.pts[i - 1], next = l.pts[i + 1], st = Math.max(1, V.paso);
    let s = Math.round((p.x + V.x) / V.u / st) * st;
    s = Math.max(prev ? prev.s + 1 : 0, Math.min(next ? next.s - 1 : A.MAXU - 1, s));
    g.hit.s = s; g.hit.v = vDe(p.y);
    R.asegurarHasta(s);
    refrescar();
  });
  function fin(e, cancelar){
    if(!g || e.pointerId !== g.id) return;
    const gg = g, t = pista(); g = null;
    if(!t) return;
    if(cancelar){ poner(t, gg.pre); refrescar(); return; }
    if(!gg.moved && !gg.hit) anadir(t, gg.x0, gg.y0);
    else if(gg.mode === 'mover') commit(t, gg.pre);
    refrescar();
  }
  lienzo.addEventListener('pointerup', e => fin(e, false));
  lienzo.addEventListener('pointercancel', e => fin(e, true));
  lienzo.addEventListener('contextmenu', e => e.preventDefault());

  function anadir(t, x, y){                                  // un toque en un lugar vacío = nuevo punto
    const V = R.vista(), st = Math.max(1, V.paso);
    const s = Math.max(0, Math.min(A.MAXU - 1, Math.round((x + V.x) / V.u / st) * st)), v = vDe(y);
    const pre = snap(t), l = asegurar(t), i = l.pts.findIndex(q => q.s >= s);
    if(i >= 0 && l.pts[i].s === s){ l.pts[i].v = v; sel = l.pts[i]; }
    else{
      if(l.pts.length >= A.MAXPTS){ ST.toast('Máximo ' + A.MAXPTS + ' puntos por curva'); limpiarVacias(t); return; }
      const q = {s, v}; l.pts.splice(i < 0 ? l.pts.length : i, 0, q); sel = q;
    }
    R.asegurarHasta(s); commit(t, pre);
  }

  /* ---------- Tamaño y enlaces con el resto del Estudio ---------- */
  new ResizeObserver(() => {
    if(panel.hidden) return;
    let r = fit(lienzo); w = r[0]; h = r[1]; cx = r[2];
    r = fit(eje); ew = r[0]; ex = r[2];
    dibujar();
  }).observe(box);
  NS.Theme.onChange(pedirDibujo);
  ST.listeners.push(() => {                                  // otra pista, otro proyecto o un cambio en las pistas
    if(ST.curId !== ultimaPista){ ultimaPista = ST.curId; sel = null; }
    refrescar();
  });
  R.uiHooks.push(() => { if(!panel.hidden) pedirDibujo(); });

  ST.auto = {
    tick, dibujar,
    reiniciar(){ hist.clear(); sel = null; tocadas = false; },   // al abrir otro proyecto
    abierto: () => !panel.hidden,
    // Abre el panel en la pista y el parámetro indicados (lo usa el botón «📈 Automatizar» de Pistas)
    abrirPara(id, param){
      if(A.PARAMS[param]) ui.param = param;
      ST.selectTrack(id); ST.showSub('roll'); sel = null;
      if(panel.hidden) mostrar(true); else refrescar();
    }
  };
  refrescar();
})(window.NS = window.NS || {});
