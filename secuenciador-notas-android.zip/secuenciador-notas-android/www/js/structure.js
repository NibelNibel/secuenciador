/* Estructura de la canción: pestañas de secciones (Introducción, Coro…), pestañas de frases,
   edición de etiquetas, plantillas de estructura y diálogo (sheet). */
(function(NS){
  const S = NS.State, SG = NS.Song, $ = id => document.getElementById(id);
  const secBar = $('secBar'), phrBar = $('phrBar'), secTools = $('secTools');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

  /* ---------- Diálogo ---------- */
  const sheet = $('sheet'), sBody = $('sheetBody'), sOk = $('sheetOk');
  let okFn = null, closeFn = null, accepted = false;
  // onClose(aceptado) es opcional: avisa al cerrar el diálogo (true = se pulsó Aceptar; false = Cancelar / tocar fuera)
  function openSheet(title, okText, build, onOk, onClose){
    $('sheetTitle').textContent = title;
    const box = document.createElement('div'); sBody.replaceChildren(box); build(box); // cuerpo nuevo: no acumula listeners
    okFn = onOk; closeFn = onClose || null; accepted = false;
    sOk.hidden = !onOk; sOk.textContent = okText || 'Aceptar';
    $('sheetCancel').textContent = onOk ? 'Cancelar' : 'Cerrar';
    sheet.hidden = false;
  }
  const closeSheet = () => {
    sheet.hidden = true; sheet.classList.remove('top'); okFn = null;
    const c = closeFn; closeFn = null; if(c) c(accepted);
  };
  NS.Sheet = {open:(title, okText, build, onOk, onClose) => { openSheet(title, okText, build, onOk, onClose); sheet.classList.add('top'); }, close:closeSheet}; // arriba: el teclado del móvil no la tapa
  $('sheetCancel').addEventListener('click', closeSheet);
  sheet.addEventListener('click', e => { if(e.target === sheet) closeSheet(); });
  sOk.addEventListener('click', () => { const f = okFn; if(f && f() !== false){ accepted = true; closeSheet(); } });

  // Pide una etiqueta: escribir libre o tocar una de las opciones de estructura.
  function askLabel(title, current, done){
    let input;
    NS.Sheet.open(title, 'Aceptar', box => {
      box.innerHTML = '<input id="lblInput" maxlength="40" placeholder="Escribe una etiqueta…" value="' + esc(current) + '">' +
        '<p class="small">Opciones de estructura:</p><div class="chipsRow">' +
        SG.PRESETS.map(p => '<button class="btn chip" data-p="' + esc(p) + '">' + esc(p) + '</button>').join('') + '</div>';
      input = box.querySelector('#lblInput');
      box.addEventListener('click', e => { const b = e.target.closest('[data-p]'); if(b){ closeSheet(); done(b.dataset.p, true); } });
      input.addEventListener('keydown', e => { if(e.key === 'Enter'){ e.preventDefault(); sOk.click(); } });
    }, () => { done(input.value.trim(), false); });
  }

  /* ---------- Secciones ---------- */
  const isBlank = secs => secs.length === 1 && !secs[0].label && secs[0].phrases.every(p => !p.notes.length);

  function addSection(){
    askLabel('Nueva sección', '', (label, preset) => S.mutate((secs, pos) => {
      if(preset) label = SG.uniqueLabel(secs, label, -1);
      secs.splice(pos.sec + 1, 0, SG.newSection(label)); pos.sec++; pos.phr = 0;
    }));
  }
  function editLabel(){
    const d = S.data;
    askLabel('Etiqueta de la sección', d.sections[d.sec].label, (label, preset) => S.mutate((secs, pos) => {
      secs[pos.sec].label = preset ? SG.uniqueLabel(secs, label, pos.sec) : label;
    }));
  }
  function moveSection(dir){
    S.mutate((secs, pos) => {
      const j = pos.sec + dir; if(j < 0 || j >= secs.length) return;
      [secs[pos.sec], secs[j]] = [secs[j], secs[pos.sec]]; pos.sec = j;
    });
  }
  function dupSection(){
    S.mutate((secs, pos) => {
      const c = JSON.parse(JSON.stringify(secs[pos.sec]));
      c.id = SG.newSection().id; if(c.label) c.label = SG.uniqueLabel(secs, c.label, -1);
      secs.splice(pos.sec + 1, 0, c); pos.sec++; pos.phr = 0;
    });
  }
  function delSection(){
    const d = S.data, s = d.sections[d.sec], n = s.phrases.reduce((a, p) => a + p.notes.length, 0);
    if(n && !confirm('¿Eliminar «' + SG.labelOf(s, d.sec) + '» y sus ' + n + ' notas?')) return;
    NS.Player.stop();
    S.mutate((secs, pos) => {
      secs.splice(pos.sec, 1);
      if(!secs.length) secs.push(SG.newSection());
      pos.sec = Math.min(pos.sec, secs.length - 1); pos.phr = 0;
    });
  }
  function templates(){
    openSheet('Estructura de la canción', null, box => {
      box.innerHTML = '<p class="small">Añade las secciones al final (vacías). Tus notas no se tocan.</p>' +
        SG.TEMPLATES.map((t, i) => '<button class="btn tpl" data-t="' + i + '"><b>' + esc(t.name) + '</b><span>' + esc(t.parts.join(' · ')) + '</span></button>').join('');
      box.addEventListener('click', e => {
        const b = e.target.closest('[data-t]'); if(!b) return;
        const t = SG.TEMPLATES[+b.dataset.t]; closeSheet();
        S.mutate((secs, pos) => {
          if(isBlank(secs)) secs.length = 0;
          const first = secs.length;
          t.parts.forEach(l => secs.push(SG.newSection(SG.uniqueLabel(secs, l, -1))));
          pos.sec = first; pos.phr = 0;
        });
      });
    });
  }

  secBar.addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    if(b.dataset.add) return addSection();
    if(+b.dataset.i !== S.data.sec){ NS.Player.stop(); S.set({sec:+b.dataset.i, phr:0}); }
    else editLabel(); // tocar la sección ya activa → editar etiqueta
  });
  secTools.addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    ({label:editLabel, left:() => moveSection(-1), right:() => moveSection(1), tpl:templates, dup:dupSection, del:delSection})[b.dataset.sact]();
  });

  /* ---------- Frases ---------- */
  phrBar.addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    if(b.dataset.add) return S.mutate((secs, pos) => { secs[pos.sec].phrases.push({notes:[]}); pos.phr = secs[pos.sec].phrases.length - 1; });
    S.set({phr:+b.dataset.i});
  });

  /* ---------- Dibujo ---------- */
  function draw(){
    const d = S.data;
    secBar.innerHTML = d.sections.map((s, i) =>
      '<button class="stab' + (i === d.sec ? ' sel' : '') + '" data-i="' + i + '">' + esc(SG.labelOf(s, i)) + '</button>').join('') +
      '<button class="stab add" data-add="1" title="Nueva sección">＋</button>';
    const sec = d.sections[d.sec];
    phrBar.innerHTML = sec.phrases.map((p, i) =>
      '<button class="ptab' + (i === d.phr ? ' sel' : '') + '" data-i="' + i + '">Frase ' + (i + 1) + '<small>' + p.notes.length + '</small></button>').join('') +
      '<button class="ptab add" data-add="1" title="Nueva frase">＋</button>';
    $('secName').textContent = SG.labelOf(sec, d.sec) + ' (' + (d.sec + 1) + ' de ' + d.sections.length + ')';
    $('phrName').textContent = 'Frase ' + (d.phr + 1) + ' de ' + sec.phrases.length + ' · en «' + SG.labelOf(sec, d.sec) + '»';
    secTools.querySelector('[data-sact=left]').disabled = d.sec === 0;
    secTools.querySelector('[data-sact=right]').disabled = d.sec === d.sections.length - 1;
    const a = document.querySelector('#secBar .sel'), b = document.querySelector('#phrBar .sel');
    a && a.scrollIntoView({block:'nearest', inline:'nearest'}); b && b.scrollIntoView({block:'nearest', inline:'nearest'});
  }
  S.on(keys => { if(keys.some(k => ['sections', 'sec', 'phr'].includes(k))) draw(); });
  draw();
})(window.NS = window.NS || {});
