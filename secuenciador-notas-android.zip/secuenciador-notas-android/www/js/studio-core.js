/* Estudio multipista (piano roll) — núcleo: pistas, tempo, avisos, diálogos y guardado automático.
   El sonido NO se genera aquí: cada pista usa un instrumento de NS.Audio (el mismo motor del teclado). */
(function(NS){
  'use strict';
  const T = window.Tone, $ = id => document.getElementById(id);
  const ST = NS.Studio = {metro:false, bpm:120, name:'', tracks:[], curId:0, listeners:[]};
  const MAX = 8, MINDB = -40, MAXDB = 6;
  const COLORS = ['#4dd0a1', '#64b5f6', '#ba68c8', '#ff8a65', '#f06292', '#aed581', '#4dd0e1', '#a1887f'];
  const num = (v, lo, hi, d) => (Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d);
  const M = NS.Mezcla;
  let nextId = 1, master = 0, general = M.generalVacio(), ready = false, timer = 0;   // general: efectos de toda la cancion
  Object.assign(ST, {MAX, MINDB, MAXDB});

  /* ---------- Aviso breve y diálogo (confirmar / pedir texto) ---------- */
  let toastT = 0;
  ST.toast = msg => {
    const t = $('toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, 2600);
  };
  // opts: {title, msg, ok, input (valor inicial), max}. Devuelve true/false, o el texto (o null) si hay input.
  ST.ask = o => new Promise(res => {
    let input = null;
    NS.Sheet.open(o.title || '', o.ok || 'Aceptar', box => {
      if(o.msg){ const p = document.createElement('p'); p.className = 'small'; p.textContent = o.msg; box.appendChild(p); }
      if(o.input !== undefined){
        input = document.createElement('input'); input.value = o.input; input.maxLength = o.max || 20; input.style.width = '100%';
        input.addEventListener('keydown', e => { if(e.key === 'Enter'){ e.preventDefault(); $('sheetOk').click(); } });
        box.appendChild(input); setTimeout(() => { input.focus(); input.select(); }, 60);
      }
    }, () => { res(input ? input.value : true); }, accepted => { if(!accepted) res(input ? null : false); });
  });

  /* ---------- Guardado automático (en este dispositivo) ---------- */
  const save = () => { clearTimeout(timer); timer = 0; if(ready && ST.roll && ST.persist) ST.persist(); };   // ST.persist: js/studio-proyectos.js
  ST.changed = () => { if(!ready) return; clearTimeout(timer); timer = setTimeout(save, 500); };
  ST.saveNow = save;
  ST.enableSave = () => { ready = true; };
  document.addEventListener('visibilitychange', () => { if(document.hidden) save(); });
  window.addEventListener('pagehide', save);

  /* ---------- Tempo ---------- */
  ST.setBpm = (v, quiet) => {
    v = Math.max(40, Math.min(240, Math.round(v) || 120));
    ST.bpm = v; T.Transport.bpm.value = v; $('stBpmVal').textContent = v;
    if(!quiet) ST.changed();
  };

  /* ---------- Pistas ---------- */
  const emit = () => { ST.listeners.forEach(f => f()); ST.changed(); };
  ST.emit = emit;
  const instOk = id => NS.Audio.list().some(i => i.id === id);
  ST.instName = id => { const i = NS.Audio.list().find(x => x.id === id); return i ? i.name : 'Piano'; };
  const cleanName = (v, t) => String(v).trim().slice(0, 20) || ('Pista ' + (ST.tracks.indexOf(t) + 1));
  ST.cleanName = cleanName;

  function build(r){
    const t = {id:r.id, name:r.name, inst:r.inst, color:r.color, mute:!!r.mute, solo:!!r.solo, vol:r.vol, pan:r.pan, auto:r.auto,   // auto: curvas de automatización (NS.Auto), opcional
      gan:M.limpiarGanancia(r.gan), fx:M.limpiarEfectos(r.fx)};   // Nibel: ganancia de entrada (dB) y efectos de la pista, del mezclador
    t.audio = NS.Audio.createTrack({inst:t.inst, vol:t.vol, pan:t.pan, gan:t.gan, fx:t.fx});
    return t;
  }
  ST.cur = () => ST.tracks.find(t => t.id === ST.curId);
  ST.trackById = id => ST.tracks.find(t => t.id === id);
  ST.index = () => ST.tracks.findIndex(t => t.id === ST.curId);
  ST.audible = t => !t.mute && (!ST.tracks.some(x => x.solo) || t.solo);
  ST.master = () => master;
  ST.stopSound = () => ST.tracks.forEach(t => t.audio.silence());

  ST.addTrack = () => {
    if(ST.tracks.length >= MAX){ ST.toast('Máximo ' + MAX + ' pistas'); return false; }
    const id = nextId++, color = COLORS.find(c => !ST.tracks.some(t => t.color === c)) || COLORS[(id - 1) % COLORS.length];
    ST.tracks.push(build({id, name:'Pista ' + id, inst:'piano', color, vol:0, pan:0, gan:0, fx:M.efectosVacios()}));
    ST.curId = id; emit(); return true;
  };
  ST.selectTrack = id => { if(ST.curId !== id && ST.trackById(id)){ ST.roll.releaseHeld(); ST.curId = id; emit(); } };
  ST.removeTrack = id => {
    if(ST.tracks.length < 2) return;
    const i = ST.tracks.findIndex(t => t.id === id); if(i < 0) return;
    ST.roll.removeNotes(id);
    ST.tracks[i].audio.dispose(); ST.tracks.splice(i, 1);
    if(ST.curId === id) ST.curId = ST.tracks[Math.max(0, i - 1)].id;
    emit();
  };
  ST.setInst = (id, inst) => {
    const t = ST.trackById(id); if(!t || t.inst === inst || !instOk(inst)) return;
    t.inst = inst; t.audio.setInst(inst); emit();
    t.audio.play(60, .5, undefined, .9);                   // prueba el instrumento recién elegido
  };
  ST.renameTrack = (id, name) => { const t = ST.trackById(id); if(!t) return; t.name = cleanName(name, t); emit(); };
  ST.setMaster = v => { master = v; NS.Audio.setMaster(v); ST.changed(); };

  /* ---------- Mezclador: ganancia de entrada y efectos ---------- */
  // Nibel: estos cambios no vuelven a dibujar todo el Estudio; quien los pide actualiza solo su pantalla
  ST.setGanancia = (id, v) => { const t = ST.trackById(id); if(!t) return; t.gan = M.limpiarGanancia(v); t.audio.setGanancia(t.gan); ST.changed(); };
  ST.setEfecto = (id, clave, v) => {
    const t = ST.trackById(id); if(!t || !(clave in t.fx)) return;
    t.fx[clave] = M.limpiarEfectos({[clave]:v})[clave]; t.audio.setEfectos(t.fx); ST.changed();
  };
  ST.quitarEfectos = id => { const t = ST.trackById(id); if(!t) return; t.fx = M.efectosVacios(); t.audio.setEfectos(t.fx); ST.changed(); };
  ST.general = () => general;                                  // efectos de toda la cancion: {rev, eco, graves, agudos}
  ST.setGeneral = (clave, v) => {
    if(!(clave in general)) return;
    general = M.limpiarGeneral(Object.assign({}, general, {[clave]:v})); NS.Audio.setGeneral(general); ST.changed();
  };
  ST.quitarGeneral = () => { general = M.generalVacio(); NS.Audio.setGeneral(general); ST.changed(); };

  /* ---------- Exportar / importar todo el proyecto ---------- */
  ST.exportState = () => ({
    v:1, name:ST.name, bpm:ST.bpm, metro:!!ST.metro, master, general:Object.assign({}, general), curId:ST.curId, nextId,
    tracks:ST.tracks.map(t => ({id:t.id, name:t.name, inst:t.inst, color:t.color, mute:t.mute, solo:t.solo, vol:t.vol, pan:t.pan, auto:NS.Auto.copiar(t.auto),
      gan:t.gan, fx:Object.assign({}, t.fx)})),
    roll:ST.roll.exportState(), teoria:NS.Teoria.exportar()
  });
  // Valida todo antes de tocar nada; con d = null crea un proyecto vacío (una pista).
  ST.load = d => {
    d = d && typeof d === 'object' ? d : {};
    const seen = new Set(), tracks = [];
    for(const r of (Array.isArray(d.tracks) ? d.tracks : []).slice(0, MAX)){
      if(!r || !Number.isInteger(r.id) || r.id < 1 || seen.has(r.id)) continue;
      seen.add(r.id);
      tracks.push({id:r.id, name:String(r.name || '').trim().slice(0, 20) || 'Pista ' + (tracks.length + 1), inst:instOk(r.inst) ? r.inst : 'piano',
        color:typeof r.color === 'string' && /^#[0-9a-f]{6}$/i.test(r.color) ? r.color : COLORS[(r.id - 1) % COLORS.length],
        mute:!!r.mute, solo:!!r.solo, vol:num(r.vol, MINDB, MAXDB, 0), pan:num(r.pan, -1, 1, 0), auto:NS.Auto.limpiar(r.auto),
        gan:M.limpiarGanancia(r.gan), fx:M.limpiarEfectos(r.fx)});
    }
    if(!tracks.length) tracks.push({id:1, name:'Pista 1', inst:'piano', color:COLORS[0], mute:false, solo:false, vol:0, pan:0, gan:0, fx:M.efectosVacios()});
    ST.roll.releaseHeld();
    if(ST.auto) ST.auto.reiniciar();                           // el historial de la automatización es de cada proyecto
    ST.tracks.forEach(t => t.audio.dispose()); ST.tracks = tracks.map(build);
    nextId = Math.max(Number.isInteger(d.nextId) ? d.nextId : 1, ...tracks.map(t => t.id + 1));
    ST.curId = seen.has(d.curId) ? d.curId : tracks[0].id;
    master = num(d.master, MINDB, MAXDB, 0); NS.Audio.setMaster(master);
    general = M.limpiarGeneral(d.general); NS.Audio.setGeneral(general);       // Nibel: proyectos viejos sin efectos generales se abren sin efectos
    ST.name = typeof d.name === 'string' ? d.name.slice(0, 40) : '';
    ST.metro = !!d.metro;
    ST.setBpm(Number.isFinite(d.bpm) ? d.bpm : 120, true);
    NS.Teoria.importar(d.teoria);                            // tonalidad y escala del proyecto (opcionales)
    ST.roll.importState(d.roll || {});
    ST.listeners.forEach(f => f());
  };
})(window.NS = window.NS || {});
