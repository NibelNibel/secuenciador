/* Automatización de parámetros — datos y matemáticas (sin pantalla ni audio).
   Una pista puede tener una curva por parámetro:  pista.auto = { vol:{curva, pts:[{s, v}]}, pan:{…} }
     s = posición en unidades del Roll (1/32 de nota; una negra = 8) · v = valor (vol en dB, pan de −1 a 1)
     curva = cómo se pasa de un punto al siguiente: 'lineal' | 'suave' | 'escalon'
   Antes del primer punto vale el valor del primero; después del último, el del último.
   Para añadir otro parámetro (p. ej. un filtro) basta con registrarlo en PARAMS y darle una salida en audio.js. */
(function(NS){
  'use strict';
  const MAXU = 512 * 32;                  // mismo límite del Roll (512 compases)
  const MAXPTS = 256;                     // puntos por curva
  const CURVAS = {lineal:'Lineal', suave:'Suave', escalon:'Escalón'};
  const PARAMS = {
    vol:{nombre:'Volumen', corto:'Vol', min:-40, max:6, def:0, marcas:[6, 0, -12, -24, -40],
      fmt:v => (v <= -40 ? '−∞' : (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(Math.round(v * 10) / 10) + ' dB')},
    pan:{nombre:'Balance', corto:'Pan', min:-1, max:1, def:0, marcas:[1, 0, -1],
      fmt:v => (Math.abs(v) < 0.025 ? 'Centro' : Math.round(Math.abs(v) * 100) + (v < 0 ? ' I' : ' D'))}
  };
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));

  // Valida lo que venga de un proyecto guardado o importado. Devuelve undefined si no hay ninguna curva con puntos.
  function limpiar(raw){
    if(!raw || typeof raw !== 'object') return undefined;
    const out = {};
    for(const k of Object.keys(PARAMS)){
      const l = raw[k], P = PARAMS[k];
      if(!l || typeof l !== 'object' || !Array.isArray(l.pts)) continue;
      const por = new Map();
      for(const p of l.pts){
        if(!p || !Number.isFinite(p.s) || !Number.isFinite(p.v)) continue;
        const s = Math.round(p.s); if(s < 0 || s >= MAXU) continue;
        por.set(s, {s, v:lim(p.v, P.min, P.max)});             // dos puntos en la misma posición: gana el último
      }
      const pts = [...por.values()].sort((a, b) => a.s - b.s).slice(0, MAXPTS);
      if(pts.length) out[k] = {curva:CURVAS[l.curva] ? l.curva : 'lineal', pts};
    }
    return Object.keys(out).length ? out : undefined;
  }
  const copiar = a => (a ? JSON.parse(JSON.stringify(a)) : undefined);

  const suavizar = t => t * t * (3 - 2 * t);
  // Valor de la curva en la posición s (unidades, puede ser decimal). null si no hay curva.
  function valorEn(l, s){
    if(!l || !l.pts || !l.pts.length) return null;
    const p = l.pts, n = p.length;
    if(s <= p[0].s) return p[0].v;
    if(s >= p[n - 1].s) return p[n - 1].v;
    let lo = 0, hi = n - 1;
    while(hi - lo > 1){ const m = (lo + hi) >> 1; if(p[m].s <= s) lo = m; else hi = m; }
    const a = p[lo], b = p[hi];
    if(l.curva === 'escalon') return a.v;
    const t = (s - a.s) / (b.s - a.s);
    return a.v + (b.v - a.v) * (l.curva === 'suave' ? suavizar(t) : t);
  }
  const hay = (auto, k) => !!(auto && auto[k] && auto[k].pts.length);
  const alguna = auto => !!auto && (hay(auto, 'vol') || hay(auto, 'pan'));

  /* Para los renders sin conexión (WAV, vídeo): lista de eventos {t (segundos), v, salto}.
     salto = true → el valor cambia de golpe en t; si no, se llega a él con una rampa desde el evento anterior.
     spu = segundos por unidad. mapa (opcional) convierte los segundos de la canción a los del render (el primer evento siempre es t = 0).
     Se muestrea cada ~40 ms entre el primer y el último punto: así la rampa sigue la curva también en dB. */
  function muestras(l, spu, mapa){
    if(!l || !l.pts || !l.pts.length) return [];
    const f = mapa || (t => t), p = l.pts, out = [{t:0, v:p[0].v, salto:true}];
    for(let i = 1; i < p.length; i++){
      const a = p[i - 1], b = p[i], ta = a.s * spu, tb = b.s * spu;
      if(l.curva === 'escalon'){ out.push({t:f(tb), v:b.v, salto:true}); continue; }
      if(i === 1) out.push({t:f(ta), v:a.v, salto:true});
      const n = Math.max(1, Math.ceil((tb - ta) / 0.04));
      for(let k = 1; k <= n; k++) out.push({t:f(ta + (tb - ta) * k / n), v:valorEn(l, a.s + (b.s - a.s) * k / n), salto:false});
    }
    return out;
  }

  NS.Auto = {MAXU, MAXPTS, CURVAS, PARAMS, limpiar, copiar, valorEn, hay, alguna, muestras};
})(window.NS = window.NS || {});
