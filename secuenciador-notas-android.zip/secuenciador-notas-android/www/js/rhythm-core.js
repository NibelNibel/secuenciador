/* Ritmos: datos, exportación (MIDI y WAV) y entrega del archivo al móvil.
   Un ritmo = lista de eventos {t, d} en milisegundos, uno por nota de la melodía:
   t = momento en que se toca la nota (desde el inicio), d = cuánto dura (lo que se mantuvo el dedo). */
(function(NS){
  const uid = () => 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // Sanea un ritmo venido de localStorage
  function clean(r){
    if(!r || typeof r !== 'object' || !Array.isArray(r.events) || !r.events.length) return null;
    const events = r.events.filter(e => e && Number.isFinite(e.t) && Number.isFinite(e.d) && e.t >= 0 && e.d > 0)
      .map(e => ({t:Math.round(e.t), d:Math.round(e.d)}));
    if(events.length !== r.events.length) return null;
    return {id:typeof r.id === 'string' && r.id ? r.id : uid(), name:typeof r.name === 'string' && r.name ? r.name.slice(0, 40) : 'Ritmo',
      events, created:Number.isFinite(r.created) ? r.created : Date.now()};
  }
  const normalize = arr => Array.isArray(arr) ? arr.map(clean).filter(Boolean) : [];
  const create = (name, events) => ({id:uid(), name, events, created:Date.now()});
  const totalMs = ev => ev.length ? ev[ev.length - 1].t + ev[ev.length - 1].d : 0;
  const fits = (m, r) => r.events.length === m.notes.length;           // ¿el ritmo tiene una duración por cada nota?
  const favorite = m => {                                              // ritmo elegido (si sigue encajando)
    const r = (m.rhythms || []).find(x => x.id === m.favRhythm);
    return r && fits(m, r) ? r : null;
  };

  /* ---------- MIDI (formato 0). PPQ 500 + 500000 µs/negra → 1 tick = 1 ms ---------- */
  const vlq = n => { const b = [n & 127]; while((n >>= 7) > 0) b.unshift((n & 127) | 128); return b; };
  function toMidi(notes, events, title){
    const trk = [], enc = new TextEncoder();
    const meta = (type, data) => trk.push(0, 0xFF, type, ...vlq(data.length), ...data);
    meta(0x03, [...enc.encode(String(title || 'Ritmo').slice(0, 60))]);
    meta(0x51, [0x07, 0xA1, 0x20]);          // 500000 µs por negra
    meta(0x58, [4, 2, 24, 8]);
    const ev = [];
    events.forEach((e, i) => { ev.push({at:e.t, on:1, n:notes[i]}); ev.push({at:e.t + e.d, on:0, n:notes[i]}); });
    ev.sort((a, b) => a.at - b.at || a.on - b.on); // al coincidir, primero se apaga
    let last = 0;
    ev.forEach(x => { trk.push(...vlq(x.at - last), x.on ? 0x90 : 0x80, x.n, x.on ? 96 : 0); last = x.at; });
    trk.push(0, 0xFF, 0x2F, 0);
    const n = trk.length;
    return Uint8Array.from([0x4D,0x54,0x68,0x64, 0,0,0,6, 0,0, 0,1, 500 >> 8, 500 & 255,
      0x4D,0x54,0x72,0x6B, (n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255, ...trk]);
  }

  /* ---------- WAV (mono 16 bit): síntesis aditiva sencilla tipo piano ---------- */
  function toWav(notes, events){
    const SR = 44100, REL = 0.35, H = [1, .5, .28, .14, .07];
    const len = Math.ceil((totalMs(events) / 1000 + REL + .3) * SR), buf = new Float32Array(len);
    events.forEach((e, i) => {
      const f = 440 * Math.pow(2, (notes[i] - 69) / 12), s0 = Math.floor(e.t / 1000 * SR), dur = e.d / 1000;
      const n = Math.min(Math.floor((dur + REL) * SR), len - s0);
      for(let k = 0; k < n; k++){
        const t = k / SR; let env = Math.min(1, t / .004);
        if(t > dur) env *= Math.max(0, 1 - (t - dur) / REL);
        let v = 0;
        for(let h = 0; h < H.length; h++){
          if(f * (h + 1) >= SR / 2) break;
          v += H[h] * Math.exp(-t * (1.1 + h * 1.6)) * Math.sin(2 * Math.PI * f * (h + 1) * t);
        }
        buf[s0 + k] += v * env;
      }
    });
    let peak = 0; for(let i = 0; i < len; i++) peak = Math.max(peak, Math.abs(buf[i]));
    const g = peak ? 0.85 / peak : 1, out = new Uint8Array(44 + len * 2), dv = new DataView(out.buffer);
    const str = (o, s) => { for(let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); dv.setUint32(4, 36 + len * 2, true); str(8, 'WAVE'); str(12, 'fmt '); dv.setUint32(16, 16, true);
    dv.setUint16(20, 1, true); dv.setUint16(22, 1, true); dv.setUint32(24, SR, true); dv.setUint32(28, SR * 2, true);
    dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); str(36, 'data'); dv.setUint32(40, len * 2, true);
    for(let i = 0; i < len; i++) dv.setInt16(44 + i * 2, Math.max(-1, Math.min(1, buf[i] * g)) * 32767, true);
    return out;
  }

  const safeName = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w\- .]+/g, '_').trim().slice(0, 60) || 'ritmo';

  // Construye el archivo {name, mime, bytes} de un ritmo de una melodía. kind: 'mid' | 'wav'
  function makeFile(m, r, kind){
    const base = safeName(m.name + ' - ' + r.name);
    return kind === 'wav'
      ? {name:base + '.wav', mime:'audio/wav', bytes:toWav(m.notes, r.events)}
      : {name:base + '.mid', mime:'audio/midi', bytes:toMidi(m.notes, r.events, m.name + ' - ' + r.name)};
  }

  /* ---------- Entrega ----------
     En la app Android (Capacitor) un <a download> no funciona: se escribe el archivo en la caché y se abre el
     menú «Compartir» de Android (ahí eliges Guardar en el dispositivo, Drive, WhatsApp…). En navegador, descarga normal. */
  function b64(u8){ let s = ''; for(let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
  async function deliver(file){
    const cap = window.Capacitor, P = (cap && cap.Plugins) || {};
    const native = !!(cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform());
    if(native){
      if(!P.Filesystem || !P.Share) return {ok:false, msg:'Faltan los plugins de archivos. Recompila el APK (npm install + cap sync).'};
      try{
        let w;
        if(file.blob){                                  // archivo grande (vídeo): se escribe por trozos para no llenar la memoria
          const TROZO = 3 * 1024 * 1024;                // múltiplo de 3: cada trozo en base64 es independiente
          for(let pos = 0; pos < file.blob.size; pos += TROZO){
            const data = b64(new Uint8Array(await file.blob.slice(pos, pos + TROZO).arrayBuffer()));
            if(pos === 0) w = await P.Filesystem.writeFile({path:file.name, data, directory:'CACHE'});
            else await P.Filesystem.appendFile({path:file.name, data, directory:'CACHE'});
          }
        }else w = await P.Filesystem.writeFile({path:file.name, data:b64(file.bytes), directory:'CACHE'});
        await P.Share.share({title:file.name, files:[w.uri], dialogTitle:'Guardar o compartir ' + file.name});
        return {ok:true};
      }catch(e){
        if(/cancel/i.test(String(e && (e.message || e)))) return {ok:true, canceled:true};
        return {ok:false, msg:'No se pudo guardar: ' + (e && e.message || e)};
      }
    }
    try{
      const url = URL.createObjectURL(file.blob || new Blob([file.bytes], {type:file.mime})), a = document.createElement('a');
      a.href = url; a.download = file.name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      return {ok:true};
    }catch(e){ return {ok:false, msg:'No se pudo descargar: ' + (e && e.message || e)}; }
  }

  NS.RhythmCore = {normalize, create, totalMs, fits, favorite, toMidi, toWav, makeFile, deliver};
})(window.NS = window.NS || {});
