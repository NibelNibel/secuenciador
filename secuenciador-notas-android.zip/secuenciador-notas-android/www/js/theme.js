/* Sistema de temas: registro de estéticas, persistencia, selector «Apariencia» y paleta para los lienzos (canvas).
   · Los valores visuales viven en css/themes.css (variables CSS por tema). Aquí solo hay metadatos y lógica.
   · El tema activo es <html data-theme="id">. Se guarda con NS.Storage en la clave propia «tema» (y «temaFx» para los efectos),
     nunca se toca ningún dato de proyectos, melodías, ritmos o estudio.
   · Para añadir un tema: bloque [data-theme="id"] en themes.css + una línea en THEMES. */
(function(NS){
  'use strict';
  const $ = id => document.getElementById(id);
  const DEFAULT = 'studio';
  const THEMES = [
    {id:'sci-fi',     name:'Futurista · Sci-Fi',     sub:'Cian y azul eléctrico'},
    {id:'kawaii',     name:'Kawaii · Pastel',        sub:'Rosa, lila y celeste'},
    {id:'minimal',    name:'Minimalismo premium',    sub:'Crema, tinta y dorado'},
    {id:'arcade',     name:'Retro arcade · 8 bits',  sub:'Neón sobre negro'},
    {id:'glass',      name:'Glassmorphism',          sub:'Cristal y desenfoque'},
    {id:'studio',     name:'Estudio musical',        sub:'Verde y naranja de mesa de audio'},
    {id:'editorial',  name:'Editorial · Revista',    sub:'Serif, crema y rojo'},
    {id:'brutal',     name:'Neobrutalismo',          sub:'Bordes gruesos, sombras duras'},
    {id:'gothic',     name:'Dark fantasy · Gótico',  sub:'Violeta, carmesí y oro'},
    {id:'terminal',   name:'Terminal · Hacker',      sub:'Verde fósforo monoespaciado'},
    {id:'y2k',        name:'Y2K · Cyberpop',         sub:'Plata, rosa y azul eléctrico'},
    {id:'organic',    name:'Organic UI · Natural',   sub:'Crema, verdes y marrones'},
    {id:'swiss',      name:'Swiss · Internacional',  sub:'Retícula, negro y rojo'},
    {id:'aurora',     name:'Aurora · Ambient',       sub:'Luces violeta y turquesa'},
    {id:'industrial', name:'Industrial · Hardware',  sub:'Perillas, LEDs y metal'}
  ];
  const IDS = THEMES.map(t => t.id);
  const root = document.documentElement;
  const listeners = [];
  const reduceMotion = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  let current = DEFAULT, fx = true, pal = null;

  /* ---------- Paleta de los lienzos (se lee de las variables CSS del tema activo) ---------- */
  const probe = document.createElement('canvas').getContext('2d');
  const parse = c => {                       // cualquier color CSS -> [r, g, b, a]
    probe.fillStyle = '#000'; probe.fillStyle = String(c || '#000');
    const v = probe.fillStyle;
    if(v[0] === '#') return [parseInt(v.slice(1, 3), 16), parseInt(v.slice(3, 5), 16), parseInt(v.slice(5, 7), 16), 1];
    const m = v.match(/[\d.]+/g) || [0, 0, 0]; return [+m[0], +m[1], +m[2], m[3] === undefined ? 1 : +m[3]];
  };
  const mix = (a, b, t) => [0, 1, 2].map(i => Math.round(a[i] + (b[i] - a[i]) * t));
  const rgba = (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
  const hex = c => '#' + c.slice(0, 3).map(n => Math.max(0, Math.min(255, n)).toString(16).padStart(2, '0')).join('');
  const lum = c => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  const WHITE = [255, 255, 255], BLACK = [0, 0, 0];

  // Colores originales de la app (tema «studio» anterior). La exportación a vídeo siempre los usa: el vídeo no depende del tema.
  const CLASICA = {
    fila:'#1e222b', filaNegra:'#161920', filaSonando:'#2c2a22', lineaOctava:'#343a4a', teclaBlanca:'#e8eaf0', teclaNegra:'#262a33', teclaSonando:'#ffb454',
    textoBlanca:'#555b6b', textoNegra:'#ffffff', textoSonando:'#1a1200', cuadriculaCompas:'#6b7690', cuadriculaTiempo:'#444c61', cuadriculaFina:'#2a2f3b', numeroCompas:'#8b93a7',
    notaElegida:'#ffd54f', notaElegidaBorde:'#fff', notaTexto:'rgba(10,12,16,.75)', notaAsa:'rgba(0,0,0,.35)', lazoRelleno:'rgba(255,180,84,.16)', lazoBorde:'#ffb454',
    etiquetaFondo:'rgba(20,22,28,.78)', etiquetaTexto:'#e8eaf0', cursor:'#ff6b6b', minimapaFondo:'#161920', minimapaRayas:'#2a2f3b', vistaRelleno:'rgba(255,180,84,.18)', vistaBorde:'#ffb454',
    escenaArriba:'#080a14', escenaAbajo:'#171b33', carrilNegro:'rgba(0,0,0,0.22)', lineaDo:'rgba(255,255,255,0.10)', lineaTecla:'rgba(255,255,255,0.028)',
    compas0:'rgba(255,255,255,0.20)', compas:'rgba(255,255,255,0.06)', compasTexto:'rgba(255,255,255,0.42)',
    blancaArriba:'#fbfbfd', blancaAbajo:'#c4c6d0', negraArriba:'#3a3d4a', negraAbajo:'#0a0b10', negraBrillo:'rgba(255,255,255,0.09)', teclaRotulo:'#6c7084',
    impactoBorde:'rgba(255,255,255,0.15)', impactoCentro:'rgba(255,255,255,0.8)', titulo:'rgba(255,255,255,0.35)'
  };

  function buildPalette(){
    const cs = getComputedStyle(root), v = n => cs.getPropertyValue(n).trim();
    const c = n => parse(v(n));
    const text = c('--text'), accent = c('--accent'), onAccent = c('--on-accent'), danger = c('--danger'), muted = c('--muted');
    const rb = c('--roll-bg'), kw = c('--key-w1'), kb = c('--key-b1'), ktx = c('--key-text'), kbt = c('--key-btext'), panel = c('--panel');
    const dark = lum(rb) < 0.45;
    const fila = dark ? mix(rb, WHITE, 0.045) : rb, filaNegra = mix(rb, BLACK, dark ? 0.1 : 0.07);
    const gFina = mix(fila, text, 0.1), gTiempo = mix(fila, text, 0.22), gCompas = mix(fila, text, 0.45);
    const sTop = c('--scene-top'), sBot = c('--scene-bot'), sdark = lum(mix(sTop, sBot, 0.5)) < 0.45;
    const sc = sdark ? WHITE : [20, 20, 30], sa = sdark ? 1 : 1.6;
    return {
      fila:hex(fila), filaNegra:hex(filaNegra), filaSonando:hex(mix(fila, accent, 0.22)), lineaOctava:hex(mix(fila, text, 0.16)),
      teclaBlanca:hex(kw), teclaNegra:hex(kb), teclaSonando:hex(accent), textoBlanca:hex(ktx), textoNegra:hex(kbt), textoSonando:hex(onAccent),
      cuadriculaCompas:hex(gCompas), cuadriculaTiempo:hex(gTiempo), cuadriculaFina:hex(gFina), numeroCompas:hex(muted),
      notaElegida:hex(mix(accent, WHITE, 0.35)), notaElegidaBorde:dark ? '#fff' : '#111', notaTexto:'rgba(10,12,16,.78)', notaAsa:'rgba(0,0,0,.35)',
      escalaFila:rgba(accent, dark ? 0.11 : 0.14), escalaRaiz:rgba(accent, dark ? 0.26 : 0.32), escalaPunto:hex(accent),
      lazoRelleno:rgba(accent, 0.16), lazoBorde:hex(accent), etiquetaFondo:rgba(panel, 0.82), etiquetaTexto:hex(text), cursor:hex(danger),
      minimapaFondo:hex(rb), minimapaRayas:hex(gFina), vistaRelleno:rgba(accent, 0.18), vistaBorde:hex(accent),
      escenaArriba:hex(sTop), escenaAbajo:hex(sBot), carrilNegro:sdark ? 'rgba(0,0,0,0.22)' : 'rgba(0,0,0,0.05)',
      lineaDo:rgba(sc, 0.10 * sa), lineaTecla:rgba(sc, 0.028 * sa), compas0:rgba(sc, 0.20 * sa), compas:rgba(sc, 0.06 * sa), compasTexto:rgba(sc, 0.42 * Math.min(sa, 1.4)),
      blancaArriba:hex(kw), blancaAbajo:hex(c('--key-w2')), negraArriba:hex(kb), negraAbajo:hex(c('--key-b2')), negraBrillo:'rgba(255,255,255,0.09)', teclaRotulo:hex(ktx),
      impactoBorde:rgba(sdark ? WHITE : accent, 0.15), impactoCentro:rgba(sdark ? WHITE : accent, 0.8), titulo:rgba(sc, 0.35)
    };
  }
  const palette = () => pal || (pal = buildPalette());

  /* ---------- Aplicar y guardar ---------- */
  function paintMeta(){
    const m = document.querySelector('meta[name="theme-color"]');
    if(m){ const bg = getComputedStyle(root).getPropertyValue('--bg').trim(); if(bg) m.setAttribute('content', hex(parse(bg))); }
  }
  function apply(id, animate){
    if(!IDS.includes(id)) id = DEFAULT;
    const changed = id !== current || root.getAttribute('data-theme') !== id;
    current = id;
    if(animate && changed && !reduceMotion()){
      root.classList.add('theme-anim'); clearTimeout(apply.t); apply.t = setTimeout(() => root.classList.remove('theme-anim'), 450);
    }
    root.setAttribute('data-theme', id);
    pal = null; paintMeta();
    if(changed) listeners.slice().forEach(fn => { try{ fn(id); }catch(e){} });
    markActive();
    return id;
  }
  function set(id){ if(!IDS.includes(id)) return false; apply(id, true); NS.Storage.set('tema', id); return true; }
  function setFx(on){
    fx = !!on; if(fx) root.removeAttribute('data-fx'); else root.setAttribute('data-fx', 'off');
    NS.Storage.set('temaFx', fx); const b = $('thFx'); if(b) b.checked = fx;
  }

  /* ---------- Selector «Apariencia» ---------- */
  let built = false, lastFocus = null;
  const mk = (tag, cls, txt) => { const e = document.createElement(tag); if(cls) e.className = cls; if(txt !== undefined) e.textContent = txt; return e; };
  function build(){
    const grid = $('thGrid'); grid.textContent = '';
    THEMES.forEach(t => {
      const card = mk('button', 'thCard'); card.type = 'button'; card.dataset.id = t.id;
      card.setAttribute('role', 'radio'); card.setAttribute('aria-checked', 'false'); card.setAttribute('aria-label', t.name + '. ' + t.sub);
      const prev = mk('span', 'thPrev'); prev.setAttribute('data-theme', t.id); prev.setAttribute('aria-hidden', 'true');
      const top = mk('span', 'thTop');
      ['--accent', '--accent2', '--accent3'].forEach(v => { const d = mk('i', 'thDot'); d.style.background = 'var(' + v + ')'; top.appendChild(d); });
      top.appendChild(mk('span', 'thAa', 'Aa'));
      const pan = mk('span', 'thPan'); pan.appendChild(mk('i', 'thBtn')); pan.appendChild(mk('i', 'thLine'));
      prev.append(top, pan);
      card.append(prev, mk('span', 'thName', t.name), mk('span', 'thSub', t.sub), mk('span', 'thCheck', '✓'));
      card.addEventListener('click', () => { if(set(t.id)) $('thCur').textContent = 'Activa: ' + t.name; });
      grid.appendChild(card);
    });
    $('thFx').checked = fx;
    built = true;
  }
  function markActive(){
    if(!built) return;
    [...$('thGrid').children].forEach(c => c.setAttribute('aria-checked', String(c.dataset.id === current)));
    const t = THEMES.find(x => x.id === current); $('thCur').textContent = 'Activa: ' + (t ? t.name : '');
  }
  function open(){
    const sh = $('themeSheet'); if(!sh) return;
    if(!built) build();
    lastFocus = document.activeElement; markActive(); sh.hidden = false;
    const act = [...$('thGrid').children].find(c => c.dataset.id === current);
    if(act) setTimeout(() => act.scrollIntoView({block:'nearest'}), 30);
    setTimeout(() => { try{ $('thClose').focus({preventScroll:true}); }catch(e){} }, 40);
  }
  function close(){ const sh = $('themeSheet'); if(!sh || sh.hidden) return; sh.hidden = true; try{ if(lastFocus) lastFocus.focus({preventScroll:true}); }catch(e){} }

  /* ---------- Arranque ---------- */
  const saved = NS.Storage.get('tema', DEFAULT);
  fx = NS.Storage.get('temaFx', true) !== false;
  if(!fx) root.setAttribute('data-fx', 'off');
  apply(typeof saved === 'string' && IDS.includes(saved) ? saved : DEFAULT, false);

  const btn = $('themeBtn'); if(btn) btn.addEventListener('click', open);
  const closeBtn = $('thClose'); if(closeBtn) closeBtn.addEventListener('click', close);
  const sheet = $('themeSheet'); if(sheet) sheet.addEventListener('click', e => { if(e.target === sheet) close(); });
  const fxBox = $('thFx'); if(fxBox) fxBox.addEventListener('change', () => setFx(fxBox.checked));
  document.addEventListener('keydown', e => { if(e.key === 'Escape') close(); });

  NS.Theme = {
    list:() => THEMES.map(t => Object.assign({}, t)),
    current:() => current,
    set, setFx, open, close,
    onChange(fn){ if(typeof fn === 'function') listeners.push(fn); },
    palette,                       // colores de los lienzos según el tema activo
    clasica:() => CLASICA          // colores originales (la exportación a vídeo no depende del tema)
  };
})(window.NS = window.NS || {});
