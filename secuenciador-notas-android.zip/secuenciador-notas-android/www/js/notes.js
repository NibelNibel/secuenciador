/* Utilidades de notas. Internamente cada nota es un número MIDI (C4 = 60). */
(function(NS){
  const SHARP = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
  const FLAT  = ['C','D♭','D','E♭','E','F','G♭','G','A♭','A','B♭','B'];
  const BASE  = {C:0,D:2,E:4,F:5,G:7,A:9,B:11};
  const MIN = 12, MAX = 119; // C0 .. B8

  // "C♯5", "C#5", "Db4", "bb3" → midi (o null si no es válida)
  function parse(tok){
    const m = /^([A-Ga-g])([#♯]|[b♭])?(\d)$/.exec(tok.trim());
    if(!m) return null;
    const acc = m[2] ? ((m[2] === '#' || m[2] === '♯') ? 1 : -1) : 0;
    const midi = (+m[3] + 1) * 12 + BASE[m[1].toUpperCase()] + acc;
    return (midi >= MIN && midi <= MAX) ? midi : null;
  }
  // acc: '#' (sostenidos) o 'b' (bemoles)
  function name(midi, acc){ return (acc === 'b' ? FLAT : SHARP)[midi % 12] + (Math.floor(midi / 12) - 1); }
  function tone(midi){ return SHARP[midi % 12].replace('♯','#') + (Math.floor(midi / 12) - 1); }
  function parseSeq(text){
    const notes = [], bad = [];
    text.split(/[\s,;|]+/).forEach(t => { if(!t) return; const m = parse(t); if(m === null) bad.push(t); else notes.push(m); });
    return {notes, bad};
  }
  const format = (list, acc) => list.map(m => name(m, acc)).join(' ');

  NS.Notes = {MIN, MAX, parse, name, tone, parseSeq, format};
})(window.NS = window.NS || {});
