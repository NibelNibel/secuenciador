/* Estudio — formatos extra de exportación: partitura (MusicXML), tabla de notas (CSV) y proyecto (JSON).
   También abre un proyecto guardado en JSON. Los archivos se entregan con NS.RhythmCore.deliver
   (en el APK abre «Compartir» de Android; en el navegador se descarga directo). */
(function(NS){
  'use strict';
  const ST = NS.Studio, RC = NS.RhythmCore, $ = id => document.getElementById(id);

  const UNIDADES_POR_NEGRA = 8;                         // Nibel: una negra mide 8 unidades (cada unidad es 1/32 de nota)
  const UNIDADES_POR_COMPAS = 32;                       // Nibel: compas de 4 tiempos
  const DURACIONES_VALIDAS = [32, 24, 16, 12, 8, 6, 4, 3, 2, 1]; // Nibel: duraciones que una partitura sabe escribir
  const TIPOS_NOTA = {32:['whole', 0], 24:['half', 1], 16:['half', 0], 12:['quarter', 1], 8:['quarter', 0],
    6:['eighth', 1], 4:['eighth', 0], 3:['16th', 1], 2:['16th', 0], 1:['32nd', 0]};
  const LETRAS = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
  const ES_SOSTENIDA = [0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0];

  const escapar = t => String(t).replace(/[&<>"]/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;'}[c]));
  const nombreBase = () => String(ST.name || 'Estudio').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w\- .]+/g, '_').trim().slice(0, 40) || 'Estudio';
  const todasLasNotas = () => ST.roll.exportState().notes.filter(n => ST.trackById(n.t));
  const mensaje = t => { $('stExportMsg').textContent = t || ''; };
  const codificar = t => new TextEncoder().encode(t);

  async function enviar(archivo){
    const r = await RC.deliver(archivo);
    if(!r.ok) mensaje(r.msg || 'No se pudo entregar el archivo');
    else if(!r.canceled) mensaje('Listo: ' + archivo.name);
  }

  /* ---------- Partitura (MusicXML): se abre en MuseScore, Finale, Sibelius, Flat, etc. ---------- */
  // Nibel: parte una duracion en pedazos que se pueden escribir como nota (ej. 5 = 4 + 1)
  function partirDuracion(largo){
    const partes = [];
    for(const d of DURACIONES_VALIDAS) while(largo >= d){ partes.push(d); largo -= d; }
    return partes;
  }
  // Nibel: reparte las notas de una pista en voces; dentro de una voz nunca se pisan dos eventos
  function armarVoces(notas){
    const grupos = new Map();
    for(const n of notas){
      const clave = n.s + '|' + n.d;
      if(!grupos.has(clave)) grupos.set(clave, {s:n.s, d:n.d, alturas:new Set()});
      grupos.get(clave).alturas.add(n.p);
    }
    const eventos = [...grupos.values()].sort((a, b) => a.s - b.s || b.d - a.d);
    const voces = [];
    for(const e of eventos){
      let voz = voces.find(v => v.fin <= e.s);
      if(!voz){ voz = {fin:0, eventos:[]}; voces.push(voz); }
      voz.eventos.push(e); voz.fin = e.s + e.d;
    }
    return voces;
  }
  // Nibel: convierte los eventos de una voz en piezas (notas y silencios) que no cruzan la linea de compas
  function piezasDeVoz(voz, totalCompases){
    const piezas = [], limite = totalCompases * UNIDADES_POR_COMPAS;
    const agregar = (desde, hasta, alturas) => {
      let pos = desde;
      const pedazos = [];
      while(pos < hasta){
        const finCompas = (Math.floor(pos / UNIDADES_POR_COMPAS) + 1) * UNIDADES_POR_COMPAS;
        const tramo = Math.min(hasta, finCompas) - pos;
        for(const d of partirDuracion(tramo)){ pedazos.push({s:pos, d}); pos += d; }
      }
      pedazos.forEach((pz, i) => piezas.push({s:pz.s, d:pz.d, alturas,
        ligaInicio:!!alturas && i < pedazos.length - 1, ligaFin:!!alturas && i > 0}));
    };
    let cursor = 0;
    for(const e of voz.eventos){
      if(e.s > cursor) agregar(cursor, e.s, null);
      agregar(e.s, e.s + e.d, [...e.alturas].sort((a, b) => a - b));
      cursor = e.s + e.d;
    }
    if(cursor < limite) agregar(cursor, limite, null);
    return piezas;
  }
  function xmlPieza(pz, numeroVoz){
    const [tipo, puntos] = TIPOS_NOTA[pz.d];
    const comun = '<duration>' + pz.d + '</duration>';
    const cola = '<voice>' + numeroVoz + '</voice><type>' + tipo + '</type>' + (puntos ? '<dot/>' : '');
    if(!pz.alturas) return '<note' + (numeroVoz > 1 ? ' print-object="no"' : '') + '><rest/>' + comun + cola + '</note>';
    return pz.alturas.map((p, i) => {
      const alteracion = ES_SOSTENIDA[p % 12];
      const ligas = (pz.ligaFin ? '<tie type="stop"/>' : '') + (pz.ligaInicio ? '<tie type="start"/>' : '');
      const marcas = (pz.ligaFin ? '<tied type="stop"/>' : '') + (pz.ligaInicio ? '<tied type="start"/>' : '');
      return '<note>' + (i ? '<chord/>' : '') + '<pitch><step>' + LETRAS[p % 12] + '</step>' + (alteracion ? '<alter>1</alter>' : '') +
        '<octave>' + (Math.floor(p / 12) - 1) + '</octave></pitch>' + comun + ligas + cola + (marcas ? '<notations>' + marcas + '</notations>' : '') + '</note>';
    }).join('');
  }
  function construirMusicXml(notas){
    const fin = Math.max(...notas.map(n => n.s + n.d));
    const totalCompases = Math.max(1, Math.ceil(fin / UNIDADES_POR_COMPAS));
    const pistas = ST.tracks.filter(t => notas.some(n => n.t === t.id));
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">\n' +
      '<score-partwise version="4.0"><work><work-title>' + escapar(ST.name || 'Estudio') + '</work-title></work>' +
      '<identification><encoding><software>Secuenciador de notas</software></encoding></identification><part-list>';
    pistas.forEach((t, i) => {
      xml += '<score-part id="P' + (i + 1) + '"><part-name>' + escapar(t.name) + '</part-name>' +
        '<score-instrument id="P' + (i + 1) + '-I1"><instrument-name>' + escapar(ST.instName(t.inst)) + '</instrument-name></score-instrument>' +
        '<midi-instrument id="P' + (i + 1) + '-I1"><midi-channel>' + (i % 15 + (i % 15 >= 9 ? 2 : 1)) + '</midi-channel><midi-program>' + (NS.Audio.program(t.inst) + 1) + '</midi-program></midi-instrument></score-part>';
    });
    xml += '</part-list>';
    pistas.forEach((t, i) => {
      const mias = notas.filter(n => n.t === t.id);
      const promedio = mias.reduce((a, n) => a + n.p, 0) / mias.length;
      const clave = promedio < 55 ? '<sign>F</sign><line>4</line>' : '<sign>G</sign><line>2</line>'; // Nibel: notas graves van en clave de fa
      const voces = armarVoces(mias).map(v => piezasDeVoz(v, totalCompases));
      xml += '<part id="P' + (i + 1) + '">';
      for(let c = 0; c < totalCompases; c++){
        const desde = c * UNIDADES_POR_COMPAS, hasta = desde + UNIDADES_POR_COMPAS;
        xml += '<measure number="' + (c + 1) + '">';
        if(c === 0){
          xml += '<attributes><divisions>' + UNIDADES_POR_NEGRA + '</divisions><key><fifths>0</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><clef>' + clave + '</clef></attributes>';
          if(i === 0) xml += '<direction placement="above"><direction-type><metronome><beat-unit>quarter</beat-unit><per-minute>' + ST.bpm + '</per-minute></metronome></direction-type><sound tempo="' + ST.bpm + '"/></direction>';
        }
        let escritas = 0;
        voces.forEach((piezas, v) => {
          const delCompas = piezas.filter(pz => pz.s >= desde && pz.s < hasta);
          if(v > 0 && !delCompas.some(pz => pz.alturas)) return; // Nibel: una voz extra sin notas en este compas no se escribe
          if(escritas) xml += '<backup><duration>' + UNIDADES_POR_COMPAS + '</duration></backup>';
          xml += delCompas.map(pz => xmlPieza(pz, v + 1)).join('');
          escritas++;
        });
        if(c === totalCompases - 1) xml += '<barline location="right"><bar-style>light-heavy</bar-style></barline>';
        xml += '</measure>';
      }
      xml += '</part>';
    });
    return xml + '</score-partwise>\n';
  }
  async function exportarPartitura(){
    const notas = todasLasNotas();
    if(!notas.length){ mensaje('No hay notas que exportar.'); return; }
    try{
      await enviar({name:nombreBase() + '.musicxml', mime:'application/vnd.recordare.musicxml+xml', bytes:codificar(construirMusicXml(notas))});
    }catch(e){ mensaje('No se pudo crear la partitura.'); console.error(e); }
  }

  /* ---------- Tabla de notas (CSV): se abre en Excel, Hojas de cálculo de Google, etc. ---------- */
  function construirCsv(notas){
    const segundosPorUnidad = 60 / ST.bpm / UNIDADES_POR_NEGRA, redondear = v => Math.round(v * 1000) / 1000;
    const filas = [['pista', 'instrumento', 'nota', 'midi', 'compas', 'tiempo_en_compas', 'duracion_en_tiempos', 'inicio_seg', 'duracion_seg']];
    const ordenadas = notas.slice().sort((a, b) => a.s - b.s || a.p - b.p);
    for(const n of ordenadas){
      const t = ST.trackById(n.t);
      filas.push([t.name, ST.instName(t.inst), NS.Notes.name(n.p, '#').replace('♯', '#'), n.p,
        Math.floor(n.s / UNIDADES_POR_COMPAS) + 1, redondear((n.s % UNIDADES_POR_COMPAS) / UNIDADES_POR_NEGRA + 1),
        redondear(n.d / UNIDADES_POR_NEGRA), redondear(n.s * segundosPorUnidad), redondear(n.d * segundosPorUnidad)]);
    }
    const celda = v => { const t = String(v); return /[",\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; };
    return '\ufeff' + filas.map(f => f.map(celda).join(',')).join('\r\n') + '\r\n'; // Nibel: la marca del inicio hace que Excel lea bien las tildes
  }
  async function exportarCsv(){
    const notas = todasLasNotas();
    if(!notas.length){ mensaje('No hay notas que exportar.'); return; }
    await enviar({name:nombreBase() + '.csv', mime:'text/csv', bytes:codificar(construirCsv(notas))});
  }

  /* ---------- Proyecto completo (JSON): sirve de copia de seguridad y se puede volver a abrir ---------- */
  async function exportarProyecto(){
    ST.saveNow();
    const datos = Object.assign({formato:'secuenciador-notas-estudio'}, ST.exportState());
    await enviar({name:nombreBase() + '.json', mime:'application/json', bytes:codificar(JSON.stringify(datos))});
  }
  async function abrirProyecto(archivo){
    if(!archivo) return;
    let datos;
    try{ datos = JSON.parse(await archivo.text()); }
    catch(e){ mensaje('Ese archivo no es un proyecto válido.'); return; }
    if(!datos || !Array.isArray(datos.tracks) || !datos.roll || !Array.isArray(datos.roll.notes)){ mensaje('Ese archivo no es un proyecto del Estudio.'); return; }
    ST.proyectos.agregar(datos, datos.name || archivo.name.replace(/\.json$/i, ''));   // se añade a la lista; los demás proyectos no se tocan
    mensaje('');
  }

  $('stPartitura').addEventListener('click', exportarPartitura);
  $('stCsv').addEventListener('click', exportarCsv);
  $('stJson').addEventListener('click', exportarProyecto);
  $('stAbrir').addEventListener('click', () => $('stArchivoProyecto').click());
  $('stArchivoProyecto').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; abrirProyecto(f); });
  ST.exportarPartitura = exportarPartitura; ST.exportarCsv = exportarCsv; ST.exportarProyecto = exportarProyecto;
  ST.formatos = {construirMusicXml, construirCsv};
})(window.NS = window.NS || {});
