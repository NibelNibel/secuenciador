/* Estado central: borrador actual (se guarda solo) + lista de melodías. */
(function(NS){
  const valid = n => Number.isInteger(n) && n >= NS.Notes.MIN && n <= NS.Notes.MAX;
  const DEF = {notes:[], name:'', editingId:null, recording:false, acc:'#', lowOct:3, inst:'piano', bpm:120, kbHidden:false, tab:'piano'};
  const data = Object.assign({}, DEF, NS.Storage.get('draft', {}));
  data.notes = Array.isArray(data.notes) ? data.notes.filter(valid) : [];
  let saved = NS.Storage.get('melodies', []);
  const melodies = Array.isArray(saved) ? saved.filter(m => m && Array.isArray(m.notes)) : [];
  const subs = [];
  const emit = (keys, src) => subs.forEach(f => f(keys, src));

  NS.State = {
    data,
    melodies,
    on(f){ subs.push(f); },
    set(patch, src){ Object.assign(data, patch); NS.Storage.set('draft', data); emit(Object.keys(patch), src); },
    saveMelody(m){
      const now = Date.now();
      let e = m.id && melodies.find(x => x.id === m.id);
      if(e){ Object.assign(e, {name:m.name, notes:m.notes, updated:now}); }
      else{
        e = {id:'m' + now.toString(36) + Math.random().toString(36).slice(2,6), name:m.name, notes:m.notes, created:now, updated:now};
        melodies.unshift(e);
      }
      NS.Storage.set('melodies', melodies); emit(['melodies']); return e;
    },
    removeMelody(id){
      const i = melodies.findIndex(x => x.id === id); if(i < 0) return;
      melodies.splice(i, 1); NS.Storage.set('melodies', melodies);
      if(data.editingId === id) this.set({editingId:null});
      emit(['melodies']);
    }
  };
})(window.NS = window.NS || {});
