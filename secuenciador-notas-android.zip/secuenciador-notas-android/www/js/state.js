/* Estado central: borrador actual (se guarda solo) + lista de melodías.
   La melodía se organiza en secciones → frases → notas (ver song.js). */
(function(NS){
  const DEF = {sections:null, sec:0, phr:0, name:'', editingId:null, recording:false, acc:'#', lowOct:3, inst:'piano', bpm:120, view:'both', tab:'home', rhMel:null};
  const stored = NS.Storage.get('draft', {});
  const data = Object.assign({}, DEF, stored);
  data.sections = NS.Song.normalize(data.sections, stored.notes); // `notes` = formato antiguo (sin secciones)
  delete data.notes;
  data.tab = 'home';   // Sonavia siempre arranca en el menú principal (los modos no se restauran)
  if(!['both','edit','keys'].includes(data.view)) data.view = stored.kbHidden ? 'edit' : 'both'; // kbHidden = formato antiguo
  delete data.kbHidden;
  const clamp = () => {
    data.sec = Math.min(Math.max(0, data.sec | 0), data.sections.length - 1);
    data.phr = Math.min(Math.max(0, data.phr | 0), data.sections[data.sec].phrases.length - 1);
  };
  clamp();

  let saved = NS.Storage.get('melodies', []);
  const melodies = (Array.isArray(saved) ? saved : []).filter(m => m && typeof m === 'object' && (Array.isArray(m.sections) || Array.isArray(m.notes)))
    .map(m => { m.sections = NS.Song.normalize(m.sections, m.notes); m.notes = NS.Song.flat(m.sections); if(typeof m.name !== 'string') m.name = 'Melodía';
      m.rhythms = NS.RhythmCore.normalize(m.rhythms); if(!m.rhythms.some(r => r.id === m.favRhythm)) m.favRhythm = null; return m; });
  const subs = [];
  const emit = (keys, src) => subs.forEach(f => f(keys, src));
  const copySecs = s => JSON.parse(JSON.stringify(s));

  NS.State = {
    data,
    melodies,
    on(f){ subs.push(f); },
    set(patch, src){
      Object.assign(data, patch);
      if('sections' in patch || 'sec' in patch || 'phr' in patch) clamp();
      NS.Storage.set('draft', data); emit(Object.keys(patch), src);
    },
    // Notas de la frase activa y de toda la canción
    phraseNotes(){ return data.sections[data.sec].phrases[data.phr].notes; },
    allNotes(){ return NS.Song.flat(data.sections); },
    // Edita una copia de las secciones: fn(secciones, pos) puede cambiar pos.sec / pos.phr.
    mutate(fn, src){
      const secs = copySecs(data.sections), pos = {sec:data.sec, phr:data.phr};
      fn(secs, pos);
      this.set({sections:secs, sec:pos.sec, phr:pos.phr}, src);
    },
    setPhraseNotes(notes, src){
      this.mutate((secs, pos) => { secs[pos.sec].phrases[pos.phr].notes = notes; }, src);
    },
    saveMelody(m){
      const now = Date.now(), sections = copySecs(m.sections), notes = NS.Song.flat(sections);
      let e = m.id && melodies.find(x => x.id === m.id);
      if(e){ Object.assign(e, {name:m.name, sections, notes, updated:now}); } // los ritmos se conservan
      else{
        e = {id:'m' + now.toString(36) + Math.random().toString(36).slice(2,6), name:m.name, sections, notes, rhythms:copySecs(m.rhythms || []), favRhythm:m.favRhythm || null, created:now, updated:now};
        melodies.unshift(e);
      }
      NS.Storage.set('melodies', melodies); emit(['melodies']); return e;
    },
    // Edita una melodía guardada (p. ej. sus ritmos): fn(melodía)
    updateMelody(id, fn){
      const m = melodies.find(x => x.id === id); if(!m) return;
      fn(m); NS.Storage.set('melodies', melodies); emit(['melodies']);
    },
    removeMelody(id){
      const i = melodies.findIndex(x => x.id === id); if(i < 0) return;
      melodies.splice(i, 1); NS.Storage.set('melodies', melodies);
      if(data.editingId === id) this.set({editingId:null});
      emit(['melodies']);
    }
  };
})(window.NS = window.NS || {});
