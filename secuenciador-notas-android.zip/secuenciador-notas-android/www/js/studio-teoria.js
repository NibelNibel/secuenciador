/* Estudio — «🎼 Herramientas musicales» (panel del Roll): escala y tonalidad, acordes, progresiones, arpegiador y transposición.
   Todo es opcional: la escala solo resalta y (si se activa) ajusta; nunca impide escribir notas fuera de ella.
   La teoría está en js/teoria.js; las notas se escriben con ST.roll.colocar / ST.roll.transponer (cada acción = un paso de Deshacer). */
(function(NS){
  'use strict';
  const ST = NS.Studio, TE = NS.Teoria, R = ST.roll, N = NS.Notes, $ = id => document.getElementById(id);
  const panel = $('stTeoria'), toggle = document.querySelector('[data-teo-toggle]');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const opt = (v, t, sel) => '<option value="' + esc(v) + '"' + (sel ? ' selected' : '') + '>' + esc(t) + '</option>';
  const plural = (n, a, b) => n + ' ' + (n === 1 ? a : b);
  const DURS = [[8, '1/4 (una negra)'], [16, '1/2 (una blanca)'], [32, '1 compás'], [64, '2 compases']];
  const POS = [['fin', 'Al final de la pista'], ['vista', 'Donde estoy viendo'], ['sel', 'Después de lo seleccionado']];
  const PASOS = [[8, '1/4'], [4, '1/8'], [2, '1/16'], [1, '1/32']];
  const LARGOS = [[1, 'Ligadas (completas)'], [.6, 'Normales'], [.35, 'Cortas (staccato)']];
  const INVS = ['Fundamental', '1ª inversión', '2ª inversión', '3ª inversión'];

  const ui = {tab:'escala', grupo:'triadas',
    ch:{root:0, tipo:'maj', inv:0, oct:3},
    ins:{dur:32, pos:'fin', bajo:false},
    prog:{idx:-1, txt:'', auto:false, voces:false},
    arp:{patron:'sube', paso:4, octavas:1, largo:1, conservar:false},
    trans:{semis:3}};

  /* ---------- Estructura del panel ---------- */
  panel.innerHTML =
    '<div class="seg teoTabs" id="teoTabs">' +
      [['escala', 'Escala'], ['acordes', 'Acordes'], ['prog', 'Progresión'], ['arp', 'Arpegio'], ['trans', 'Transponer']]
        .map(t => '<button data-tab="' + t[0] + '"' + (t[0] === ui.tab ? ' class="sel"' : '') + '>' + t[1] + '</button>').join('') + '</div>' +

    '<div class="teoPane" data-pane="escala">' +
      '<div class="teoGrid"><label>Tónica<select id="teoRoot"></select></label><label>Escala<select id="teoEscala"></select></label></div>' +
      '<p class="small" id="teoNotas"></p>' +
      '<div class="teoGrid"><button class="btn sm" id="teoResaltar"></button><button class="btn sm" id="teoAjustar"></button></div>' +
      '<button class="btn sm" id="teoAjustarYa">🧲 Ajustar a la escala las notas seleccionadas</button>' +
      '<p class="small">Son ayudas opcionales: las notas de la escala se iluminan en el Roll, y puedes seguir escribiendo notas fuera de ella (llevan un puntito). El ajuste al mover solo actúa si lo activas.</p>' +
    '</div>' +

    '<div class="teoPane" data-pane="acordes" hidden>' +
      '<div class="teoSub"><b>Acordes que encajan en la escala</b><div class="seg mini" id="chGrupo"><button data-g="triadas" class="sel">Tríadas</button><button data-g="septimas">Séptimas</button></div></div>' +
      '<div class="teoChips" id="chChips"></div>' +
      '<div class="teoSub"><b>Construir un acorde</b></div>' +
      '<div class="teoGrid"><label>Nota<select id="chRoot"></select></label><label>Tipo<select id="chTipo"></select></label>' +
        '<label>Inversión<select id="chInv"></select></label><label>Octava<select id="chOct"></select></label></div>' +
      '<p class="small" id="chNotas"></p>' +
    '</div>' +

    '<div class="teoPane" data-pane="prog" hidden>' +
      '<label>Progresión<select id="pgSel"></select></label>' +
      '<label>Acordes (puedes escribir los tuyos)<input id="pgTxt" type="text" maxlength="200" placeholder="Am F C G" autocapitalize="off" autocomplete="off" spellcheck="false"></label>' +
      '<p class="small" id="pgInfo"></p>' +
      '<button class="btn sm" id="pgVoz"></button>' +
    '</div>' +

    '<div class="teoPane" data-pane="arp" hidden>' +
      '<div class="teoGrid"><label>Patrón<select id="arPat"></select></label><label>Velocidad<select id="arPaso"></select></label>' +
        '<label>Octavas<select id="arOct"></select></label><label>Notas<select id="arLargo"></select></label></div>' +
      '<button class="btn sm" id="arCons"></button>' +
      '<p class="small" id="arInfo"></p>' +
    '</div>' +

    '<div class="teoPane" data-pane="trans" hidden>' +
      '<p class="small" id="trInfo"></p>' +
      '<div class="teoBtns">' + [[-12, '⬇ Octava'], [-2, '⬇ Tono'], [-1, '⬇ Semitono'], [1, '⬆ Semitono'], [2, '⬆ Tono'], [12, '⬆ Octava']]
        .map(x => '<button class="btn sm" data-s="' + x[0] + '">' + x[1] + '</button>').join('') + '</div>' +
      '<div class="teoGrid3"><label>Otro valor<select id="trN"></select></label><button class="btn sm" id="trDn">⬇ Bajar</button><button class="btn sm" id="trUp">⬆ Subir</button></div>' +
      '<div class="teoSub"><b>Por grados de la escala</b></div>' +
      '<div class="teoGrid"><button class="btn sm" data-gr="-1">⬇ 1 grado</button><button class="btn sm" data-gr="1">⬆ 1 grado</button></div>' +
      '<p class="small" id="trGHint"></p>' +
    '</div>' +

    '<div class="teoIns" id="teoIns" hidden>' +
      '<div class="teoGrid"><label>Cada acorde dura<select id="inDur"></select></label><label>Colocar<select id="inPos"></select></label></div>' +
      '<button class="btn sm" id="inBajo"></button>' +
    '</div>' +
    '<div class="teoGrid teoAcc" id="teoAcc" hidden><button class="btn sm" id="acA"></button><button class="btn sm primary" id="acB"></button></div>';

  const q = id => panel.querySelector('#' + id);
  const panes = [...panel.querySelectorAll('.teoPane')];

  // Llenado de los selectores (una sola vez)
  q('teoRoot').innerHTML = [...Array(12).keys()].map(i => opt(i, TE.pcLabel(i))).join('');
  const grupos = []; TE.ESCALAS.forEach(e => { let g = grupos.find(x => x.n === e.g); if(!g) grupos.push(g = {n:e.g, items:[]}); g.items.push(e); });
  q('teoEscala').innerHTML = grupos.map(g => '<optgroup label="' + esc(g.n) + '">' + g.items.map(e => opt(e.id, e.n)).join('') + '</optgroup>').join('');
  q('chRoot').innerHTML = q('teoRoot').innerHTML;
  q('chTipo').innerHTML = TE.ACORDES.map(a => opt(a.id, a.n)).join('');
  q('chInv').innerHTML = INVS.map((t, i) => opt(i, t)).join('');
  q('chOct').innerHTML = [2, 3, 4, 5].map(o => opt(o, 'Octava ' + o)).join('');
  q('inDur').innerHTML = DURS.map(d => opt(d[0], d[1])).join('');
  q('inPos').innerHTML = POS.map(p => opt(p[0], p[1])).join('');
  q('arPat').innerHTML = TE.PATRONES.map(p => opt(p[0], p[1])).join('');
  q('arPaso').innerHTML = PASOS.map(p => opt(p[0], p[1])).join('');
  q('arOct').innerHTML = [1, 2, 3].map(o => opt(o, plural(o, 'octava', 'octavas'))).join('');
  q('arLargo').innerHTML = LARGOS.map(l => opt(l[0], l[1])).join('');
  q('trN').innerHTML = [...Array(24).keys()].map(i => opt(i + 1, plural(i + 1, 'semitono', 'semitonos'), i + 1 === ui.trans.semis)).join('');
  const pgGrupos = []; TE.PROGRESIONES.forEach((p, i) => { let g = pgGrupos.find(x => x.n === p.g); if(!g) pgGrupos.push(g = {n:p.g, items:[]}); g.items.push([i, p]); });
  q('pgSel').innerHTML = opt(-1, '— Elegir una progresión —') + pgGrupos.map(g => '<optgroup label="' + esc(g.n) + '">' + g.items.map(x => opt(x[0], x[1].n)).join('') + '</optgroup>').join('');
  q('chOct').value = ui.ch.oct; q('inDur').value = ui.ins.dur; q('arPat').value = ui.arp.patron; q('arPaso').value = ui.arp.paso;

  /* ---------- Utilidades ---------- */
  const bem = () => TE.flatKey();
  const nombresNotas = ps => ps.map(p => N.name(p, bem() ? 'b' : '#')).join(' ');
  const onOff = (b, txt, v) => { b.textContent = txt + ': ' + (v ? 'sí' : 'no'); b.classList.toggle('on', !!v); b.setAttribute('aria-pressed', !!v); };
  const cambio = () => { ST.changed(); R.redibujar(); };
  const idsSel = () => R.notasSel().map(n => n.id);
  const unidadSeg = () => 60 / ST.bpm / 8;

  /* ---------- Escala ---------- */
  function refEscala(){
    const e = TE.estado, act = TE.activa();
    q('teoRoot').value = e.root; q('teoEscala').value = e.escala;
    q('teoNotas').textContent = act ? 'Notas: ' + TE.notasEscala().map(pc => TE.pcName(pc, bem())).join(' ') : 'Sin escala: no se resalta ninguna nota.';
    onOff(q('teoResaltar'), '💡 Resaltar notas', e.resaltar);
    onOff(q('teoAjustar'), '🧲 Ajustar al mover', e.ajustar);
    q('teoResaltar').disabled = q('teoAjustar').disabled = q('teoAjustarYa').disabled = !act;
    q('trGHint').textContent = act ? '' : 'Elige una escala en la pestaña «Escala» para transponer por grados.';
    panel.querySelectorAll('[data-gr]').forEach(b => { b.disabled = !act; });
  }
  function ponerEscala(){
    const antes = TE.etiqueta();
    TE.ponerEscala(+q('teoRoot').value, q('teoEscala').value);
    if(TE.activa() && !TE.estado.resaltar && antes !== TE.etiqueta()) TE.estado.resaltar = true;   // al elegir una escala nueva se vuelve a mostrar
    cambio(); refTodo();
  }
  q('teoRoot').addEventListener('change', ponerEscala);
  q('teoEscala').addEventListener('change', ponerEscala);
  q('teoResaltar').addEventListener('click', () => { TE.estado.resaltar = !TE.estado.resaltar; cambio(); refEscala(); });
  q('teoAjustar').addEventListener('click', () => { TE.estado.ajustar = !TE.estado.ajustar; cambio(); refEscala(); ST.toast(TE.estado.ajustar ? 'Al crear o mover notas se ajustarán a la escala' : 'Ajuste desactivado: notas libres'); });
  q('teoAjustarYa').addEventListener('click', () => {
    const ids = idsSel(), r = R.transponer(ids.length ? ids : null, TE.cercana);
    if(!r.n) ST.toast('No hay notas que ajustar');
    else if(!r.ok) ST.toast('No se pudo ajustar');
    else ST.toast(r.cambiadas ? plural(r.cambiadas, 'nota ajustada', 'notas ajustadas') + ' a la escala' : 'Todas las notas ya estaban en la escala');
  });

  /* ---------- Acordes ---------- */
  function refChips(){
    const box = q('chChips'), lista = TE.compatibles(ui.grupo);
    box.innerHTML = lista.length ? lista.map(c =>
      '<button class="btn sm chip' + (c.root === ui.ch.root && c.tipo === ui.ch.tipo ? ' on' : '') + '" data-r="' + c.root + '" data-t="' + c.tipo + '">' +
      esc(TE.simbolo(c.root, c.tipo, bem())) + (c.romano ? '<small>' + esc(c.romano) + '</small>' : '') + '</button>').join('')
      : '<p class="small">Elige una escala en la pestaña «Escala» para ver aquí los acordes que encajan con ella. También puedes construir cualquier acorde abajo.</p>';
  }
  function refConstructor(){
    q('chRoot').value = ui.ch.root; q('chTipo').value = ui.ch.tipo; q('chInv').value = ui.ch.inv; q('chOct').value = ui.ch.oct;
    const ps = TE.construir(ui.ch.root, ui.ch.tipo, ui.ch.oct, ui.ch.inv);
    q('chNotas').textContent = TE.simbolo(ui.ch.root, ui.ch.tipo, bem()) + ' · ' + nombresNotas(ps) + (TE.activa() && !ps.every(TE.enEscala) ? ' · (alguna nota queda fuera de la escala)' : '');
  }
  const acordePs = () => TE.construir(ui.ch.root, ui.ch.tipo, ui.ch.oct, ui.ch.inv);
  q('chGrupo').addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    ui.grupo = b.dataset.g; q('chGrupo').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b)); refChips();
  });
  q('chChips').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if(!b) return;
    ui.ch.root = +b.dataset.r; ui.ch.tipo = b.dataset.t; refChips(); refConstructor(); R.sonar(acordePs(), 1.1);
  });
  [['chRoot', 'root'], ['chTipo', 'tipo'], ['chInv', 'inv'], ['chOct', 'oct']].forEach(([id, k]) => q(id).addEventListener('change', () => {
    ui.ch[k] = k === 'tipo' ? q(id).value : +q(id).value; refChips(); refConstructor(); R.sonar(acordePs(), 1.1);
  }));

  /* ---------- Dónde y cómo se colocan los acordes ---------- */
  function inicioInsercion(){
    if(ui.ins.pos === 'vista') return R.inicioVista();
    if(ui.ins.pos === 'sel'){ const s = R.notasSel(); if(s.length) return Math.max(...s.map(n => n.s + n.d)); }
    const fin = R.finPistaActual(); return fin ? Math.ceil(fin / 32) * 32 : 0;
  }
  const bajoDe = (root, oct) => { const p = 12 * oct + root; return p >= TE.LOW ? p : p + 12; };   // la fundamental, una octava por debajo del acorde
  function refIns(){
    q('inDur').value = ui.ins.dur; q('inPos').value = ui.ins.pos;
    onOff(q('inBajo'), '🎸 Añadir bajo', ui.ins.bajo); q('inBajo').title = 'Añade la fundamental de cada acorde una octava más grave';
  }
  q('inDur').addEventListener('change', () => { ui.ins.dur = +q('inDur').value; refProg(); });
  q('inPos').addEventListener('change', () => { ui.ins.pos = q('inPos').value; });
  q('inBajo').addEventListener('click', () => { ui.ins.bajo = !ui.ins.bajo; refIns(); });

  function insertarAcorde(){
    const s0 = inicioInsercion(), ps = acordePs(), lista = ps.map(p => ({p, s:s0, d:ui.ins.dur}));
    if(ui.ins.bajo) lista.push({p:bajoDe(ui.ch.root, ui.ch.oct), s:s0, d:ui.ins.dur});
    const r = R.colocar(lista);
    ST.toast(r.added ? TE.simbolo(ui.ch.root, ui.ch.tipo, bem()) + ' en el compás ' + (Math.floor(s0 / 32) + 1) + (r.cut ? ' (' + plural(r.cut, 'nota quedó', 'notas quedaron') + ' fuera)' : '') : 'No cabe: queda fuera del final del Roll');
  }

  /* ---------- Progresión ---------- */
  function refProg(){
    const p = ui.prog, r = TE.parsearProgresion(p.txt);
    if(document.activeElement !== q('pgTxt')) q('pgTxt').value = p.txt;
    q('pgSel').value = p.idx;
    onOff(q('pgVoz'), '🔗 Voces cercanas', p.voces); q('pgVoz').title = 'Cada acorde elige la inversión más próxima al anterior, para un cambio suave';
    let t;
    if(!p.txt.trim()) t = 'Elige una progresión o escribe acordes separados por espacios. Se adaptan a la tónica elegida en «Escala»: ' + TE.pcName(TE.estado.root, bem()) + '.';
    else if(r.error) t = '⚠ No entiendo «' + r.error + '». Ejemplos: Am, F#m7, Bb, Cmaj7, G7, Dsus4, Do, Lam, Sol7.';
    else{
      const total = r.acordes.length * ui.ins.dur / 32;
      t = plural(r.acordes.length, 'acorde', 'acordes') + ' · ' + (total >= 1 ? Math.round(total * 10) / 10 + (total === 1 ? ' compás' : ' compases') : 'menos de un compás');
    }
    q('pgInfo').textContent = t;
    q('acB').disabled = ui.tab === 'prog' && (!p.txt.trim() || !!r.error);
    q('acA').disabled = q('acB').disabled;
  }
  q('pgSel').addEventListener('change', () => {
    const i = +q('pgSel').value; ui.prog.idx = i;
    if(i >= 0){ ui.prog.txt = TE.textoProgresion(TE.PROGRESIONES[i], TE.estado.root, bem()); ui.prog.auto = true; }
    refProg();
  });
  q('pgTxt').addEventListener('input', () => { ui.prog.txt = q('pgTxt').value; ui.prog.auto = false; ui.prog.idx = -1; q('pgSel').value = -1; refProg(); });
  q('pgVoz').addEventListener('click', () => { ui.prog.voces = !ui.prog.voces; refProg(); });

  // Notas de cada acorde de la progresión (con voces cercanas: cada acorde elige la inversión y octava más próximas al anterior)
  function notasProgresion(acordes){
    const res = []; let prev = null;
    acordes.forEach((c, i) => {
      let ps = TE.construir(c.root, c.tipo, ui.ch.oct, i === 0 ? ui.ch.inv : 0);
      if(ui.prog.voces && prev !== null){
        const n = TE.acordeDe(c.tipo).i.length; let mejor = null;
        for(let inv = 0; inv < n; inv++) for(let o = ui.ch.oct - 1; o <= ui.ch.oct + 1; o++){
          const cand = TE.construir(c.root, c.tipo, o, inv), avg = cand.reduce((a, b) => a + b, 0) / cand.length, dist = Math.abs(avg - prev);
          if(!mejor || dist < mejor.dist - 0.01) mejor = {ps:cand, dist};
        }
        if(mejor) ps = mejor.ps;
      }
      prev = ps.reduce((a, b) => a + b, 0) / ps.length;
      res.push({c, ps});
    });
    return res;
  }
  function progresionValida(){
    const r = TE.parsearProgresion(ui.prog.txt);
    if(!ui.prog.txt.trim()){ ST.toast('Elige una progresión o escribe acordes'); return null; }
    if(r.error){ ST.toast('No entiendo «' + r.error + '»'); return null; }
    return r.acordes;
  }
  function insertarProgresion(){
    const ac = progresionValida(); if(!ac) return;
    const s0 = inicioInsercion(), lista = [];
    notasProgresion(ac).forEach((x, i) => {
      const s = s0 + i * ui.ins.dur;
      x.ps.forEach(p => lista.push({p, s, d:ui.ins.dur}));
      if(ui.ins.bajo) lista.push({p:bajoDe(x.c.root, ui.ch.oct), s, d:ui.ins.dur});
    });
    const r = R.colocar(lista), fin = s0 + ac.length * ui.ins.dur;
    ST.toast(r.added ? 'Progresión de ' + plural(ac.length, 'acorde', 'acordes') + ' en los compases ' + (Math.floor(s0 / 32) + 1) + '–' + Math.max(Math.floor(s0 / 32) + 1, Math.ceil(fin / 32)) + (r.cut ? ' (algunas notas quedaron fuera)' : '') : 'No cabe: queda fuera del final del Roll');
  }
  function oirProgresion(){
    const ac = progresionValida(); if(!ac) return;
    const sec = Math.min(ui.ins.dur * unidadSeg(), 2.5);
    notasProgresion(ac).forEach((x, i) => {
      const ps = ui.ins.bajo ? x.ps.concat(bajoDe(x.c.root, ui.ch.oct)) : x.ps;
      R.sonar(ps, sec * .95, i * ui.ins.dur * unidadSeg());
    });
  }

  /* ---------- Arpegio ---------- */
  function refArp(){
    onOff(q('arCons'), '➕ Conservar el acorde original', ui.arp.conservar);
    const sel = R.notasSel(), g = TE.agrupar(sel);
    q('arInfo').textContent = !sel.length ? 'Selecciona un acorde (notas que empiezan a la vez) o varias notas para convertirlos en arpegio. Con «Multi» o «Lazo» (en la barra) eliges varios.'
      : g.length ? plural(sel.length, 'nota seleccionada', 'notas seleccionadas') + ' · ' + plural(g.length, 'acorde que se arpegiará', 'acordes que se arpegiarán')
      : '⚠ Con una sola nota no hay arpegio: selecciona al menos dos notas con alturas distintas.';
    q('acB').disabled = ui.tab === 'arp' && !g.length;
  }
  [['arPat', 'patron', String], ['arPaso', 'paso', Number], ['arOct', 'octavas', Number], ['arLargo', 'largo', Number]].forEach(([id, k, f]) =>
    q(id).addEventListener('change', () => { ui.arp[k] = f(q(id).value); }));
  q('arCons').addEventListener('click', () => { ui.arp.conservar = !ui.arp.conservar; refArp(); });
  function aplicarArpegio(){
    const sel = R.notasSel(), g = TE.agrupar(sel);
    if(!g.length){ ST.toast('Selecciona un acorde o varias notas distintas'); return; }
    const nuevas = [], quitar = [];
    g.forEach(x => { nuevas.push(...TE.arpegiar(x, ui.arp)); quitar.push(...x.ids); });
    const r = R.colocar(nuevas, ui.arp.conservar ? [] : quitar);
    ST.toast(r.added ? plural(g.length, 'acorde arpegiado', 'acordes arpegiados') + ' · ' + plural(r.added, 'nota', 'notas') : 'No se pudo crear el arpegio');
  }

  /* ---------- Transposición ---------- */
  const rangoTxt = () => N.name(TE.LOW, '#') + '–' + N.name(TE.HIGH, '#');
  function distTxt(s){
    s = Math.abs(s);
    return s === 12 ? 'una octava' : s === 24 ? 'dos octavas' : s === 2 ? 'un tono' : s === 1 ? 'un semitono' : s + ' semitonos';
  }
  function refTrans(){
    const sel = R.notasSel(), tr = ST.cur(), todas = R.notasPista().length;
    q('trInfo').textContent = sel.length ? 'Se transponen las ' + plural(sel.length, 'nota seleccionada', 'notas seleccionadas') + '.'
      : todas ? 'No hay nada seleccionado: se transpone toda la pista «' + (tr ? tr.name : '') + '» (' + plural(todas, 'nota', 'notas') + ').' : 'Esta pista no tiene notas todavía.';
  }
  function resultado(r, texto){
    if(!r.n) ST.toast('No hay notas que transponer');
    else if(r.fuera) ST.toast('No se puede: alguna nota saldría del rango (' + rangoTxt() + ')');
    else ST.toast(plural(r.n, 'nota', 'notas') + ' ' + texto);
  }
  function transponer(semis){
    const ids = idsSel(), r = R.transponer(ids.length ? ids : null, p => p + semis);
    resultado(r, (semis > 0 ? 'subida' : 'bajada') + (r.n === 1 ? '' : 's') + ' ' + distTxt(semis));
  }
  function transponerGrados(dir){
    const ids = idsSel(), r = R.transponer(ids.length ? ids : null, p => { const x = TE.siguiente(p, dir); return x === null ? -1 : x; });
    resultado(r, (dir > 0 ? 'subida' : 'bajada') + (r.n === 1 ? '' : 's') + ' un grado de la escala');
  }
  q('trN').addEventListener('change', () => { ui.trans.semis = +q('trN').value; });
  q('trDn').addEventListener('click', () => transponer(-ui.trans.semis));
  q('trUp').addEventListener('click', () => transponer(ui.trans.semis));
  panel.querySelectorAll('[data-s]').forEach(b => b.addEventListener('click', () => transponer(+b.dataset.s)));
  panel.querySelectorAll('[data-gr]').forEach(b => b.addEventListener('click', () => transponerGrados(+b.dataset.gr)));

  /* ---------- Pestañas, botones de acción y estado ---------- */
  function refAcciones(){
    const acc = q('teoAcc'), a = q('acA'), b = q('acB');
    q('teoIns').hidden = !(ui.tab === 'acordes' || ui.tab === 'prog');
    acc.hidden = !['acordes', 'prog', 'arp'].includes(ui.tab);
    a.hidden = ui.tab === 'arp';
    acc.classList.toggle('uno', ui.tab === 'arp');
    a.textContent = '▶ Escuchar';
    b.textContent = ui.tab === 'acordes' ? '＋ Insertar acorde' : ui.tab === 'prog' ? '＋ Insertar progresión' : '🎹 Aplicar arpegio';
    a.disabled = b.disabled = false;
    if(ui.tab === 'prog') refProg(); else if(ui.tab === 'arp') refArp();
  }
  function ponerPestana(t){
    ui.tab = t;
    panel.querySelectorAll('#teoTabs button').forEach(b => b.classList.toggle('sel', b.dataset.tab === t));
    panes.forEach(p => { p.hidden = p.dataset.pane !== t; });
    refAcciones(); refTrans(); refArp();
  }
  q('teoTabs').addEventListener('click', e => { const b = e.target.closest('button'); if(b) ponerPestana(b.dataset.tab); });
  q('acA').addEventListener('click', () => { if(ui.tab === 'acordes') R.sonar(acordePs(), 1.4); else if(ui.tab === 'prog') oirProgresion(); });
  q('acB').addEventListener('click', () => {
    if(ui.tab === 'acordes') insertarAcorde(); else if(ui.tab === 'prog') insertarProgresion(); else if(ui.tab === 'arp') aplicarArpegio();
  });

  function refTodo(){
    // la tónica cambió: una progresión elegida de la lista se vuelve a escribir en la nueva tonalidad
    if(ui.prog.auto && ui.prog.idx >= 0) ui.prog.txt = TE.textoProgresion(TE.PROGRESIONES[ui.prog.idx], TE.estado.root, bem());
    refEscala(); refChips(); refConstructor(); refIns(); refProg(); refArp(); refTrans(); refAcciones();
  }

  toggle.addEventListener('click', () => {
    panel.hidden = !panel.hidden;
    toggle.classList.toggle('on', !panel.hidden); toggle.setAttribute('aria-expanded', !panel.hidden);
    if(!panel.hidden) refTodo();
  });
  R.uiHooks.push(() => { if(panel.hidden) return; refTrans(); refArp(); });
  ST.listeners.push(() => { refTodo(); });          // al abrir otro proyecto o cambiar de pista
  refTodo();
})(window.NS = window.NS || {});
