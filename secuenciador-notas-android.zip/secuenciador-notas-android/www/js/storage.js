/* Persistencia en localStorage (a prueba de fallos). */
(function(NS){
  const P = 'secuenciadorNotas.v1.';
  NS.Storage = {
    get(k, def){ try{ const v = localStorage.getItem(P + k); return v === null ? def : JSON.parse(v); }catch(e){ return def; } },
    set(k, v){ try{ localStorage.setItem(P + k, JSON.stringify(v)); return true; }catch(e){ return false; } }
  };
})(window.NS = window.NS || {});
