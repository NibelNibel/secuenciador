/* Estructura de la canción: secciones (Introducción, Estrofa, Coro…) → frases → notas.
   Al reproducir solo se usan las notas, en orden (flat). */
(function(NS){
  const uid = () => 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const okNote = n => Number.isInteger(n) && n >= NS.Notes.MIN && n <= NS.Notes.MAX;

  // Etiquetas sugeridas por la app
  const PRESETS = ['Introducción', 'Estrofa', 'Pre-coro', 'Coro', 'Post-coro', 'Puente', 'Solo', 'Interludio', 'Final'];
  // Plantillas de estructura (se añaden como secciones vacías)
  const TEMPLATES = [
    {name:'Pop clásico', parts:['Introducción', 'Estrofa', 'Pre-coro', 'Coro', 'Estrofa', 'Pre-coro', 'Coro', 'Puente', 'Coro', 'Final']},
    {name:'Estrofa + Coro', parts:['Introducción', 'Estrofa', 'Coro', 'Estrofa', 'Coro', 'Final']},
    {name:'Simple (A–B)', parts:['Estrofa', 'Coro']}
  ];

  const newSection = (label, notes) => ({id:uid(), label:label || '', phrases:[{notes:notes ? notes.slice() : []}]});
  const fromNotes = notes => [newSection('', notes)];
  const flat = secs => secs.reduce((a, s) => a.concat(...s.phrases.map(p => p.notes)), []);

  // Sanea lo que venga de localStorage / versiones antiguas (que solo tenían `notes`).
  function normalize(secs, fallbackNotes){
    let out = [];
    if(Array.isArray(secs)){
      out = secs.filter(s => s && typeof s === 'object').map(s => {
        const phrases = (Array.isArray(s.phrases) ? s.phrases : [])
          .filter(p => p && Array.isArray(p.notes)).map(p => ({notes:p.notes.filter(okNote)}));
        if(!phrases.length) phrases.push({notes:[]});
        return {id:typeof s.id === 'string' && s.id ? s.id : uid(), label:typeof s.label === 'string' ? s.label.slice(0, 40) : '', phrases};
      });
    }
    if(!out.length) out = fromNotes(Array.isArray(fallbackNotes) ? fallbackNotes.filter(okNote) : []);
    return out;
  }

  // Posición (sección, frase, nota) de la nota nº idx de la lista plana.
  function locate(secs, idx){
    let n = 0;
    for(let s = 0; s < secs.length; s++) for(let p = 0; p < secs[s].phrases.length; p++){
      const len = secs[s].phrases[p].notes.length;
      if(idx < n + len) return {s, p, i:idx - n};
      n += len;
    }
    return null;
  }

  const labelOf = (sec, i) => sec.label || ('Sección ' + (i + 1));

  // Si la etiqueta ya existe en otra sección, añade nº: «Estrofa» → «Estrofa 2»…
  function uniqueLabel(secs, label, skipIdx){
    const used = secs.filter((s, i) => i !== skipIdx).map(s => s.label.toLowerCase());
    if(!used.includes(label.toLowerCase())) return label;
    let n = 2; while(used.includes((label + ' ' + n).toLowerCase())) n++;
    return label + ' ' + n;
  }

  // Texto para el portapapeles: una línea por frase, bajo el título de cada sección.
  function toText(secs, acc){
    const hasLabels = secs.length > 1 || secs[0].label;
    return secs.map((s, i) => {
      const lines = s.phrases.filter(p => p.notes.length).map(p => NS.Notes.format(p.notes, acc));
      if(!lines.length) return '';
      return (hasLabels ? '[' + labelOf(s, i) + ']\n' : '') + lines.join('\n');
    }).filter(Boolean).join('\n\n');
  }

  /* Texto → secciones y frases (inverso de toText).
       [Estrofa]            ← encabezado = sección (también «Estrofa:»)
       A4 B4 C5 …           ← cada línea = una frase
     Sin encabezados, una línea en blanco separa secciones. Devuelve {sections, bad, ignored}. */
  const HEAD = /^[\[\(\{]\s*(.*?)\s*[\]\)\}]\s*:?$|^([^\[\(\{\]\)\}:]+):$/;
  function parseText(text){
    const secs = [], bad = [], ignored = [];
    let cur = null, gap = false;
    const open = label => { cur = newSection(label); cur.phrases = []; secs.push(cur); gap = false; };
    String(text || '').split(/\r?\n/).forEach(raw => {
      const line = raw.trim();
      if(!line){ gap = true; return; }
      const h = HEAD.exec(line);
      if(h){ open((h[1] !== undefined ? h[1] : h[2]).trim().slice(0, 40)); return; }
      const r = NS.Notes.parseSeq(line);
      if(!r.notes.length){ ignored.push(line); return; } // texto suelto (letra, comentarios…)
      bad.push(...r.bad);
      if(!cur || (gap && !cur.label && cur.phrases.length)) open('');
      cur.phrases.push({notes:r.notes}); gap = false;
    });
    secs.forEach(s => { if(!s.phrases.length) s.phrases.push({notes:[]}); });
    return {sections:secs, bad, ignored};
  }

  async function copy(text){
    try{ if(navigator.clipboard && window.isSecureContext){ await navigator.clipboard.writeText(text); return true; } }catch(e){}
    try{ // respaldo para WebViews sin Clipboard API
      const t = document.createElement('textarea'); t.value = text; t.setAttribute('readonly', '');
      t.style.cssText = 'position:fixed;top:0;left:0;opacity:0'; document.body.appendChild(t); t.select();
      const ok = document.execCommand('copy'); t.remove(); return ok;
    }catch(e){ return false; }
  }

  // Tono (0-360) distintivo de cada sección: mismo tipo = mismo color («Estrofa 2» → como «Estrofa»).
  const HUES = {'introduccion':205, 'estrofa':150, 'pre-coro':48, 'precoro':48, 'coro':345, 'post-coro':295, 'postcoro':295,
                'puente':22, 'solo':255, 'interludio':175, 'final':95};
  function hueOf(sec, i){
    const key = (sec.label || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\d]+$/, '').trim();
    if(HUES[key] !== undefined) return HUES[key];
    if(!key) return (i * 47 + 20) % 360;
    let x = 7; for(const ch of key) x = (x * 31 + ch.charCodeAt(0)) >>> 0;
    return x % 360;
  }

  NS.Song = {hueOf, PRESETS, TEMPLATES, newSection, fromNotes, flat, normalize, locate, labelOf, uniqueLabel, toText, parseText, copy};
})(window.NS = window.NS || {});
