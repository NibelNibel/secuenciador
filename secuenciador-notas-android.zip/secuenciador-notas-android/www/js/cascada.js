/* Nibel: Cascada - animacion de notas que caen sobre un teclado (estilo Falling Notes).
   Lleva su propio reloj sobre el tiempo del audio (no usa el Transport del Estudio), asi no se mezclan.
   Las notas se leen con NS.CascadaLectores y suenan con el mismo motor de instrumentos del Estudio. */
(function(NS){
  'use strict';
  const T = window.Tone, $ = id => document.getElementById(id);
  const NOTA_MINIMA = 12, NOTA_MAXIMA = 119;
  const TIEMPO_PREVIO = 2, TIEMPO_FINAL = 1.5;               // Nibel: segundos de espera antes de la primera nota y despues de la ultima
  const ANTICIPO_AGENDA = 0.15, INTERVALO_AGENDA = 30;       // Nibel: cada 30 ms se programan las notas de los proximos 150 ms
  const OPCIONES_CAIDA = [2, 3, 4, 6, 8];                    // Nibel: segundos que tarda una nota en caer hasta el teclado
  const OPCIONES_VELOCIDAD = [0.5, 0.75, 1, 1.25, 1.5];
  const MAXIMO_PARTICULAS = 220;
  const ES_NEGRA = [false, true, false, true, false, false, true, false, true, false, true, false];
  const NOTA_DEFECTO_BAJA = 48, NOTA_DEFECTO_ALTA = 83;      // Nibel: C3 a B5 cuando todavia no hay cancion

  // Colores del tema activo; la exportación a vídeo usa siempre los originales (el vídeo no depende del tema)
  const pal = () => (estaExportando ? NS.Theme.clasica() : NS.Theme.palette());
  const lienzo = $('caLienzo'), escena = $('caEscena'), fondoPantalla = document.createElement('canvas');
  // Nibel: ctx y fondo apuntan a los lienzos donde se dibuja ahora: los de la pantalla, o los de la exportacion a video
  let ctx = lienzo.getContext('2d'), fondo = fondoPantalla, ctxFondo = fondo.getContext('2d'), estaExportando = false;

  let cancion = null, fuente = 'estudio', firmaEstudio = '';
  let estaReproduciendo = false, esBucle = false, estaArrastrando = false, estaEnCine = false, esTecladoCompleto = false;
  let posicion = -TIEMPO_PREVIO, posicionBase = 0, relojBase = 0, indiceAgenda = 0, finAuto = 0, idAgenda = 0, idCuadro = 0;   // finAuto: hasta dónde (segundos de la canción) ya se programó la automatización
  let indiceCaida = 2, indiceVelocidad = 2, ultimoPintado = 0, posicionAnterior = -TIEMPO_PREVIO, ultimoTextoTiempo = '';
  let ancho = 0, alto = 0, ratio = 1, arriba = 0, altoTeclado = 0, altoNegra = 0, versionDisposicion = 0;
  let teclas = [], blancas = [], negras = [], mapaTeclas = [], gradienteBlanca = null, gradienteNegra = null;
  let necesitaPintar = true, particulas = [], activas = new Map(), idOcultarBarra = 0;

  const ajustes = NS.Storage.get('cascada', {});
  if(Number.isInteger(ajustes.caida) && ajustes.caida >= 0 && ajustes.caida < OPCIONES_CAIDA.length) indiceCaida = ajustes.caida;
  if(Number.isInteger(ajustes.velocidad) && ajustes.velocidad >= 0 && ajustes.velocidad < OPCIONES_VELOCIDAD.length) indiceVelocidad = ajustes.velocidad;
  esBucle = !!ajustes.bucle; esTecladoCompleto = !!ajustes.tecladoCompleto;
  const guardarAjustes = () => NS.Storage.set('cascada', {caida:indiceCaida, velocidad:indiceVelocidad, bucle:esBucle, tecladoCompleto:esTecladoCompleto});

  const velocidad = () => OPCIONES_VELOCIDAD[indiceVelocidad];
  const duracionTotal = () => (cancion ? cancion.duracion : 0);
  const relojAudio = () => T.context.currentTime;
  // Nibel: el sonido tarda un poquito en salir por el altavoz; se resta para que lo que ves coincida con lo que oyes
  const latenciaSalida = () => { const raw = T.context.rawContext; return Math.max(0, Math.min(0.2, (raw && (raw.outputLatency || raw.baseLatency)) || 0)); };
  const posicionEn = reloj => posicionBase + (reloj - relojBase) * velocidad();
  const posicionVisible = () => (estaReproduciendo ? Math.min(posicionEn(relojAudio() - latenciaSalida()), duracionTotal() + TIEMPO_FINAL) : posicion);
  const formatoTiempo = s => { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

  /* ---------- Colores ---------- */
  const mezclarConBlanco = (rgb, f) => rgb.map(c => Math.round(c + (255 - c) * f));
  const css = (rgb, a) => 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + (a === undefined ? 1 : a) + ')';
  function prepararColores(pista){
    pista.rgb = [1, 3, 5].map(i => parseInt(pista.color.slice(i, i + 2), 16));
    pista.rgbClaro = mezclarConBlanco(pista.rgb, 0.45);
    pista.rgbBrillo = mezclarConBlanco(pista.rgb, 0.75);
    pista.cBase = css(pista.rgb); pista.cClaro = css(pista.rgbClaro); pista.cBrillo = css(pista.rgbBrillo);
    pista.versionGradiente = -1;
  }

  /* ---------- Cargar una cancion ---------- */
  function liberarAudio(){
    if(!cancion) return;
    cancion.pistas.forEach(p => { try{ p.audio.dispose(); }catch(e){} });
  }
  function aplicarCancion(nueva){
    detener();
    liberarAudio();
    nueva.notas.sort((a, b) => a.i - b.i || a.p - b.p);
    let finMaximo = 0;
    nueva.finesMaximos = new Float64Array(nueva.notas.length);
    nueva.notas.forEach((n, k) => { n.f = n.i + n.d; finMaximo = Math.max(finMaximo, n.f); nueva.finesMaximos[k] = finMaximo; });
    nueva.duracion = finMaximo;
    nueva.bajo = Math.min(...nueva.notas.map(n => n.p)); nueva.alto = Math.max(...nueva.notas.map(n => n.p));
    nueva.pistas.forEach(p => { prepararColores(p); p.audio = NS.Audio.createTrack({inst:p.inst, vol:p.vol, pan:p.pan, gan:p.gan, fx:p.fx}); });
    nueva.hayAuto = !!nueva.segundosPorUnidad && nueva.pistas.some(p => NS.Auto.alguna(p.auto));   // curvas de volumen / balance del Estudio
    cancion = nueva; posicion = -TIEMPO_PREVIO; posicionAnterior = posicion; particulas = [];
    armarDisposicion(); dibujarInterfaz(); necesitaPintar = true;
  }
  const mensaje = texto => { $('caMensaje').textContent = texto || ''; };

  function cargarDelEstudio(){
    const ST = NS.Studio;
    try{
      const estado = ST.exportState();
      const firma = JSON.stringify([estado.bpm, estado.tracks, estado.roll.notes.map(n => [n.t, n.p, n.s, n.d])]);
      if(cancion && fuente === 'estudio' && firma === firmaEstudio) return;       // Nibel: nada cambio desde la ultima vez, se deja todo como esta
      firmaEstudio = firma; fuente = 'estudio';
      aplicarCancion(NS.CascadaLectores.cancionDeProyecto(estado, ''));
      mensaje('');
    }catch(e){
      vaciar(e.message); firmaEstudio = '';
    }
    dibujarFuente();
  }
  function vaciar(texto){
    detener(); liberarAudio(); cancion = null; fuente = 'estudio'; posicion = -TIEMPO_PREVIO; particulas = [];
    armarDisposicion(); dibujarInterfaz(); mensaje(texto || ''); necesitaPintar = true;
  }
  async function cargarArchivo(archivo){
    if(!archivo) return;
    mensaje('Leyendo ' + archivo.name + '...');
    try{
      const nueva = await NS.CascadaLectores.leerArchivo(archivo);
      fuente = 'archivo'; aplicarCancion(nueva); dibujarFuente();
      mensaje(nueva.aviso || '');
      NS.Studio.toast('Listo: ' + nueva.nombre);
    }catch(e){
      mensaje(e && e.message ? e.message : 'No se pudo abrir ese archivo.');
    }
  }

  /* ---------- Reproduccion ---------- */
  function primerIndiceDesde(tiempo){
    const notas = cancion.notas; let bajo = 0, alto = notas.length;
    while(bajo < alto){ const medio = (bajo + alto) >> 1; if(notas[medio].i < tiempo) bajo = medio + 1; else alto = medio; }
    return bajo;
  }
  function agendar(){
    if(!estaReproduciendo || !cancion) return;
    const ahora = relojAudio(), limite = posicionEn(ahora + ANTICIPO_AGENDA), notas = cancion.notas, v = velocidad();
    while(indiceAgenda < notas.length && notas[indiceAgenda].i <= limite){
      const n = notas[indiceAgenda++], pista = cancion.pistas[n.pista];
      if(pista.estaOculta) continue;
      const cuando = Math.max(ahora, relojBase + (n.i - posicionBase) / v);
      pista.audio.play(n.p, Math.min(30, Math.max(0.05, n.d / v)), cuando, 0.85);
    }
    if(cancion.hayAuto && limite > finAuto) agendarAutomatizacion(ahora, limite, v);
  }
  // Volumen y balance de cada pista entre finAuto y `hasta` (segundos de la canción): un tramo corto cada vez
  function agendarAutomatizacion(ahora, hasta, v){
    const spu = cancion.segundosPorUnidad, a = finAuto, ua = a / spu, ub = hasta / spu;
    const t0 = Math.max(ahora, relojBase + (a - posicionBase) / v), dur = relojBase + (hasta - posicionBase) / v - t0;
    finAuto = hasta;
    const tramo = (lane, poner) => {
      if(!lane || !lane.pts.length) return;
      const va = NS.Auto.valorEn(lane, ua);
      if(lane.curva === 'escalon'){                                    // saltos: el valor cambia justo en cada punto
        poner(va, va, t0, 0);
        for(const q of lane.pts) if(q.s > ua && q.s <= ub) poner(q.v, q.v, relojBase + (q.s * spu - posicionBase) / v, 0);
      }else if(dur > 0) poner(va, NS.Auto.valorEn(lane, ub), t0, dur);
    };
    for(const p of cancion.pistas){
      if(!p.auto) continue;
      tramo(p.auto.vol, (x, y, t, d) => p.audio.autoVol(x, y, t, d));
      tramo(p.auto.pan, (x, y, t, d) => p.audio.autoPan(x, y, t, d));
    }
  }
  function silenciarTodo(){ if(cancion) cancion.pistas.forEach(p => { p.audio.silence(); if(p.auto) p.audio.restaurar(); }); }

  async function reproducir(){
    if(!cancion) return;
    NS.Player.stop(); NS.Studio.stop();                                // Nibel: se apaga el Estudio y el reproductor de melodias para que no suenen a la vez
    try{ await NS.Audio.start(); }catch(e){}
    if(T.context.state !== 'running'){ try{ await T.context.resume(); }catch(e){} }
    if(T.context.state !== 'running'){ NS.Studio.toast('No se pudo activar el audio. Toca de nuevo.'); return; }
    if(posicion >= cancion.duracion + TIEMPO_FINAL - 0.05) posicion = -TIEMPO_PREVIO;
    posicionBase = posicion; relojBase = relojAudio() + 0.05;
    indiceAgenda = primerIndiceDesde(posicion - 0.001); finAuto = posicion;
    estaReproduciendo = true; posicionAnterior = posicion;
    clearInterval(idAgenda); idAgenda = setInterval(agendar, INTERVALO_AGENDA); agendar();
    dibujarInterfaz(); iniciarCuadros();
  }
  function pausar(){
    if(!estaReproduciendo) return;
    posicion = Math.max(-TIEMPO_PREVIO, Math.min(posicionVisible(), duracionTotal() + TIEMPO_FINAL));
    estaReproduciendo = false; clearInterval(idAgenda); idAgenda = 0; silenciarTodo(); dibujarInterfaz(); necesitaPintar = true;
  }
  function detener(){
    if(estaReproduciendo){ estaReproduciendo = false; clearInterval(idAgenda); idAgenda = 0; silenciarTodo(); }
    posicion = -TIEMPO_PREVIO; posicionAnterior = posicion; particulas = []; dibujarInterfaz(); necesitaPintar = true;
  }
  function alternar(){ if(estaReproduciendo) pausar(); else reproducir(); }
  function moverA(destino){
    if(!cancion) return;
    destino = Math.max(-TIEMPO_PREVIO, Math.min(destino, cancion.duracion + TIEMPO_FINAL));
    posicion = destino; posicionAnterior = destino; particulas = [];
    if(estaReproduciendo){
      silenciarTodo(); posicionBase = destino; relojBase = relojAudio() + 0.03; indiceAgenda = primerIndiceDesde(destino - 0.001); finAuto = destino;
    }
    necesitaPintar = true; actualizarPosicion();
  }
  function cambiarVelocidad(){
    if(estaReproduciendo){ const ahora = relojAudio(); posicionBase = posicionEn(ahora); relojBase = ahora; }
    indiceVelocidad = (indiceVelocidad + 1) % OPCIONES_VELOCIDAD.length;
    guardarAjustes(); dibujarInterfaz();
  }

  /* ---------- Disposicion: teclado, fondo y medidas ---------- */
  function rangoDeTeclas(){
    if(esTecladoCompleto) return [21, 108];                              // Nibel: las 88 teclas de un piano (A0 a C8)
    let bajo = cancion ? cancion.bajo : NOTA_DEFECTO_BAJA, alto = cancion ? cancion.alto : NOTA_DEFECTO_ALTA;
    bajo = Math.floor(bajo / 12) * 12; alto = Math.floor(alto / 12) * 12 + 11;   // Nibel: se completan octavas enteras, de C a B
    while((alto - bajo + 1) / 12 < 3){ if(alto + 12 <= NOTA_MAXIMA) alto += 12; else if(bajo - 12 >= NOTA_MINIMA) bajo -= 12; else break; }
    return [Math.max(NOTA_MINIMA, bajo), Math.min(NOTA_MAXIMA, alto)];
  }
  function armarDisposicion(){
    if(estaExportando) return false;                                       // Nibel: mientras se exporta el video no se toca la disposicion
    const w = escena.clientWidth, h = escena.clientHeight;
    if(!w || !h) return false;
    disponer(w, h, Math.min(2, window.devicePixelRatio || 1), lienzo, fondoPantalla);
    return true;
  }
  // Nibel: w x h son las medidas "logicas" (las que usa el dibujo); el lienzo real mide w*r x h*r pixeles
  function disponer(w, h, r, lienzoDestino, fondoDestino){
    ctx = lienzoDestino.getContext('2d'); fondo = fondoDestino; ctxFondo = fondo.getContext('2d');
    ratio = r; ancho = w; alto = h; versionDisposicion++;
    for(const c of [lienzoDestino, fondoDestino]){ c.width = Math.round(w * ratio); c.height = Math.round(h * ratio); }
    const [bajo, techo] = rangoDeTeclas();
    blancas = []; negras = []; teclas = []; mapaTeclas = new Array(128).fill(null);
    for(let p = bajo; p <= techo; p++) if(!ES_NEGRA[p % 12]) blancas.push({p, esNegra:false, x:0, w:0});
    const anchoBlanca = w / blancas.length;
    blancas.forEach((t, k) => { t.x = k * anchoBlanca; t.w = anchoBlanca; mapaTeclas[t.p] = t; });
    for(let p = bajo; p <= techo; p++){
      if(!ES_NEGRA[p % 12]) continue;
      const izquierda = mapaTeclas[p - 1]; if(!izquierda) continue;
      const anchoNegra = anchoBlanca * 0.62, t = {p, esNegra:true, x:izquierda.x + izquierda.w - anchoNegra / 2, w:anchoNegra};
      negras.push(t); mapaTeclas[p] = t;
    }
    teclas = blancas.concat(negras);
    altoTeclado = Math.round(Math.max(52, Math.min(112, h * 0.15))); altoNegra = Math.round(altoTeclado * 0.62); arriba = h - altoTeclado;
    const P = pal();
    gradienteBlanca = ctx.createLinearGradient(0, arriba, 0, h); gradienteBlanca.addColorStop(0, P.blancaArriba); gradienteBlanca.addColorStop(1, P.blancaAbajo);
    gradienteNegra = ctx.createLinearGradient(0, arriba, 0, arriba + altoNegra); gradienteNegra.addColorStop(0, P.negraArriba); gradienteNegra.addColorStop(1, P.negraAbajo);
    armarFondo(); necesitaPintar = true;
  }
  function armarFondo(){
    const c = ctxFondo, P = pal(); c.setTransform(ratio, 0, 0, ratio, 0, 0);
    const degradado = c.createLinearGradient(0, 0, 0, arriba);
    degradado.addColorStop(0, P.escenaArriba); degradado.addColorStop(1, P.escenaAbajo);
    c.fillStyle = degradado; c.fillRect(0, 0, ancho, alto);
    c.fillStyle = P.carrilNegro;                                      // Nibel: carriles mas oscuros donde van las teclas negras
    for(const t of negras) c.fillRect(t.x, 0, t.w, arriba);
    for(const t of blancas){                                               // Nibel: lineas finas entre teclas; las de cada Do (C) son mas claras
      c.fillStyle = t.p % 12 === 0 ? P.lineaDo : P.lineaTecla;
      c.fillRect(Math.round(t.x), 0, 1, arriba);
    }
  }

  /* ---------- Dibujo ---------- */
  function trazarRedondeado(x, y, w, h, r){
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function trazarBase(x, y, w, h, r){                                      // Nibel: rectangulo con las esquinas redondeadas solo abajo
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r); ctx.closePath();
  }
  function carril(tecla){                                                  // Nibel: por donde cae la nota de esa tecla
    const margen = tecla.esNegra ? 0.5 : 1;
    return {x:tecla.x + margen, w:Math.max(2, tecla.w - margen * 2)};
  }
  function gradienteActivo(pista, esNegra){
    if(pista.versionGradiente !== versionDisposicion){
      pista.gradienteBlanca = ctx.createLinearGradient(0, arriba, 0, alto); pista.gradienteBlanca.addColorStop(0, pista.cBase); pista.gradienteBlanca.addColorStop(1, css(mezclarConBlanco(pista.rgb, 0.82)));
      pista.gradienteNegra = ctx.createLinearGradient(0, arriba, 0, arriba + altoNegra); pista.gradienteNegra.addColorStop(0, pista.cBrillo); pista.gradienteNegra.addColorStop(1, pista.cBase);
      pista.versionGradiente = versionDisposicion;
    }
    return esNegra ? pista.gradienteNegra : pista.gradienteBlanca;
  }

  function dibujarCompases(t, ventana, pixelesPorSegundo){
    const compases = cancion.compases, P = pal();
    let k = 0, bajo = 0, alto2 = compases.length;
    while(bajo < alto2){ const medio = (bajo + alto2) >> 1; if(compases[medio].fin < t) bajo = medio + 1; else alto2 = medio; }
    k = bajo;
    ctx.font = '600 10px system-ui, sans-serif'; ctx.textBaseline = 'bottom'; ctx.textAlign = 'left';
    for(; k < compases.length && compases[k].t <= t + ventana; k++){
      const c = compases[k], paso = (c.fin - c.t) / c.tiempos;
      for(let b = 0; b < c.tiempos; b++){
        const y = Math.round(arriba - (c.t + b * paso - t) * pixelesPorSegundo);
        if(y < 0 || y > arriba) continue;
        ctx.fillStyle = b === 0 ? P.compas0 : P.compas;
        ctx.fillRect(0, y, ancho, 1);
        if(b === 0){ ctx.fillStyle = P.compasTexto; ctx.fillText(c.etiqueta, 4, y - 2); }
      }
    }
  }

  function lanzarParticulas(tecla, pista){
    const cantidad = 3 + ((Math.random() * 3) | 0);
    for(let k = 0; k < cantidad && particulas.length < MAXIMO_PARTICULAS; k++){
      particulas.push({x:tecla.x + tecla.w / 2 + (Math.random() - 0.5) * tecla.w, y:arriba - 2, vx:(Math.random() - 0.5) * 46,
        vy:-(40 + Math.random() * 100), vida:0, maximo:0.5 + Math.random() * 0.55, radio:0.8 + Math.random() * 1.7, rgb:pista.rgbBrillo});
    }
  }

  function dibujarNotas(t, ventana, pixelesPorSegundo, hayParticulas){
    const notas = cancion.notas, fines = cancion.finesMaximos;
    activas.clear();
    let bajo = 0, alto2 = notas.length;
    while(bajo < alto2){ const medio = (bajo + alto2) >> 1; if(fines[medio] < t) bajo = medio + 1; else alto2 = medio; }  // Nibel: primera nota que aun no termino
    const desvanecer = Math.max(20, alto * 0.07);
    for(let k = bajo; k < notas.length; k++){
      const n = notas[k];
      if(n.i > t + ventana) break;
      if(n.f < t) continue;
      const pista = cancion.pistas[n.pista];
      if(pista.estaOculta) continue;
      const tecla = mapaTeclas[n.p]; if(!tecla) continue;
      const yInicio = arriba - (n.i - t) * pixelesPorSegundo, yFin = yInicio - n.d * pixelesPorSegundo;
      const y1 = Math.min(yInicio - 1.5, arriba);
      let y0 = Math.max(yFin, -6);
      if(y1 - y0 < 3) y0 = y1 - 3;                                           // Nibel: una nota muy corta se dibuja con un alto minimo para que se vea
      const estaSonando = n.i <= t && t < n.f, c = carril(tecla), altura = y1 - y0;
      if(estaSonando){ activas.set(n.p, pista); }
      else if(hayParticulas && n.i > posicionAnterior && n.i <= t) lanzarParticulas(tecla, pista);
      ctx.globalAlpha = Math.min(1, Math.max(0, y1) / desvanecer);
      ctx.fillStyle = css(pista.rgb, 0.16); trazarRedondeado(c.x - 2, y0 - 2, c.w + 4, altura + 4, 6); ctx.fill();          // Nibel: halo suave alrededor de la nota
      ctx.fillStyle = estaSonando ? pista.cClaro : pista.cBase; trazarRedondeado(c.x, y0, c.w, altura, Math.min(4, c.w / 2)); ctx.fill();
      if(c.w > 5){ ctx.fillStyle = 'rgba(255,255,255,0.28)'; ctx.fillRect(c.x + 1, y0 + 2, 1.5, Math.max(0, altura - 4)); }
    }
    ctx.globalAlpha = 1;
  }

  function dibujarBrillos(){
    ctx.globalCompositeOperation = 'lighter';
    activas.forEach((pista, p) => {
      const tecla = mapaTeclas[p], centro = tecla.x + tecla.w / 2, radio = Math.max(tecla.w * 2.4, 22);
      const resplandor = ctx.createRadialGradient(centro, arriba, 0, centro, arriba, radio);
      resplandor.addColorStop(0, css(pista.rgbBrillo, 0.75)); resplandor.addColorStop(1, css(pista.rgb, 0));
      ctx.fillStyle = resplandor; ctx.fillRect(centro - radio, arriba - radio, radio * 2, radio * 2);
      const haz = ctx.createLinearGradient(0, arriba, 0, arriba - 70);
      haz.addColorStop(0, css(pista.rgbBrillo, 0.45)); haz.addColorStop(1, css(pista.rgb, 0));
      const c = carril(tecla); ctx.fillStyle = haz; ctx.fillRect(c.x, arriba - 70, c.w, 70);
    });
    ctx.globalCompositeOperation = 'source-over';
  }

  function dibujarParticulas(dt){
    if(!particulas.length) return;
    ctx.globalCompositeOperation = 'lighter';
    particulas = particulas.filter(p => {
      p.vida += dt; if(p.vida >= p.maximo) return false;
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 70 * dt;
      ctx.fillStyle = css(p.rgb, (1 - p.vida / p.maximo) * 0.9);
      ctx.beginPath(); ctx.arc(p.x, p.y, p.radio, 0, 6.2832); ctx.fill();
      return true;
    });
    ctx.globalCompositeOperation = 'source-over';
  }

  function dibujarTeclado(){
    const baseY = arriba, P = pal();
    for(const t of blancas){
      const pista = activas.get(t.p);
      ctx.fillStyle = pista ? gradienteActivo(pista, false) : gradienteBlanca;
      trazarBase(t.x + 0.5, baseY, t.w - 1, altoTeclado - 1, Math.min(4, t.w / 2));
      ctx.fill();
    }
    for(const t of negras){
      const pista = activas.get(t.p);
      ctx.fillStyle = pista ? gradienteActivo(pista, true) : gradienteNegra;
      trazarBase(t.x, baseY, t.w, altoNegra, Math.min(3, t.w / 2)); ctx.fill();
      if(!pista){ ctx.fillStyle = P.negraBrillo; ctx.fillRect(t.x + 1.5, baseY, 1.2, altoNegra - 5); }
    }
    const tamano = Math.max(6.5, Math.min(10, (blancas[0] ? blancas[0].w : 10) * 0.55));
    ctx.font = '600 ' + tamano + 'px system-ui, sans-serif'; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
    ctx.fillStyle = P.teclaRotulo;
    for(const t of blancas) if(t.p % 12 === 0 && !activas.has(t.p)) ctx.fillText('C' + (Math.floor(t.p / 12) - 1), t.x + 1.5, alto - 4);
    const linea = ctx.createLinearGradient(0, 0, ancho, 0);                 // Nibel: linea brillante donde las notas tocan el teclado
    linea.addColorStop(0, P.impactoBorde); linea.addColorStop(0.5, P.impactoCentro); linea.addColorStop(1, P.impactoBorde);
    ctx.fillStyle = linea; ctx.fillRect(0, baseY - 1.5, ancho, 2);
  }

  // Nibel: dibuja un fotograma completo de la animacion en el instante t (segundos de la cancion). Lo usan la pantalla y la exportacion a video.
  function dibujarCuadro(t, dt, hayParticulas){
    const ventana = OPCIONES_CAIDA[indiceCaida], pixelesPorSegundo = arriba / ventana;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    ctx.drawImage(fondo, 0, 0, ancho, alto);
    activas.clear();
    if(cancion){ dibujarCompases(t, ventana, pixelesPorSegundo); dibujarNotas(t, ventana, pixelesPorSegundo, hayParticulas); }
    dibujarBrillos(); dibujarParticulas(dt); dibujarTeclado();
  }

  function pintar(ahoraMs){
    if(!ancho || estaExportando) return;
    const dt = Math.min(0.05, Math.max(0.001, (ahoraMs - ultimoPintado) / 1000)); ultimoPintado = ahoraMs;
    const t = posicionVisible();
    const hayParticulas = estaReproduciendo && Math.abs(t - posicionAnterior) < 0.4;
    dibujarCuadro(t, dt, hayParticulas);
    if(estaEnCine && cancion){ ctx.font = '600 13px system-ui, sans-serif'; ctx.textBaseline = 'top'; ctx.textAlign = 'right'; ctx.fillStyle = pal().titulo; ctx.fillText(cancion.nombre, ancho - 10, 8); }
    posicionAnterior = t;
    if(estaReproduciendo && t >= cancion.duracion + TIEMPO_FINAL - 0.02){
      if(esBucle){ posicion = -TIEMPO_PREVIO; estaReproduciendo = false; clearInterval(idAgenda); silenciarTodo(); reproducir(); }
      else{ detener(); }
    }
    actualizarPosicion();
  }

  function iniciarCuadros(){
    if(idCuadro) return;
    const cuadro = ahoraMs => {
      idCuadro = 0;
      if($('view-cascada').hidden) return;
      if(!estaExportando && (estaReproduciendo || necesitaPintar || particulas.length)){ necesitaPintar = false; pintar(ahoraMs); }
      idCuadro = requestAnimationFrame(cuadro);
    };
    idCuadro = requestAnimationFrame(cuadro);
  }

  /* ---------- Interfaz ---------- */
  function actualizarPosicion(){
    const total = duracionTotal(), t = posicionVisible();
    const texto = formatoTiempo(t) + ' / ' + formatoTiempo(total);
    if(texto !== ultimoTextoTiempo){ ultimoTextoTiempo = texto; $('caTiempo').textContent = texto; $('caTiempoCine').textContent = texto; }
    if(!estaArrastrando){ $('caPosicion').value = t + TIEMPO_PREVIO; $('caPosicionCine').value = t + TIEMPO_PREVIO; }
  }
  function dibujarFuente(){
    [...document.querySelectorAll('#caFuente button')].forEach(b => b.classList.toggle('sel', b.dataset.fuente === fuente));
  }
  function dibujarInterfaz(){
    const tiene = !!cancion;
    $('caPlay').textContent = estaReproduciendo ? '\u275A\u275A' : '\u25B6'; $('caPlayCine').textContent = $('caPlay').textContent;
    $('caPlay').setAttribute('aria-label', estaReproduciendo ? 'Pausar' : 'Reproducir');
    $('caBucle').classList.toggle('on', esBucle); $('caBucle').setAttribute('aria-pressed', esBucle);
    $('caVelocidad').textContent = 'Vel. ' + velocidad() + 'x';
    $('caCaida').textContent = 'Caida ' + OPCIONES_CAIDA[indiceCaida] + ' s';
    $('caTeclas').textContent = esTecladoCompleto ? 'Teclas 88' : 'Teclas auto';
    for(const id of ['caPlay', 'caStop', 'caBucle', 'caPosicion', 'caPlayCine', 'caPosicionCine']) $(id).disabled = !tiene && id !== 'caBucle';
    const maximo = String((tiene ? cancion.duracion : 0) + TIEMPO_PREVIO + TIEMPO_FINAL);
    $('caPosicion').max = maximo; $('caPosicionCine').max = maximo;
    $('caVacio').hidden = tiene;
    if(!tiene) $('caVacio').innerHTML = '<div><b>Todavia no hay nada que animar</b>Escribe notas en el Estudio, o abre un archivo de proyecto o una partitura MusicXML.</div>';
    $('caInfo').textContent = tiene ? cancion.nombre + ' \u00B7 ' + cancion.notas.length + ' notas \u00B7 ' + Math.round(cancion.bpm) + ' BPM \u00B7 ' + cancion.pistas.length + (cancion.pistas.length === 1 ? ' pista' : ' pistas') : '';
    const caja = $('caPistas'); caja.textContent = '';
    if(tiene) cancion.pistas.forEach((p, k) => {
      const b = document.createElement('button'), punto = document.createElement('i'), nombre = document.createElement('span');
      b.className = 'btn caPista' + (p.estaOculta ? ' off' : ''); b.style.setProperty('--c', p.color); b.dataset.pista = k;
      b.setAttribute('aria-pressed', !p.estaOculta); b.title = 'Mostrar u ocultar esta pista (tambien la silencia)';
      nombre.textContent = p.nombre; b.append(punto, nombre); caja.appendChild(b);
    });
    actualizarPosicion(); necesitaPintar = true;
  }

  function alternarPista(k){
    const p = cancion && cancion.pistas[k]; if(!p) return;
    p.estaOculta = !p.estaOculta; if(p.estaOculta) p.audio.silence();
    dibujarInterfaz();
  }
  function entrarCine(){
    estaEnCine = true; $('view-cascada').classList.add('cine'); mostrarBarraCine();
  }
  function salirCine(){
    estaEnCine = false; const vista = $('view-cascada'); vista.classList.remove('cine', 'conBarra'); clearTimeout(idOcultarBarra); necesitaPintar = true;
  }
  function mostrarBarraCine(){
    const vista = $('view-cascada'); vista.classList.add('conBarra'); clearTimeout(idOcultarBarra);
    idOcultarBarra = setTimeout(() => { if(!estaArrastrando) vista.classList.remove('conBarra'); }, 3200);
  }

  /* ---------- Eventos ---------- */
  $('caPlay').addEventListener('click', alternar); $('caPlayCine').addEventListener('click', () => { alternar(); mostrarBarraCine(); });
  $('caStop').addEventListener('click', detener);
  $('caBucle').addEventListener('click', () => { esBucle = !esBucle; guardarAjustes(); dibujarInterfaz(); });
  $('caVelocidad').addEventListener('click', cambiarVelocidad);
  $('caCaida').addEventListener('click', () => { indiceCaida = (indiceCaida + 1) % OPCIONES_CAIDA.length; guardarAjustes(); dibujarInterfaz(); });
  $('caTeclas').addEventListener('click', () => { esTecladoCompleto = !esTecladoCompleto; guardarAjustes(); armarDisposicion(); dibujarInterfaz(); });
  $('caCine').addEventListener('click', entrarCine); $('caCineSalir').addEventListener('click', salirCine);
  for(const id of ['caPosicion', 'caPosicionCine']){
    const barra = $(id);
    barra.addEventListener('pointerdown', () => { estaArrastrando = true; });
    for(const fin of ['pointerup', 'pointercancel', 'change']) barra.addEventListener(fin, () => { estaArrastrando = false; if(estaEnCine) mostrarBarraCine(); });
    barra.addEventListener('input', () => moverA(parseFloat(barra.value) - TIEMPO_PREVIO));
  }
  lienzo.addEventListener('click', () => { if(!cancion) return; if(estaEnCine){ $('view-cascada').classList.contains('conBarra') ? $('view-cascada').classList.remove('conBarra') : mostrarBarraCine(); } else alternar(); });
  $('caPistas').addEventListener('click', e => { const b = e.target.closest('button'); if(b) alternarPista(+b.dataset.pista); });
  $('caEstudio').addEventListener('click', () => { firmaEstudio = ''; cargarDelEstudio(); });
  $('caAbrir').addEventListener('click', () => $('caArchivo').click());
  $('caArchivo').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; cargarArchivo(f); });
  const botonEstudio = $('stCascada');
  if(botonEstudio) botonEstudio.addEventListener('click', () => NS.State.set({tab:'cascada'}));
  if(typeof ResizeObserver === 'function') new ResizeObserver(() => { if(armarDisposicion()) pintar(performance.now()); }).observe(escena);
  window.addEventListener('resize', () => { if(armarDisposicion()) necesitaPintar = true; });
  document.addEventListener('visibilitychange', () => { if(document.hidden) pausar(); });

  // Al cambiar de tema se rehacen el fondo y las teclas con la nueva paleta (si la pestaña está oculta, se rehacen al entrar)
  NS.Theme.onChange(() => { if(!estaExportando) armarDisposicion(); necesitaPintar = true; });

  /* ---------- API para el resto de la app ---------- */
  NS.Cascada = {
    // Nibel: se llama al entrar a la pestana; si el proyecto del Estudio cambio, se vuelve a leer
    alEntrar(){
      if(fuente === 'estudio') cargarDelEstudio();
      armarDisposicion(); necesitaPintar = true; iniciarCuadros(); dibujarFuente();
    },
    // Nibel: se llama al salir de la pestana
    alSalir(){ if(NS.CascadaVideo) NS.CascadaVideo.cancelar(); detener(); salirCine(); },
    detener,
    hayCancion: () => !!cancion,
    nombreCancion: () => (cancion ? cancion.nombre : ''),
    /* Nibel: prepara la exportacion a video. Dibuja la animacion en `o.lienzo` (de o.ancho x o.alto "logicos" por o.ratio) y
       devuelve {duracion, audio(), dibujar(tau, dt), cerrar()}. tau = segundo del VIDEO; la velocidad elegida se respeta.
       Hay que llamar siempre a cerrar() para devolver la pantalla a su estado normal. */
    paraVideo(o){
      if(!cancion || estaExportando) return null;
      detener();
      const guardado = {particulas, posicionAnterior, posicion};
      estaExportando = true;
      disponer(o.ancho, o.alto, o.ratio, o.lienzo, document.createElement('canvas'));
      particulas = []; posicionAnterior = -TIEMPO_PREVIO;
      const v = velocidad();
      return {
        duracion:(duracionTotal() + TIEMPO_PREVIO + TIEMPO_FINAL) / v,
        // Nibel: las mismas notas, con el mismo instrumento, volumen, balance y fuerza que suenan en pantalla
        audio(){
          const spu = cancion.segundosPorUnidad, aVideo = t => (t + TIEMPO_PREVIO) / v;   // las curvas se desplazan igual que las notas
          const specs = cancion.pistas.map((p, k) => ({id:k, inst:p.inst, vol:p.vol, pan:p.pan, gan:p.gan, fx:p.fx,
            autoVol:spu && p.auto ? NS.Auto.muestras(p.auto.vol, spu, aVideo) : [], autoPan:spu && p.auto ? NS.Auto.muestras(p.auto.pan, spu, aVideo) : []})), notas = [];
          for(const n of cancion.notas){
            if(cancion.pistas[n.pista].estaOculta) continue;
            notas.push({t:n.pista, p:n.p, s:(n.i + TIEMPO_PREVIO) / v, d:Math.min(30, Math.max(0.05, n.d / v)), v:0.85});
          }
          return {specs, notas, maestro:(NS.Studio && NS.Studio.master) ? NS.Studio.master() : 0, general:(NS.Studio && NS.Studio.general) ? NS.Studio.general() : undefined};
        },
        dibujar(tau, dt){
          const t = -TIEMPO_PREVIO + tau * v;
          dibujarCuadro(t, dt, Math.abs(t - posicionAnterior) < 0.4);
          posicionAnterior = t;
        },
        cerrar(){
          estaExportando = false;
          ctx = lienzo.getContext('2d'); fondo = fondoPantalla; ctxFondo = fondo.getContext('2d');   // Nibel: por si la pantalla esta oculta y armarDisposicion no puede medirla
          particulas = guardado.particulas; posicionAnterior = guardado.posicionAnterior; posicion = guardado.posicion;
          armarDisposicion(); dibujarInterfaz(); necesitaPintar = true; if(!$('view-cascada').hidden) iniciarCuadros();
        }
      };
    }
  };
  dibujarFuente(); dibujarInterfaz();
})(window.NS = window.NS || {});
