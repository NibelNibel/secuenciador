#!/usr/bin/env bash
# Compila el APK. Requisitos: Node 20+, JDK 21 y Android SDK (Android Studio los incluye).
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/get-piano.sh
npm install
[ -d android ] || npx cap add android
python3 -m pip install --quiet pillow || pip install --quiet --break-system-packages pillow
python3 scripts/set-icons.py
npx cap sync android
# Evita que Android 15 dibuje la app bajo la barra de estado
STY=android/app/src/main/res/values/styles.xml
grep -q windowOptOutEdgeToEdgeEnforcement "$STY" || sed -i '0,/<\/style>/s##    <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>\n    </style>#' "$STY"
# El teclado del móvil se dibuja encima, sin redimensionar (ni deformar) la app
MAN=android/app/src/main/AndroidManifest.xml
sed -i 's/android:windowSoftInputMode="[^"]*"/android:windowSoftInputMode="adjustNothing"/' "$MAN"
grep -q windowSoftInputMode "$MAN" || sed -i '0,/<activity/s##<activity android:windowSoftInputMode="adjustNothing"#' "$MAN"
# Plugin nativo «Descargas»: guarda en Descargas/Sonavia (si no compilara, se compila sin él y la app usa «Compartir»)
JAVA_DIR=android/app/src/main/java/com/secuenciador/notas
mkdir -p "$JAVA_DIR"
ORIG_MAIN="$(mktemp)"; cp "$JAVA_DIR/MainActivity.java" "$ORIG_MAIN" 2>/dev/null || : > "$ORIG_MAIN"
cp android-nativo/*.java "$JAVA_DIR/"
if ! (cd android && ./gradlew assembleDebug); then
  echo "AVISO: el plugin Descargas no compiló; se compila sin él."
  rm -f "$JAVA_DIR/DescargasPlugin.java"
  [ -s "$ORIG_MAIN" ] && cp "$ORIG_MAIN" "$JAVA_DIR/MainActivity.java"
  (cd android && ./gradlew assembleDebug)
fi
cp android/app/build/outputs/apk/debug/app-debug.apk secuenciador-notas.apk
echo "Listo: secuenciador-notas.apk"
