#!/usr/bin/env bash
# Descarga las muestras del piano (Salamander Grand Piano, CC-BY 3.0, A. Holm)
# a www/audio/salamander para que vayan DENTRO de la app. Solo hace falta internet al compilar.
set -u
cd "$(dirname "$0")/.."
D=www/audio/salamander; mkdir -p "$D"
ok=0; fail=0
for n in A0 C1 Ds1 Fs1 A1 C2 Ds2 Fs2 A2 C3 Ds3 Fs3 A3 C4 Ds4 Fs4 A4 C5 Ds5 Fs5 A5 C6 Ds6 Fs6 A6 C7; do
  if [ -s "$D/$n.mp3" ] || curl -fsSL --retry 3 -o "$D/$n.mp3" "https://tonejs.github.io/audio/salamander/$n.mp3"; then ok=$((ok+1)); else fail=$((fail+1)); rm -f "$D/$n.mp3"; fi
done
echo "Muestras de piano: $ok ok, $fail fallidas"
# Si falta alguna, se borran todas: la app usara el piano sintetizado completo (sin huecos).
if [ "$fail" -gt 0 ]; then rm -rf "$D"; echo "AVISO: se usara el piano sintetizado."; fi
exit 0
