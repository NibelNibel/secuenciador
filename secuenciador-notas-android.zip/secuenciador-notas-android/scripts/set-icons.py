#!/usr/bin/env python3
"""Reemplaza los iconos de la app Android por los de www/imgs/icons."""
import os
from PIL import Image
BG = (20, 22, 28, 255)  # #14161c
RES = "android/app/src/main/res"
src = Image.open("www/imgs/icons/icon-512.png").convert("RGBA")
legacy = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
fore = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
def fit(img, size, scale):
    c = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    k = int(size * scale); im = img.resize((k, k), Image.LANCZOS)
    c.paste(im, ((size - k) // 2, (size - k) // 2), im); return c
for d, px in legacy.items():
    out = os.path.join(RES, f"mipmap-{d}"); os.makedirs(out, exist_ok=True)
    sq = Image.new("RGBA", (px, px), BG); sq.alpha_composite(fit(src, px, .86))
    sq.save(os.path.join(out, "ic_launcher.png")); sq.save(os.path.join(out, "ic_launcher_round.png"))
    fit(src, fore[d], .56).save(os.path.join(out, "ic_launcher_foreground.png"))  # zona segura adaptable
vals = os.path.join(RES, "values"); os.makedirs(vals, exist_ok=True)
open(os.path.join(vals, "ic_launcher_background.xml"), "w").write(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#14161C</color>\n</resources>\n')
print("Iconos actualizados")
