package com.secuenciador.notas;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(DescargasPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
