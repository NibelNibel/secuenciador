package com.secuenciador.notas;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/* Guarda archivos en Descargas/Sonavia (visible en el administrador de archivos).
   Funciona por trozos: iniciar -> escribir (varias veces) -> finalizar. Android 10 o superior. */
@CapacitorPlugin(name = "Descargas")
public class DescargasPlugin extends Plugin {

    private static class Sesion {
        Uri uri;
        OutputStream salida;
    }

    private final Map<String, Sesion> sesiones = new HashMap<>();

    @PluginMethod
    public void iniciar(PluginCall call) {
        String nombre = call.getString("name");
        String mime = call.getString("mime", "application/octet-stream");
        if (nombre == null || nombre.isEmpty()) {
            call.reject("Falta el nombre del archivo");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("Android demasiado antiguo para guardar en Descargas");
            return;
        }
        try {
            ContentResolver resolver = getContext().getContentResolver();
            ContentValues valores = new ContentValues();
            valores.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
            valores.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            valores.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sonavia");
            valores.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores);
            if (uri == null) {
                call.reject("No se pudo crear el archivo en Descargas");
                return;
            }
            OutputStream salida = resolver.openOutputStream(uri);
            if (salida == null) {
                resolver.delete(uri, null, null);
                call.reject("No se pudo abrir el archivo para escribir");
                return;
            }
            Sesion s = new Sesion();
            s.uri = uri;
            s.salida = salida;
            String id = UUID.randomUUID().toString();
            sesiones.put(id, s);
            JSObject r = new JSObject();
            r.put("id", id);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("No se pudo crear el archivo: " + e.getMessage());
        }
    }

    @PluginMethod
    public void escribir(PluginCall call) {
        String id = call.getString("id");
        String datos = call.getString("data");
        Sesion s = id == null ? null : sesiones.get(id);
        if (s == null || datos == null) {
            call.reject("Archivo no abierto");
            return;
        }
        try {
            s.salida.write(Base64.decode(datos, Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("No se pudo escribir: " + e.getMessage());
        }
    }

    @PluginMethod
    public void finalizar(PluginCall call) {
        String id = call.getString("id");
        Sesion s = id == null ? null : sesiones.remove(id);
        if (s == null) {
            call.reject("Archivo no abierto");
            return;
        }
        try {
            s.salida.flush();
            s.salida.close();
            ContentValues valores = new ContentValues();
            valores.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContext().getContentResolver().update(s.uri, valores, null, null);
            call.resolve();
        } catch (Exception e) {
            call.reject("No se pudo terminar el archivo: " + e.getMessage());
        }
    }

    @PluginMethod
    public void cancelar(PluginCall call) {
        String id = call.getString("id");
        Sesion s = id == null ? null : sesiones.remove(id);
        if (s != null) {
            try {
                s.salida.close();
            } catch (Exception e) {
                // nada que hacer
            }
            try {
                getContext().getContentResolver().delete(s.uri, null, null);
            } catch (Exception e) {
                // nada que hacer
            }
        }
        call.resolve();
    }
}
